'use client';

import Link from 'next/link';
import { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Send,
  FileSearch,
  ListChecks,
  Globe,
  Clock,
  ShieldCheck,
  MessageSquare,
  CheckCircle2,
  Paperclip,
  Stamp,
} from 'lucide-react';
import ClippyMascot from '@/components/ClippyMascot';
import WorldMap from '@/components/WorldMap';
import ThemeToggle from '@/components/ThemeToggle';
import PalettePicker from '@/components/dashboard/PalettePicker';
import { useMockUser } from '@/lib/storage';
import {
  COUNTRY_NAMES,
  COUNTRY_FLAGS,
  type Country,
} from '@/lib/types';
import { cn } from '@/lib/utils';

const COUNTRIES: Country[] = ['BG', 'DE', 'NL', 'PT', 'ES', 'FR', 'PL', 'CZ', 'AT', 'SE', 'GE', 'RS', 'GB', 'CH', 'UA', 'HR', 'GR', 'RO'];

const SAMPLES = [
  'How do I apply for a residence permit in Bulgaria?',
  'What documents do I need for a work visa?',
  'How to register a company abroad?',
];

const FEATURES = [
  {
    icon: FileSearch,
    title: 'Document Analysis',
    body:
      'Upload any document and get instant insights. Our AI understands forms, applications, and official letters.',
  },
  {
    icon: ListChecks,
    title: 'Step-by-Step Guidance',
    body:
      'Get clear, numbered steps for any procedure. Know exactly what to do next and never miss a requirement.',
  },
  {
    icon: Globe,
    title: 'Multi-Country Support',
    body:
      'Whether you are abroad or at home, get localized guidance for procedures across 18 countries.',
  },
  {
    icon: Clock,
    title: 'Time Estimates',
    body:
      'Know how long each step takes. Plan your time and avoid unnecessary trips or delays.',
  },
  {
    icon: ShieldCheck,
    title: 'Document Checklist',
    body:
      'Interactive checklists ensure you have everything ready. Track your progress and tick off completed items.',
  },
  {
    icon: MessageSquare,
    title: 'Ask Anything',
    body:
      'Have a specific question? Just ask. Get instant, accurate answers about any bureaucratic process.',
  },
];

export default function HomePage() {
  const { user } = useMockUser();
  const [country, setCountry] = useState<Country>('BG');
  const [tryInput, setTryInput] = useState('');

  return (
    <div className="min-h-screen bg-background">
      {/* ================= MARKETING HEADER ================= */}
      <header className="fixed inset-x-0 top-0 z-40 border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Link href="/" className="flex items-center gap-2.5">
            <ClippyMascot size={22} mood="static" ariaLabel="" />
            <span className="text-lg font-bold tracking-tight text-foreground">FormWise</span>
          </Link>

          <div className="flex items-center gap-1.5">
            <ThemeToggle />
            <PalettePicker />

            <select
              value={country}
              onChange={(e) => setCountry(e.target.value as Country)}
              aria-label="Country"
              className={cn(
                'h-9 rounded-md border border-border bg-card px-2.5 text-sm',
                'text-foreground hover:border-primary/40 transition-colors',
                'focus:outline-none focus:ring-2 focus:ring-ring/40',
              )}
            >
              {COUNTRIES.map((c) => (
                <option key={c} value={c}>
                  {COUNTRY_FLAGS[c]} {COUNTRY_NAMES[c]}
                </option>
              ))}
            </select>

            <Link
              href={user ? '/dashboard' : '/register'}
              className={cn(
                'inline-flex items-center gap-1.5 rounded-md',
                'bg-primary text-primary-foreground shadow-brand',
                'px-3 py-1.5 text-sm font-semibold ml-1',
                'transition-all hover:shadow-brand-strong active:scale-[0.98]',
              )}
            >
              {user ? 'Dashboard' : 'Try free'}
            </Link>
          </div>
        </div>
      </header>

      <main className="pt-16">
        {/* ================= HERO ================= */}
        <section className="relative overflow-hidden">
          <div
            className="absolute -top-32 -left-32 h-72 w-72 rounded-full bg-primary/15 blur-3xl"
            aria-hidden
          />
          <div
            className="absolute top-20 -right-16 h-64 w-64 rounded-full bg-accent/15 blur-3xl"
            aria-hidden
          />

          <div className="relative mx-auto max-w-5xl px-4 py-16 sm:py-24 sm:px-6 lg:px-8">
            <div className="text-center space-y-6">
              {/* Eyebrow badge */}
              <span
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-full',
                  'bg-accent/10 border border-accent/30',
                  'px-3 py-1 text-xs font-medium text-[oklch(0.42_0.10_145)] dark:text-accent',
                )}
              >
                <Sparkles size={11} strokeWidth={2.5} />
                AI-powered guidance for any process
              </span>

              {/* Floating decorative cards */}
              <div className="relative">
                {/* Top-left floating card */}
                <div
                  className={cn(
                    'hidden md:flex absolute -left-4 top-12',
                    'items-center gap-2 rounded-xl border border-border bg-card p-2.5',
                    'shadow-lg',
                  )}
                  aria-hidden
                >
                  <span
                    className={cn(
                      'flex h-8 w-8 items-center justify-center rounded-lg shrink-0',
                      'bg-accent/15 text-accent',
                    )}
                  >
                    <CheckCircle2 size={15} strokeWidth={2.25} />
                  </span>
                  <div className="text-left">
                    <div className="text-[10px] uppercase tracking-wide text-muted-foreground leading-none">
                      Document
                    </div>
                    <div className="text-xs font-semibold text-foreground leading-tight mt-0.5">
                      Analyzed
                    </div>
                  </div>
                </div>

                {/* Top-right floating card */}
                <div
                  className={cn(
                    'hidden md:flex absolute -right-4 top-32',
                    'items-center gap-2 rounded-xl border border-border bg-card p-2.5',
                    'shadow-lg',
                  )}
                  aria-hidden
                >
                  <span
                    className={cn(
                      'flex h-8 w-8 items-center justify-center rounded-lg shrink-0',
                      'bg-primary/15 text-primary',
                    )}
                  >
                    <CheckCircle2 size={15} strokeWidth={2.25} />
                  </span>
                  <div className="text-left">
                    <div className="text-[10px] uppercase tracking-wide text-muted-foreground leading-none">
                      Step 3 of 5
                    </div>
                    <div className="text-xs font-semibold text-foreground leading-tight mt-0.5">
                      Completed
                    </div>
                  </div>
                </div>

                {/* Floating decorative icons */}
                <Paperclip
                  size={18}
                  className="hidden md:block absolute -left-20 top-40 text-primary/30 rotate-12"
                  aria-hidden
                />
                <Stamp
                  size={18}
                  className="hidden md:block absolute -right-16 -top-2 text-primary/30"
                  aria-hidden
                />

                {/* Clippy */}
                <div className="flex justify-center pt-2">
                  <ClippyMascot size={88} mood="waving" />
                </div>

                {/* Headline */}
                <h1 className="mt-6 text-balance text-4xl font-bold tracking-tight text-foreground sm:text-6xl leading-[1.05]">
                  Navigate bureaucracy
                  <br />
                  <span className="relative inline-block text-primary">
                    without the headache
                    <svg
                      className="absolute -bottom-2 left-0 right-0 h-3 w-full text-accent"
                      viewBox="0 0 600 14"
                      preserveAspectRatio="none"
                      fill="none"
                      aria-hidden
                    >
                      <path
                        d="M2 9C100 4 200 2 300 6C400 10 500 4 598 9"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinecap="round"
                      />
                    </svg>
                  </span>
                </h1>
              </div>

              <p className="text-pretty mx-auto max-w-2xl text-base sm:text-lg leading-relaxed text-muted-foreground pt-4">
                Upload documents, ask questions, and get step-by-step guidance through any
                administrative process. From visa applications to business permits.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <Link
                  href={user ? '/dashboard' : '/register'}
                  className={cn(
                    'inline-flex items-center gap-1.5 rounded-lg',
                    'bg-primary text-primary-foreground shadow-brand',
                    'px-5 py-3 text-sm font-semibold',
                    'transition-all hover:shadow-brand-strong active:scale-[0.98]',
                  )}
                >
                  Try it free <ArrowRight size={14} strokeWidth={2.25} />
                </Link>
                <Link
                  href="/demo"
                  className={cn(
                    'inline-flex items-center gap-1.5 rounded-lg',
                    'border border-border bg-card',
                    'px-5 py-3 text-sm font-semibold text-foreground',
                    'transition-all hover:border-primary/40 hover:shadow-md',
                  )}
                >
                  See how it works
                </Link>
              </div>

              <p className="text-xs text-muted-foreground pt-1">
                No credit card required. 1 free analysis to get started.
              </p>
            </div>

            {/* World Map */}
            <div className="mt-16 rounded-2xl border border-border bg-card/60 backdrop-blur-sm p-4 sm:p-6">
              <WorldMap active={country} onSelect={setCountry} />
            </div>
          </div>
        </section>

        {/* ================= FEATURES GRID ================= */}
        <section className="relative py-16 sm:py-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto space-y-3">
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-foreground">
                Everything you need to conquer paperwork
              </h2>
              <p className="text-base text-muted-foreground">
                Powerful features designed to make bureaucratic processes simple and stress-free.
              </p>
            </div>

            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((f, i) => {
                const Icon = f.icon;
                return (
                  <div
                    key={i}
                    className={cn(
                      'rounded-xl border border-border bg-card p-6',
                      'transition-all hover:border-primary/30 hover:shadow-lg',
                    )}
                  >
                    <span
                      className={cn(
                        'flex h-11 w-11 items-center justify-center rounded-lg',
                        'bg-primary/10 text-primary',
                      )}
                      aria-hidden
                    >
                      <Icon size={20} strokeWidth={2} />
                    </span>
                    <h3 className="mt-4 text-lg font-bold text-foreground">{f.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ================= TRY IT NOW ================= */}
        <section className="relative py-16 sm:py-20 bg-secondary/40">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-3">
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-foreground">
                Try it now
              </h2>
              <p className="text-base text-muted-foreground">
                Ask any question about bureaucratic procedures and see how FormWise can help.
              </p>
            </div>

            <div
              className={cn(
                'mt-10 rounded-2xl border border-border bg-card p-5 sm:p-6 shadow-xl',
              )}
            >
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-secondary/30">
                <input
                  type="text"
                  value={tryInput}
                  onChange={(e) => setTryInput(e.target.value)}
                  placeholder="Ask about any bureaucratic procedure…"
                  className={cn(
                    'h-10 w-full bg-transparent text-sm text-foreground',
                    'placeholder:text-muted-foreground/70',
                    'focus:outline-none',
                  )}
                />
                <Link
                  href={`/demo`}
                  aria-label="Try in demo"
                  className={cn(
                    'flex h-9 w-9 shrink-0 items-center justify-center rounded-md',
                    'bg-primary text-primary-foreground shadow-brand',
                    'transition-all hover:shadow-brand-strong',
                  )}
                >
                  <Send size={14} strokeWidth={2.25} />
                </Link>
              </div>

              <div className="mt-4 flex flex-wrap items-baseline gap-x-3 gap-y-2">
                <span className="text-xs font-medium text-muted-foreground">Try:</span>
                {SAMPLES.map((s) => (
                  <Link
                    key={s}
                    href="/demo"
                    className="text-xs text-primary hover:underline transition-colors"
                  >
                    {s}
                  </Link>
                ))}
              </div>

              <div className="mt-6 pt-5 border-t border-border flex flex-wrap items-center justify-between gap-3">
                <span className="text-xs text-muted-foreground">
                  Want full access? Create a free account to track your processes.
                </span>
                <Link
                  href={user ? '/dashboard' : '/register'}
                  className={cn(
                    'inline-flex items-center gap-1.5 rounded-md',
                    'border border-border bg-card',
                    'px-3 py-1.5 text-xs font-semibold text-foreground',
                    'transition-all hover:border-primary/40 hover:shadow-md',
                  )}
                >
                  {user ? 'Open dashboard' : 'Create Account'}
                  <ArrowRight size={11} strokeWidth={2.25} />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* ================= FOOTER ================= */}
        <footer className="border-t border-border py-8">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <ClippyMascot size={14} mood="static" ariaLabel="" />
              <span>FormWise · Built at AI Hackathon Ruse 2026</span>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/demo" className="hover:text-foreground transition-colors">
                Live demo
              </Link>
              <Link href="/login" className="hover:text-foreground transition-colors">
                Sign in
              </Link>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
