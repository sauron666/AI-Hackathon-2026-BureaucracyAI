'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState, type FormEvent } from 'react';
import { ArrowRight, Check, Eye, EyeOff } from 'lucide-react';
import ClippyMascot from '@/components/ClippyMascot';
import ThemeToggle from '@/components/ThemeToggle';
import { useMockUser } from '@/lib/storage';
import { cn } from '@/lib/utils';

const BENEFITS = [
  'Unlimited document analysis',
  'Process tracking dashboard',
  'Document history',
  'Priority support',
];

export default function RegisterPage() {
  const router = useRouter();
  const { signIn } = useMockUser();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const canSubmit =
    email.trim().length > 3 && email.includes('@') && password.length >= 4;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    // Mock auth: just persist to localStorage. No real backend.
    signIn(email, name);
    // Tiny artificial delay so the button feedback registers visually
    setTimeout(() => router.push('/dashboard'), 200);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Minimal header (logo + theme) */}
      <header className="flex items-center justify-between px-4 sm:px-6 lg:px-8 py-4">
        <Link href="/" className="inline-flex items-center gap-2.5">
          <ClippyMascot size={22} mood="static" ariaLabel="" />
          <span className="text-lg font-bold tracking-tight text-foreground">FormWise</span>
        </Link>
        <ThemeToggle />
      </header>

      <main className="flex-1 flex items-start sm:items-center justify-center px-4 py-8">
        <div
          className={cn(
            'w-full max-w-md rounded-2xl border border-border bg-card shadow-xl',
            'p-6 sm:p-8 space-y-6',
          )}
        >
          <div className="text-center space-y-1">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
              Create your account
            </h1>
            <p className="text-sm text-muted-foreground">
              Start navigating bureaucracy with AI
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Field
              label="Full Name"
              type="text"
              value={name}
              onChange={setName}
              placeholder="Your name"
              autoComplete="name"
            />
            <Field
              label="Email"
              type="email"
              value={email}
              onChange={setEmail}
              placeholder="you@example.com"
              autoComplete="email"
              required
            />

            {/* Password with show/hide toggle */}
            <label className="block space-y-1.5">
              <span className="text-sm font-semibold text-foreground">Password</span>
              <div
                className={cn(
                  'relative flex items-center rounded-md border border-border bg-card',
                  'transition-colors focus-within:ring-2 focus-within:ring-ring/40 focus-within:border-primary/40',
                )}
              >
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 4 characters"
                  autoComplete="new-password"
                  required
                  minLength={4}
                  className={cn(
                    'h-11 w-full bg-transparent px-3 pr-10 text-sm',
                    'text-foreground placeholder:text-muted-foreground/70',
                    'focus:outline-none',
                  )}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className={cn(
                    'absolute right-1 h-9 w-9 inline-flex items-center justify-center rounded-md',
                    'text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors',
                  )}
                >
                  {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </label>

            <button
              type="submit"
              disabled={submitting || !canSubmit}
              className={cn(
                'w-full inline-flex items-center justify-center gap-1.5 rounded-md',
                'bg-primary text-primary-foreground shadow-brand',
                'px-4 py-3 text-sm font-semibold',
                'transition-all hover:shadow-brand-strong active:scale-[0.99]',
                'disabled:opacity-50 disabled:active:scale-100 disabled:cursor-not-allowed',
              )}
            >
              {submitting ? 'Creating your account…' : 'Create Account'}
              {!submitting && <ArrowRight size={14} strokeWidth={2.25} />}
            </button>

            <p className="text-[11px] text-center text-muted-foreground">
              Demo mode — no real signup. Any email and a 4+ character password works.
            </p>
          </form>

          {/* What you get */}
          <div className="pt-5 border-t border-border space-y-3">
            <h3 className="text-sm font-semibold text-foreground">What you get:</h3>
            <ul className="space-y-2">
              {BENEFITS.map((b) => (
                <li
                  key={b}
                  className="flex items-center gap-2 text-sm text-muted-foreground"
                >
                  <Check
                    size={14}
                    strokeWidth={2.5}
                    className="text-accent shrink-0"
                    aria-hidden
                  />
                  {b}
                </li>
              ))}
            </ul>
          </div>

          <p className="text-center text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link href="/login" className="font-semibold text-primary hover:underline">
              Log in
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}

function Field({
  label,
  type,
  value,
  onChange,
  placeholder,
  autoComplete,
  required,
  minLength,
}: {
  label: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  autoComplete?: string;
  required?: boolean;
  minLength?: number;
}) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm font-semibold text-foreground">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        required={required}
        minLength={minLength}
        className={cn(
          'h-11 w-full rounded-md border border-border bg-card px-3 text-sm',
          'text-foreground placeholder:text-muted-foreground/70',
          'transition-colors focus:outline-none focus:ring-2 focus:ring-ring/40 focus:border-primary/40',
        )}
      />
    </label>
  );
}
