/**
 * MOCK /api/chat — DEMO ONLY
 *
 * Streams a ProcedureAnswer JSON in small chunks so the useObject hook on the
 * client parses it progressively. This gives a faithful preview of the real
 * streaming behavior while Dev 2 ships /api/chat with streamObject() against
 * Anthropic. Replace this entire file with the spec in AI-CONTEXT-FINAL.md
 * when the real route is ready.
 */

export const maxDuration = 30;

interface ChatRequest {
  question?: string;
  language?: string;
  country?: string;
}

interface MockAnswer {
  summary: string;
  steps: string[];
  documents: string[];
  office: string | null;
  fee_info: string | null;
  source_url: string | null;
  confidence: number;
  answerable: boolean;
}

const ANSWERS_BY_COUNTRY: Record<string, MockAnswer> = {
  DE: {
    summary:
      "You must register your address at the local Bürgeramt within 14 days of moving in. This gives you the Anmeldebestätigung (registration confirmation) — the document you'll need for almost everything else: opening a bank account, getting a tax ID, signing up for health insurance.",
    steps: [
      "Book an appointment online at service.berlin.de — slots open about 30 days ahead and disappear quickly. Try refreshing at 8:00 on a Monday morning.",
      "Get your Wohnungsgeberbestätigung (landlord confirmation) — your landlord must give you this signed form. By law they have 14 days from your move-in date.",
      "Visit the Bürgeramt at your appointment time. Bring your passport, the Wohnungsgeberbestätigung, your rental contract, and any marriage or birth certificates if registering with family.",
      "At the appointment, fill out the Anmeldungsformular (registration form). Staff rarely speak English — bring a translator if you don't speak German.",
      "Receive your Anmeldebestätigung the same day. Keep the original safe — banks, employers, and authorities will all ask for it.",
    ],
    documents: [
      "Valid passport or EU national ID",
      "Wohnungsgeberbestätigung (landlord confirmation, signed)",
      "Rental contract (Mietvertrag)",
      "Marriage certificate if registering with spouse (apostilled, with German translation)",
    ],
    office:
      "Bürgeramt (any branch in your city — pick the one closest to you). In Berlin: e.g. Bürgeramt Mitte, Karl-Marx-Allee 31, 10178 Berlin.",
    fee_info: "Free (gratis)",
    source_url: "https://service.berlin.de/dienstleistung/120335/",
    confidence: 0.92,
    answerable: true,
  },
  NL: {
    summary:
      "To register in the Netherlands and receive your BSN (Burgerservicenummer — citizen service number), you need to make an appointment with your local municipality (gemeente) within 5 days of arrival if you plan to stay longer than 4 months.",
    steps: [
      "Book an appointment with the gemeente of the city where you'll live. Online booking is on the gemeente's website (e.g. amsterdam.nl).",
      "Bring all required documents to the appointment. Originals only — copies are not accepted.",
      "Submit your registration in person. The clerk will verify your documents and enter your details into the BRP (Basisregistratie Personen).",
      "Receive your BSN by post within 1–2 weeks at the address you registered.",
      "Use your BSN to open a Dutch bank account, sign an employment contract, and register for health insurance (zorgverzekering, mandatory within 4 months).",
    ],
    documents: [
      "Valid passport (EU national ID also accepted)",
      "Rental contract or proof of address",
      "Birth certificate (apostilled, translated to Dutch, English, French or German if not in those languages)",
      "Marriage certificate if applicable (same translation/apostille rules)",
    ],
    office:
      "Gemeente (municipality) of your residence city. The IND handles residence permits separately.",
    fee_info: "Free (gratis)",
    source_url: "https://www.government.nl/topics/personal-data/bsn",
    confidence: 0.89,
    answerable: true,
  },
  PT: {
    summary:
      "The NIF (Número de Identificação Fiscal) is Portugal's tax ID and you need it for almost everything: signing a lease, opening a bank account, getting a phone contract, even buying a SIM card. Non-residents can request one through a fiscal representative; residents apply directly.",
    steps: [
      "If you're a non-EU non-resident: appoint a fiscal representative (representante fiscal) — usually a lawyer or accountant, costs €100–250 per year.",
      "Gather your passport (or EU national ID) and proof of address (a utility bill from your home country works).",
      "Visit a Finanças (tax office) branch in person, or apply through your fiscal representative if you can't be in Portugal.",
      "Submit your application — the NIF is issued on the spot, free of charge.",
      "Save your NIF certificate. You'll quote this number constantly — banks, landlords, even the supermarket loyalty card will ask.",
    ],
    documents: [
      "Valid passport or EU national ID",
      "Proof of address (foreign address is fine for non-residents)",
      "Power of attorney for fiscal representative (non-EU non-residents only)",
    ],
    office: "Any Finanças (tax office) branch — find the nearest at portaldasfinancas.gov.pt",
    fee_info: "Free (gratis)",
    source_url: "https://www.portaldasfinancas.gov.pt/",
    confidence: 0.88,
    answerable: true,
  },
  ES: {
    summary:
      "The NIE (Número de Identidad de Extranjero) is your Spanish foreigner ID number and is mandatory for any administrative procedure — buying property, signing a lease, getting a job, opening a bank account.",
    steps: [
      "Decide your route: in Spain (faster, cheaper) or at a Spanish consulate abroad (slower, useful before arrival).",
      "Book an appointment (cita previa) at a Comisaría de Policía with a foreigners' office, on sede.administracionespublicas.gob.es.",
      "Fill in form EX-15 and pay the €9.84 fee at any bank using form 790, code 012.",
      "Attend your appointment with your passport, the EX-15, the bank receipt, and a justification (job offer, property purchase, study acceptance, etc.).",
      "Receive a paper certificate with your NIE — keep this, you'll need it constantly. The card version (TIE) is separate and only for non-EU residents staying longer than 6 months.",
    ],
    documents: [
      "Valid passport (and a photocopy of every page)",
      "Form EX-15 (filled, signed)",
      "Form 790 code 012 receipt (proof of fee paid)",
      "Justification document (oferta de trabajo, compraventa, matrícula universitaria, etc.)",
    ],
    office:
      "Comisaría de Policía with Oficina de Extranjeros, or Spanish consulate in your country.",
    fee_info: "€9.84",
    source_url: "https://sede.administracionespublicas.gob.es/",
    confidence: 0.91,
    answerable: true,
  },
};

// Low-confidence fallback used when the question doesn't match a known scenario
const LOW_CONFIDENCE_FALLBACK: MockAnswer = {
  summary:
    "I don't have detailed information about this specific procedure in my knowledge base yet. The information below is general — please verify with the official government website before acting on it.",
  steps: [
    "Check the official government website for your country and locality.",
    "Look for the relevant ministry or municipal office.",
    "Bring identification and any supporting documents to your appointment.",
  ],
  documents: ["Valid passport or national ID", "Proof of address"],
  office: "Local municipal office — verify on the official government portal.",
  fee_info: null,
  source_url: null,
  confidence: 0.35,
  answerable: true,
};

// Special "ask for clarification" mock — triggered if the question is too short
const NOT_ANSWERABLE: MockAnswer = {
  summary:
    "Your question is a bit too brief for me to give a confident, specific answer. Could you tell me which procedure you mean and which country it's for?",
  steps: [],
  documents: [],
  office: null,
  fee_info: null,
  source_url: null,
  confidence: 0.2,
  answerable: false,
};

function pickAnswer(req: ChatRequest): MockAnswer {
  const question = (req.question || '').toLowerCase().trim();
  if (question.length < 8) return NOT_ANSWERABLE;
  return ANSWERS_BY_COUNTRY[req.country || 'DE'] || LOW_CONFIDENCE_FALLBACK;
}

export async function POST(req: Request) {
  const body = (await req.json()) as ChatRequest;
  const answer = pickAnswer(body);
  const json = JSON.stringify(answer);

  // Stream the JSON as text in small chunks so useObject parses progressively.
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      let i = 0;
      while (i < json.length) {
        // Variable chunk size for a more natural feel
        const chunkSize = 18 + Math.floor(Math.random() * 22);
        const slice = json.slice(i, i + chunkSize);
        controller.enqueue(encoder.encode(slice));
        i += chunkSize;
        await new Promise((r) => setTimeout(r, 35 + Math.random() * 40));
      }
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'X-Accel-Buffering': 'no',
    },
  });
}
