/**
 * MOCK /api/journey — DEMO ONLY
 *
 * Returns a full RelocationJourney. Replace with the spec in
 * AI-CONTEXT-FINAL.md when Dev 2 ships the real generateObject() route.
 */

import type { RelocationJourney } from '@/lib/types';

interface JourneyRequest {
  from_country?: string;
  to_country?: string;
  nationality?: string;
  purpose?: string;
  language?: string;
}

function buildJourney(req: JourneyRequest): RelocationJourney {
  const nationality = req.nationality || 'someone';
  const from = req.from_country || 'abroad';
  const purpose = (req.purpose || 'work').replace('_', ' ');
  const to = req.to_country || 'DE';

  return {
    title: `Relocation plan: ${nationality} moving from ${from} to ${to} for ${purpose}`,
    estimated_total_cost: '€1,800 – €3,400 (visa, deposit, fees, first months of insurance)',
    phases: [
      {
        phase: 'Before you leave',
        timeline: '2 – 3 months before departure',
        tasks: [
          {
            task: "Apply for a work visa (D-Visum) at the German consulate in your home country. Book the appointment as early as possible — slots fill 8–12 weeks ahead.",
            urgency: 'critical',
            where: 'German consulate or embassy',
            estimated_time: '8 – 12 weeks',
          },
          {
            task: "Have your university degree recognized via anabin.kmk.org if your job requires it. For regulated professions (medicine, law, teaching), separate recognition through the relevant German chamber.",
            urgency: 'critical',
            where: 'anabin.kmk.org or relevant Kammer',
            estimated_time: '4 – 8 weeks',
          },
          {
            task: "Get all civil documents (birth certificate, marriage certificate, etc.) apostilled and translated by a sworn translator (vereidigter Übersetzer).",
            urgency: 'important',
            where: 'Home country issuing authority + German embassy',
            estimated_time: '2 – 4 weeks',
          },
          {
            task: "Open a blocked account (Sperrkonto) if your visa requires proof of funds — typical amount €11,208 for a year.",
            urgency: 'important',
            where: 'Online (Expatrio, Fintiba, Coracle)',
            estimated_time: '3 – 5 days',
          },
          {
            task: "Sort out international shipping or storage of belongings, and confirm what your destination flat already includes (most rentals are unfurnished).",
            urgency: 'optional',
            where: null,
            estimated_time: null,
          },
        ],
      },
      {
        phase: 'First week in Germany',
        timeline: 'Days 1 – 7 after arrival',
        tasks: [
          {
            task: "Find permanent housing if you don't have it yet. Until then, register at an Anmeldung-friendly Airbnb or short-let where the host will provide a Wohnungsgeberbestätigung.",
            urgency: 'critical',
            where: 'Anywhere with a registered address',
            estimated_time: '1 – 2 weeks',
          },
          {
            task: "Get the Wohnungsgeberbestätigung (landlord confirmation) signed by your landlord. Legally required within 14 days of moving in.",
            urgency: 'critical',
            where: 'From your landlord',
            estimated_time: 'Same day',
          },
          {
            task: "Book your Anmeldung (address registration) appointment immediately — slots in Berlin disappear in minutes. Try service.berlin.de at 8:00 Monday morning.",
            urgency: 'critical',
            where: 'service.berlin.de or local Bürgeramt website',
            estimated_time: 'Books 2 – 4 weeks ahead',
          },
        ],
      },
      {
        phase: 'First month',
        timeline: 'Weeks 2 – 4',
        tasks: [
          {
            task: "Attend your Anmeldung appointment with your passport, visa, Wohnungsgeberbestätigung, and rental contract. You'll receive your Anmeldebestätigung and tax ID (Steuer-ID) by post within 2 weeks.",
            urgency: 'critical',
            where: 'Bürgeramt',
            estimated_time: '30 – 45 minutes',
          },
          {
            task: "Open a German bank account. Most international employers require an IBAN to pay you. Online options (N26, ING) are fastest; Sparkasse needs in-person.",
            urgency: 'critical',
            where: 'Online or local branch',
            estimated_time: 'Same-day to 1 week',
          },
          {
            task: "Sign up for statutory health insurance (gesetzliche Krankenversicherung). Required from your employment start date. TK and AOK are the most common options.",
            urgency: 'critical',
            where: 'Online or insurer office',
            estimated_time: '1 – 2 weeks for card delivery',
          },
          {
            task: "Apply for a residence permit (Aufenthaltserlaubnis) at the Ausländerbehörde — your D-Visum is only valid for the entry period. Book the appointment online; queues are long in Berlin and Munich.",
            urgency: 'critical',
            where: 'Ausländerbehörde',
            estimated_time: '6 – 10 weeks for appointment',
          },
        ],
      },
      {
        phase: 'First 3 months',
        timeline: 'Months 2 – 3',
        tasks: [
          {
            task: "Receive and activate your eAT card (electronic residence permit). Carry it at all times — it's your legal proof of residency.",
            urgency: 'critical',
            where: 'Ausländerbehörde (collection)',
            estimated_time: '4 – 8 weeks after applying',
          },
          {
            task: "Register with the Finanzamt for income tax — usually handled automatically via Anmeldung, but verify your tax class (Steuerklasse) is correct for your situation.",
            urgency: 'important',
            where: 'Finanzamt',
            estimated_time: 'Automatic, verify by mail',
          },
          {
            task: "Pay the Rundfunkbeitrag (broadcasting fee, ~€18.36/month). Mandatory for every household — register at rundfunkbeitrag.de.",
            urgency: 'important',
            where: 'rundfunkbeitrag.de',
            estimated_time: '5 minutes',
          },
          {
            task: "Take an integration course (Integrationskurs) if your residence permit requires it. Subsidized by BAMF.",
            urgency: 'optional',
            where: 'BAMF-approved language school',
            estimated_time: '6 – 9 months',
          },
        ],
      },
    ],
    warnings: [
      "Don't sign a long-term lease before you have a residence permit — agencies require Schufa and proof of permit which you won't have on day 1. Use furnished short-lets for the first 1–2 months.",
      "Anmeldung delay is the #1 mistake: you can't get a bank account, health insurance card, or work formally until it's done. Book the appointment from your home country if possible.",
      "Schufa credit reports work like a US credit score — you need one to rent in most cities, and it takes 3–6 months of German banking history to build one. Plan workarounds (e.g. larger deposit, expat-friendly landlords).",
      "Don't ignore mail. The German postal system delivers Behördenbriefe (official letters) with strict deadlines. Read everything, even if it's in German you don't understand — translate it the same day.",
    ],
  };
}

export async function POST(req: Request) {
  const body = (await req.json()) as JourneyRequest;
  await new Promise((r) => setTimeout(r, 1500 + Math.random() * 700));
  return Response.json(buildJourney(body));
}
