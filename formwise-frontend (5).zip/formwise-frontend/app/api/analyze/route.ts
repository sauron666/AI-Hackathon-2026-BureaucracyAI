/**
 * MOCK /api/analyze — DEMO ONLY
 *
 * Returns a full DocumentRisk object. Different document_type values give
 * different scenarios so you can preview low/medium/high risk surfaces.
 * Replace with the spec in AI-CONTEXT-FINAL.md when Dev 2 ships the real
 * generateObject() route.
 */

import type { DocumentRisk } from '@/lib/types';

const RENTAL_DE: DocumentRisk = {
  risk_level: 'medium',
  summary:
    "Fair overall, but two clauses sit below standard German tenant protections. Negotiate these before signing — they may not be enforceable, but cleaner wording avoids any dispute later.",
  risks: [
    {
      clause:
        "Tenant agrees to repaint all walls in white before moving out, regardless of condition.",
      risk:
        "Rigid repaint clauses without condition-based wording have been ruled invalid by the Federal Court of Justice (BGH). You're not legally obligated to repaint walls that are in normal condition.",
      severity: 'high',
      recommendation:
        "Strike this clause or replace with: 'cosmetic repairs only if necessary based on wear and tear.'",
    },
    {
      clause: "Tenant must give 6 months' written notice before terminating the lease.",
      risk:
        "Standard German law allows tenants to terminate with 3 months' notice (§573c BGB). A 6-month requirement on the tenant is unusual and likely not enforceable.",
      severity: 'medium',
      recommendation:
        "Negotiate down to the statutory 3 months. Most landlords agree once you mention §573c.",
    },
    {
      clause: "Small pets allowed only with the landlord's written consent.",
      risk:
        "Standard wording. German courts generally interpret this as 'consent cannot be unreasonably withheld.'",
      severity: 'low',
      recommendation: "No action needed.",
    },
  ],
  missing_clauses: [
    "No itemized utility (Nebenkosten) breakdown — you should ask for one before signing.",
    "No clause specifying the deposit return timeline (the legal default is up to 6 months, but 30–60 days is standard practice).",
  ],
  positive_points: [
    "Rent is at market rate for Berlin Mitte (~€18/m²).",
    "Deposit is the legal maximum of 3 months' cold rent — not exceeded.",
    "Lease term is open-ended (unbefristet), giving you strong tenant protections.",
  ],
  verdict:
    "Sign-able once you fix the repaint clause and the 6-month notice period. Bring it back to the landlord with your edits before signing.",
};

const EMPLOYMENT_NL: DocumentRisk = {
  risk_level: 'low',
  summary:
    "Solid contract overall. The terms are within standard Dutch employment law, and the company has applied the 30% ruling correctly. One minor item to clarify before signing.",
  risks: [
    {
      clause: "Probation period of 2 months at the start of employment.",
      risk:
        "Two-month probation is the legal maximum in the Netherlands for indefinite contracts (Wet werk en zekerheid). Anything longer would be void.",
      severity: 'low',
      recommendation:
        "No action needed — this is at the legal maximum and is standard practice.",
    },
    {
      clause: "Non-compete clause covering the entire EU for 12 months after termination.",
      risk:
        "EU-wide scope is broad. Dutch courts often narrow non-competes to specific sectors and geographies if challenged. The 12-month duration is enforceable but on the longer side.",
      severity: 'medium',
      recommendation:
        "Ask for a narrower geographic scope (e.g. Benelux or 'cities where company operates') and 6 months. Often granted.",
    },
  ],
  missing_clauses: [
    "No explicit mention of pension scheme — Dutch law typically expects employer pension contributions; verify enrollment timing.",
  ],
  positive_points: [
    "30% ruling correctly applied to gross salary.",
    "Vacation: 25 days, above the statutory minimum of 20.",
    "Transition payment (transitievergoeding) explicitly mentioned for end-of-contract.",
    "Notice period is 1 month for employee, 2 months for employer — fair and standard.",
  ],
  verdict:
    "Safe to sign. Push back on the non-compete scope if you can — but the contract is fundamentally sound.",
};

const OFFICIAL_LETTER_DE: DocumentRisk = {
  risk_level: 'high',
  summary:
    "This is a formal request from the Ausländerbehörde with a hard deadline. Missing it could trigger a rejection of your residence permit application. You need to act within the next 14 days.",
  risks: [
    {
      clause: "You are required to submit the requested documents within 14 days of receipt of this letter.",
      risk:
        "Deadlines from the Ausländerbehörde are legally binding. Missing them can lead to automatic rejection of your application without further notice (§82 AufenthG).",
      severity: 'high',
      recommendation:
        "Calculate the deadline from the date on the letter, not from when you received it. Submit early — the office is closed Wednesdays and Fridays after 12:00.",
    },
    {
      clause:
        "Failure to provide the requested documentation may result in the rejection of your application.",
      risk:
        "Standard administrative warning. Combined with the strict deadline, this is real — not boilerplate.",
      severity: 'high',
      recommendation:
        "Reply with all requested documents. If anything is missing, send a partial response with an explanation rather than nothing at all.",
    },
  ],
  missing_clauses: [],
  positive_points: [
    "The letter lists exactly what documents are needed — no ambiguity to interpret.",
    "Contact name and direct extension are provided — you can call to clarify.",
  ],
  verdict:
    "Don't ignore this. Gather the documents listed, submit before the 14-day deadline, and keep proof of submission (registered post or in-person stamp).",
};

interface AnalyzeRequest {
  text?: string;
  file_url?: string;
  document_type?: string;
  country?: string;
}

export async function POST(req: Request) {
  const body = (await req.json()) as AnalyzeRequest;

  // Simulate analysis time
  await new Promise((r) => setTimeout(r, 1800 + Math.random() * 800));

  // Pick scenario based on document_type
  let result: DocumentRisk;
  switch (body.document_type) {
    case 'employment':
      result = EMPLOYMENT_NL;
      break;
    case 'official_letter':
      result = OFFICIAL_LETTER_DE;
      break;
    case 'rental':
    case 'contract':
    default:
      result = RENTAL_DE;
  }

  return Response.json(result);
}
