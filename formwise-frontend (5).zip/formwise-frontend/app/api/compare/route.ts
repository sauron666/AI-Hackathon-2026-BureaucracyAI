/**
 * MOCK /api/compare — DEMO ONLY
 *
 * Returns a full CountryComparison built from the requested country list.
 * Replace with the spec in AI-CONTEXT-FINAL.md when Dev 2 ships the real
 * generateObject() route.
 */

import { type CountryComparison, COUNTRY_NAMES } from '@/lib/types';

const COUNTRY_PROFILES: Record<
  string,
  {
    summary: string;
    processing_time: string;
    typical_cost: string;
    difficulty: 'easy' | 'moderate' | 'complex';
    key_advantage: string;
    key_disadvantage: string;
  }
> = {
  DE: {
    summary:
      "Germany offers the EU Blue Card for skilled workers earning over €45,300, with a fast-tracked process for shortage occupations. Strong worker protections and access to all of Schengen.",
    processing_time: "6 – 12 weeks",
    typical_cost: "€100 – €200",
    difficulty: 'moderate',
    key_advantage:
      "Predictable process and strong legal protections once approved. Path to permanent residence in 33 months (21 with B1 German).",
    key_disadvantage:
      "Heavy paperwork in German, long Ausländerbehörde appointment waits, and apostilled+translated documents required.",
  },
  NL: {
    summary:
      "The Netherlands has the Highly Skilled Migrant scheme — employers must be IND-recognized sponsors. Fastest route for tech workers; English is widely accepted.",
    processing_time: "2 – 4 weeks",
    typical_cost: "€345",
    difficulty: 'easy',
    key_advantage:
      "Fastest processing in the EU, English-friendly bureaucracy, 30% tax ruling for 5 years.",
    key_disadvantage:
      "Salary thresholds are higher (€5,331/month for under-30s, €7,267/month for 30+) and the housing market is brutal in Amsterdam and Utrecht.",
  },
  PT: {
    summary:
      "Portugal's D7 (passive income) and D8 (digital nomad) visas have made it a top destination. Tech Visa is fast for skilled workers at certified companies.",
    processing_time: "8 – 16 weeks",
    typical_cost: "€150 – €300",
    difficulty: 'moderate',
    key_advantage:
      "NHR tax regime (now restricted but still favorable for some), warm climate, English widely spoken, low cost of living outside Lisbon/Porto.",
    key_disadvantage:
      "AIMA (immigration office) backlogs are notorious — appointments can take 6+ months. Bureaucracy moves slowly even by EU standards.",
  },
  ES: {
    summary:
      "Spain's Beckham Law and digital nomad visa make it attractive for remote workers. Standard work visa requires employer sponsorship and proof the role couldn't be filled by an EU citizen.",
    processing_time: "8 – 12 weeks",
    typical_cost: "€80 – €200",
    difficulty: 'moderate',
    key_advantage:
      "Beckham Law caps tax at 24% for new residents for 6 years; digital nomad visa allows up to 5 years residence.",
    key_disadvantage:
      "NIE/TIE process is appointment-bottlenecked; Spanish proficiency expected at most municipal offices.",
  },
  FR: {
    summary:
      "France's Talent Passport (Passeport Talent) offers 4-year multi-year permits for skilled workers, researchers, and founders. Renewable, includes family.",
    processing_time: "6 – 10 weeks",
    typical_cost: "€225",
    difficulty: 'moderate',
    key_advantage:
      "4-year permit length means fewer renewals; family included automatically; strong career market in tech and finance.",
    key_disadvantage:
      "Process is heavily French-language; OFII medical exam required; some prefectures schedule months out.",
  },
  PL: {
    summary:
      "Poland is increasingly popular for tech workers. Work permit + residence permit are typically employer-sponsored. Lower cost of living than Western EU.",
    processing_time: "10 – 16 weeks",
    typical_cost: "€100 – €150",
    difficulty: 'complex',
    key_advantage:
      "Lowest cost of living among EU tech hubs; fast-growing tech scene in Warsaw, Krakow, Wroclaw.",
    key_disadvantage:
      "Voivode offices are slow and Polish-language only; B1 Polish needed for permanent residence.",
  },
  GE: {
    summary:
      "Georgia (the country) offers visa-free entry to 90+ nationalities for up to 1 year. Simple residency by registering a business or buying property.",
    processing_time: "1 – 4 weeks",
    typical_cost: "€20 – €100",
    difficulty: 'easy',
    key_advantage:
      "Easiest entry in the region; 1% tax for individual entrepreneurs under €155K/year revenue; no language barrier in Tbilisi.",
    key_disadvantage:
      "Not in the EU/Schengen; banking can be tricky for some nationalities; political instability in the region.",
  },
  AT: {
    summary:
      "Austria's Red-White-Red Card uses a points system favoring skilled workers, key occupations, and graduates of Austrian universities.",
    processing_time: "8 – 14 weeks",
    typical_cost: "€160 – €260",
    difficulty: 'moderate',
    key_advantage:
      "Clear points system removes guesswork; high quality of life; central European location.",
    key_disadvantage:
      "German required for many occupations; salary thresholds are high (€3,420+/month for skilled workers).",
  },
  CZ: {
    summary:
      "Czech Republic offers Employee Card for non-EU workers (up to 2 years, renewable) and Blue Card for highly qualified roles.",
    processing_time: "8 – 12 weeks",
    typical_cost: "€100",
    difficulty: 'moderate',
    key_advantage:
      "Lower cost of living than Germany/Austria with EU/Schengen access; growing tech and finance sector.",
    key_disadvantage:
      "Czech-language paperwork; appointment slots at Ministry of the Interior are limited in Prague.",
  },
  BG: {
    summary:
      "Bulgaria offers EU residence with one of the lowest costs of living in the union. Single permit (work + residence) for non-EU workers; Blue Card for highly qualified.",
    processing_time: "10 – 16 weeks",
    typical_cost: "€100 – €150",
    difficulty: 'complex',
    key_advantage:
      "Cheapest path to EU residence; flat 10% income tax; warm climate.",
    key_disadvantage:
      "Bulgarian-language bureaucracy; slower processing; less established expat infrastructure outside Sofia.",
  },
};

// Recommendation logic — picks based on which country has the easiest+fastest combo
function pickRecommendation(countryCodes: string[]): string {
  const haveNL = countryCodes.includes('NL');
  const haveDE = countryCodes.includes('DE');
  const havePT = countryCodes.includes('PT');
  const haveGE = countryCodes.includes('GE');

  if (haveNL) {
    return "If speed and English-friendliness matter most, the Netherlands wins clearly — fastest processing in the EU, the 30% ruling is a real benefit, and you can do everything in English. The catch is the salary threshold and housing market.";
  }
  if (haveDE) {
    return "Germany offers the most predictable long-term path with strong protections, but expect heavy paperwork in German. Best if you're committed for 3+ years.";
  }
  if (havePT) {
    return "Portugal is the best lifestyle choice if you can tolerate AIMA's appointment backlog. The Tech Visa is the fastest entry route.";
  }
  if (haveGE) {
    return "Georgia is the easiest non-EU option — visa-free for most nationalities, 1% tax for entrepreneurs, and quick to set up. Good for digital nomads, less ideal for long-term EU goals.";
  }
  return "Each option has trade-offs. The fastest is typically the Netherlands; the cheapest is typically Bulgaria or Georgia; the most stable long-term is Germany.";
}

interface CompareRequest {
  question?: string;
  countries?: string[];
}

export async function POST(req: Request) {
  const body = (await req.json()) as CompareRequest;
  await new Promise((r) => setTimeout(r, 1800 + Math.random() * 600));

  const codes = (body.countries && body.countries.length > 0
    ? body.countries
    : ['DE', 'NL', 'PT', 'ES']
  ).slice(0, 5);

  const result: CountryComparison = {
    question_interpreted:
      body.question ||
      "Which European country offers the best path for skilled workers from outside the EU?",
    countries: codes.map((code) => {
      const profile =
        COUNTRY_PROFILES[code] || {
          summary: `${COUNTRY_NAMES[code] || code}: limited information in the demo dataset for this country.`,
          processing_time: 'Varies',
          typical_cost: 'Varies',
          difficulty: 'moderate' as const,
          key_advantage: 'EU/regional access',
          key_disadvantage: 'Specific path details vary',
        };
      return {
        country_code: code,
        country_name: COUNTRY_NAMES[code] || code,
        ...profile,
      };
    }),
    recommendation: pickRecommendation(codes),
  };

  return Response.json(result);
}
