'use client';

import Link from 'next/link';
import { useState } from 'react';
import {
  FileText,
  Clock,
  CheckCircle2,
  TrendingUp,
  Sparkles,
  X,
  ArrowRight,
  MessageSquare,
  Upload,
  FolderOpen,
  HelpCircle,
  Home,
  Briefcase,
  Building2,
  Calendar,
  MapPin,
} from 'lucide-react';
import { useMockUser, useSavedAnswers, useLocalStorage } from '@/lib/storage';
import { cn } from '@/lib/utils';

interface Stat {
  label: string;
  value: string | number;
  sub: string;
  icon: React.ElementType;
  tone: 'primary' | 'amber' | 'sage' | 'azure';
}

interface OngoingProcess {
  id: string;
  title: string;
  status: 'In Progress' | 'Waiting' | 'Completed';
  date: string;
  location?: string;
  next: string;
  progress: number;
  icon: React.ElementType;
  iconTone: 'primary' | 'amber' | 'sage' | 'azure';
}

const ONGOING: OngoingProcess[] = [
  {
    id: 'p1',
    title: 'Residence Permit Application',
    status: 'In Progress',
    date: 'Dec 15, 2025',
    location: 'Migration Office',
    next: 'Submit biometric data',
    progress: 65,
    icon: Home,
    iconTone: 'azure',
  },
  {
    id: 'p2',
    title: 'Business Registration',
    status: 'Waiting',
    date: 'Dec 20, 2025',
    next: 'Waiting for document approval',
    progress: 40,
    icon: Briefcase,
    iconTone: 'amber',
  },
  {
    id: 'p3',
    title: 'Tax ID Application',
    status: 'In Progress',
    date: 'Dec 22, 2025',
    location: 'Tax Office',
    next: 'Collect final document',
    progress: 85,
    icon: Building2,
    iconTone: 'sage',
  },
];

const RECENT = [
  {
    id: 'r1',
    icon: MessageSquare,
    tone: 'primary' as const,
    title: 'Asked about residence permit renewal',
    body: 'How do I renew my residence permit before it expires?',
    when: '2 hours ago',
  },
  {
    id: 'r2',
    icon: FileText,
    tone: 'amber' as const,
    title: 'Uploaded passport scan',
    body: '',
    when: 'Yesterday',
  },
  {
    id: 'r3',
    icon: CheckCircle2,
    tone: 'sage' as const,
    title: 'Completed address registration',
    body: '',
    when: '3 days ago',
  },
  {
    id: 'r4',
    icon: MessageSquare,
    tone: 'primary' as const,
    title: 'Asked about work permit requirements',
    body: 'What documents do I need to apply for a work permit?',
    when: '1 week ago',
  },
];

const QUICK = [
  {
    href: '/dashboard/ask',
    icon: MessageSquare,
    tone: 'primary' as const,
    title: 'Ask a Question',
    body: 'Get instant answers about any procedure',
  },
  {
    href: '/dashboard/ask',
    icon: Upload,
    tone: 'amber' as const,
    title: 'Upload Document',
    body: 'Analyze documents for guidance',
  },
  {
    href: '/dashboard/browse',
    icon: FolderOpen,
    tone: 'sage' as const,
    title: 'Browse Guides',
    body: 'Explore procedure categories',
  },
  {
    href: '/dashboard/history',
    icon: HelpCircle,
    tone: 'azure' as const,
    title: 'Get Help',
    body: 'Tips and support resources',
  },
];

const TONE_BG: Record<string, string> = {
  primary: 'bg-primary/15 text-primary',
  amber:   'bg-[oklch(0.92_0.05_75)] text-[oklch(0.55_0.15_65)] dark:bg-[oklch(0.30_0.08_75)] dark:text-[oklch(0.78_0.14_65)]',
  sage:    'bg-accent/15 text-accent',
  azure:   'bg-[oklch(0.92_0.04_235)] text-[oklch(0.55_0.16_235)] dark:bg-[oklch(0.30_0.08_235)] dark:text-[oklch(0.75_0.13_235)]',
};

const STATUS_TONE: Record<OngoingProcess['status'], string> = {
  'In Progress': 'bg-primary/10 text-primary border-primary/20',
  'Waiting':     'bg-[oklch(0.95_0.03_75)] text-[oklch(0.45_0.13_65)] border-[oklch(0.85_0.05_75)] dark:bg-[oklch(0.25_0.06_75)] dark:text-[oklch(0.78_0.14_65)] dark:border-[oklch(0.40_0.08_75)]',
  'Completed':   'bg-accent/10 text-accent border-accent/20',
};

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

export default function DashboardHomePage() {
  const { user } = useMockUser();
  const { saved } = useSavedAnswers();
  const [welcomeDismissed, setWelcomeDismissed] = useLocalStorage<boolean>(
    'formwise:welcome-dismissed',
    false,
  );

  const documentsAnalyzed = 12 + saved.length;
  const proceduresTracked = ONGOING.filter((p) => p.status !== 'Completed').length;
  const completed = 5;
  const timeSaved = '8h';

  const stats: Stat[] = [
    {
      label: 'Documents Analyzed',
      value: documentsAnalyzed,
      sub: 'Total analyses',
      icon: FileText,
      tone: 'primary',
    },
    {
      label: 'Procedures Tracked',
      value: proceduresTracked,
      sub: 'In progress',
      icon: Clock,
      tone: 'amber',
    },
    {
      label: 'Completed',
      value: completed,
      sub: 'All time',
      icon: CheckCircle2,
      tone: 'sage',
    },
    {
      label: 'Time Saved',
      value: timeSaved,
      sub: 'Hours estimated',
      icon: TrendingUp,
      tone: 'sage',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Greeting + New question CTA */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-foreground">
            {getGreeting()}, {user?.name || user?.email}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Here's an overview of your bureaucratic journey.
          </p>
        </div>
        <Link
          href="/dashboard/ask"
          className={cn(
            'inline-flex items-center gap-1.5 rounded-md',
            'bg-primary text-primary-foreground shadow-brand',
            'px-4 py-2 text-sm font-semibold',
            'transition-all hover:shadow-brand-strong active:scale-[0.98]',
          )}
        >
          <Sparkles size={14} strokeWidth={2.25} />
          New Question
          <ArrowRight size={13} strokeWidth={2.25} />
        </Link>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div
              key={s.label}
              className={cn(
                'relative rounded-xl border border-border bg-card p-5',
                'overflow-hidden',
              )}
            >
              {/* Soft gradient backdrop */}
              <div
                className={cn(
                  'absolute -right-6 -top-6 h-24 w-24 rounded-full blur-2xl opacity-50',
                  s.tone === 'primary' && 'bg-primary/30',
                  s.tone === 'amber'   && 'bg-[oklch(0.85_0.13_75)]',
                  s.tone === 'sage'    && 'bg-accent/30',
                  s.tone === 'azure'   && 'bg-[oklch(0.80_0.12_235)]',
                )}
                aria-hidden
              />
              <div className="relative flex items-start justify-between gap-3">
                <div className="space-y-1.5">
                  <div className="text-xs font-medium text-muted-foreground">
                    {s.label}
                  </div>
                  <div className="text-3xl font-bold text-foreground tabular-nums">
                    {s.value}
                  </div>
                  <div className="text-xs text-muted-foreground">{s.sub}</div>
                </div>
                <span
                  className={cn(
                    'flex h-9 w-9 items-center justify-center rounded-lg',
                    TONE_BG[s.tone],
                  )}
                  aria-hidden
                >
                  <Icon size={16} strokeWidth={2} />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Welcome banner (dismissible) */}
      {!welcomeDismissed && (
        <div
          className={cn(
            'relative rounded-xl border border-accent/20',
            'bg-gradient-to-r from-accent/5 via-primary/5 to-accent/5',
            'p-5',
          )}
        >
          <button
            type="button"
            onClick={() => setWelcomeDismissed(true)}
            aria-label="Dismiss welcome message"
            className={cn(
              'absolute right-3 top-3 h-7 w-7 inline-flex items-center justify-center',
              'rounded-md text-muted-foreground hover:bg-secondary transition-colors',
            )}
          >
            <X size={14} strokeWidth={2} />
          </button>
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <Sparkles
                size={17}
                strokeWidth={2.25}
                className="mt-0.5 text-accent shrink-0"
                aria-hidden
              />
              <div className="space-y-1">
                <div className="text-sm font-semibold text-foreground">
                  Welcome to FormWise!
                </div>
                <p className="text-xs text-muted-foreground max-w-xl">
                  Ask our AI assistant about any bureaucratic process and get step-by-step guidance.
                </p>
              </div>
            </div>
            <Link
              href="/dashboard/ask"
              className={cn(
                'inline-flex items-center gap-1.5 rounded-md',
                'bg-primary text-primary-foreground shadow-brand',
                'px-3.5 py-1.5 text-xs font-semibold',
                'transition-all hover:shadow-brand-strong',
              )}
            >
              Get Started <ArrowRight size={11} strokeWidth={2.25} />
            </Link>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <section className="space-y-3">
        <h2 className="text-base font-semibold text-foreground">Quick Actions</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {QUICK.map((q) => {
            const Icon = q.icon;
            return (
              <Link
                key={q.title}
                href={q.href}
                className={cn(
                  'group rounded-xl border border-border bg-card p-4',
                  'transition-all hover:border-primary/30 hover:shadow-md',
                )}
              >
                <span
                  className={cn(
                    'flex h-10 w-10 items-center justify-center rounded-lg',
                    TONE_BG[q.tone],
                  )}
                  aria-hidden
                >
                  <Icon size={17} strokeWidth={2} />
                </span>
                <div className="mt-3">
                  <div className="text-sm font-semibold text-foreground">{q.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{q.body}</div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Ongoing + Recent (two-column) */}
      <div className="grid lg:grid-cols-2 gap-5">
        {/* Ongoing Processes */}
        <section
          className={cn(
            'rounded-xl border border-border bg-card p-5 space-y-4',
          )}
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-foreground">Ongoing Processes</h2>
            <Link
              href="/dashboard/history"
              className="text-xs text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-1"
            >
              View all <ArrowRight size={11} strokeWidth={2.25} />
            </Link>
          </div>
          <div className="space-y-3">
            {ONGOING.map((p) => {
              const Icon = p.icon;
              return (
                <div
                  key={p.id}
                  className={cn(
                    'rounded-lg border border-border bg-secondary/20 p-3 space-y-2',
                  )}
                >
                  <div className="flex items-start gap-3">
                    <span
                      className={cn(
                        'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg',
                        TONE_BG[p.iconTone],
                      )}
                      aria-hidden
                    >
                      <Icon size={15} strokeWidth={2} />
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold text-foreground">
                          {p.title}
                        </span>
                        <span
                          className={cn(
                            'inline-flex rounded-full border px-2 py-0.5',
                            'text-[10px] font-semibold uppercase tracking-wide',
                            STATUS_TONE[p.status],
                          )}
                        >
                          {p.status}
                        </span>
                      </div>
                      <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground">
                        <span className="inline-flex items-center gap-1">
                          <Calendar size={10} strokeWidth={2} />
                          {p.date}
                        </span>
                        {p.location && (
                          <span className="inline-flex items-center gap-1">
                            <MapPin size={10} strokeWidth={2} />
                            {p.location}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">
                        Progress
                      </div>
                      <div className="text-sm font-bold text-foreground">{p.progress}%</div>
                    </div>
                  </div>
                  <div
                    className="h-1.5 w-full overflow-hidden rounded-full bg-border"
                    role="progressbar"
                    aria-valuenow={p.progress}
                  >
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${p.progress}%` }}
                    />
                  </div>
                  <div className="text-xs text-muted-foreground">
                    <span className="font-semibold text-foreground">Next:</span>{' '}
                    {p.next}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Recent Activity */}
        <section
          className={cn(
            'rounded-xl border border-border bg-card p-5 space-y-4',
          )}
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-foreground">Recent Activity</h2>
            <Link
              href="/dashboard/history"
              className="text-xs text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-1"
            >
              View all <ArrowRight size={11} strokeWidth={2.25} />
            </Link>
          </div>
          <ul className="space-y-3">
            {RECENT.map((r) => {
              const Icon = r.icon;
              return (
                <li key={r.id} className="flex items-start gap-3">
                  <span
                    className={cn(
                      'flex h-8 w-8 shrink-0 items-center justify-center rounded-full',
                      TONE_BG[r.tone],
                    )}
                    aria-hidden
                  >
                    <Icon size={13} strokeWidth={2} />
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-foreground">{r.title}</div>
                    {r.body && (
                      <div className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                        {r.body}
                      </div>
                    )}
                    <div className="text-[10px] text-muted-foreground mt-0.5">{r.when}</div>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      </div>
    </div>
  );
}
