'use client';

import { useState } from 'react';
import ChatInterface from '@/components/ChatInterface';
import { type Country, type Language } from '@/lib/types';

export default function AskPage() {
  const [country] = useState<Country>('BG');
  const [language] = useState<Language>('en');

  return (
    <div className="space-y-2">
      <h1 className="text-3xl font-bold tracking-tight text-foreground">Ask FormWise</h1>
      <p className="text-sm text-muted-foreground">
        Ask any question about bureaucratic procedures and get step-by-step guidance.
      </p>
      <div className="pt-6">
        <ChatInterface country={country} language={language} />
      </div>
    </div>
  );
}
