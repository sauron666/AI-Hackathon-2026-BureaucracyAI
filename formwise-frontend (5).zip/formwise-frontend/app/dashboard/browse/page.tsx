'use client';

import Link from 'next/link';
import {
  Home,
  Briefcase,
  Building2,
  Heart,
  GraduationCap,
  Car,
  Plane,
  Banknote,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Category {
  slug: string;
  title: string;
  body: string;
  count: number;
  icon: React.ElementType;
  tone: 'azure' | 'amber' | 'plum' | 'rose' | 'sage' | 'orange' | 'cyan' | 'green';
}

const CATEGORIES: Category[] = [
  { slug: 'residency', title: 'Residency & Visas', body: 'Residence permits, visa applications, and...', count: 12, icon: Home, tone: 'azure' },
  { slug: 'work',      title: 'Work Permits',      body: 'Employment authorization and work-related permits', count: 8, icon: Briefcase, tone: 'amber' },
  { slug: 'business',  title: 'Business & Company', body: 'Company registration, business licenses, and...', count: 15, icon: Building2, tone: 'plum' },
  { slug: 'health',    title: 'Healthcare',        body: 'Health insurance, medical registration, and...', count: 6, icon: Heart, tone: 'rose' },
  { slug: 'education', title: 'Education',         body: 'School enrollment, university applications,...', count: 9, icon: GraduationCap, tone: 'sage' },
  { slug: 'driving',   title: 'Driving & Vehicles', body: "Driver's license, vehicle registration, and traffic...", count: 7, icon: Car, tone: 'orange' },
  { slug: 'travel',    title: 'Travel & Documents', body: 'Passport, travel documents, and...', count: 5, icon: Plane, tone: 'cyan' },
  { slug: 'finance',   title: 'Finance & Tax',      body: 'Tax IDs, bank accounts, and financial filings', count: 11, icon: Banknote, tone: 'green' },
];

const TONE: Record<Category['tone'], string> = {
  azure:  'bg-[oklch(0.92_0.04_235)] text-[oklch(0.50_0.16_235)] dark:bg-[oklch(0.30_0.08_235)] dark:text-[oklch(0.75_0.13_235)]',
  amber:  'bg-[oklch(0.92_0.05_75)]  text-[oklch(0.55_0.15_65)]  dark:bg-[oklch(0.30_0.08_75)]  dark:text-[oklch(0.78_0.14_65)]',
  plum:   'bg-[oklch(0.92_0.06_320)] text-[oklch(0.50_0.18_320)] dark:bg-[oklch(0.30_0.08_320)] dark:text-[oklch(0.75_0.14_320)]',
  rose:   'bg-[oklch(0.94_0.04_15)]  text-[oklch(0.55_0.18_25)]  dark:bg-[oklch(0.30_0.08_15)]  dark:text-[oklch(0.75_0.14_15)]',
  sage:   'bg-accent/15 text-accent',
  orange: 'bg-[oklch(0.92_0.06_45)]  text-[oklch(0.55_0.16_35)]  dark:bg-[oklch(0.30_0.08_45)]  dark:text-[oklch(0.75_0.14_45)]',
  cyan:   'bg-[oklch(0.92_0.04_205)] text-[oklch(0.50_0.13_205)] dark:bg-[oklch(0.30_0.08_205)] dark:text-[oklch(0.75_0.13_205)]',
  green:  'bg-[oklch(0.92_0.05_145)] text-[oklch(0.45_0.13_145)] dark:bg-[oklch(0.30_0.07_145)] dark:text-[oklch(0.75_0.13_145)]',
};

export default function BrowsePage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">
            Browse Procedures
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Explore all available bureaucratic procedures by category.
          </p>
        </div>
        <Link
          href="/dashboard/ask"
          className={cn(
            'inline-flex items-center gap-1.5 rounded-md',
            'border border-border bg-card',
            'px-3 py-1.5 text-xs font-semibold text-foreground',
            'transition-all hover:border-primary/40 hover:shadow-md',
          )}
        >
          <Sparkles size={11} strokeWidth={2.25} className="text-primary" />
          Ask AI Instead
        </Link>
      </div>

      {/* More countries banner */}
      <div
        className={cn(
          'rounded-xl border border-accent/30 bg-accent/5 p-5 space-y-1',
        )}
      >
        <div className="text-sm font-semibold text-accent">
          More Countries Coming Soon
        </div>
        <p className="text-xs text-muted-foreground">
          We're expanding to cover more countries. Currently featuring procedures for 18
          European countries, with Brazil, India, and the US launching this year.
        </p>
      </div>

      {/* Category grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {CATEGORIES.map((c) => {
          const Icon = c.icon;
          return (
            <Link
              key={c.slug}
              href={`/dashboard/ask?category=${c.slug}`}
              className={cn(
                'group rounded-xl border border-border bg-card p-5 space-y-3',
                'transition-all hover:border-primary/30 hover:shadow-lg',
              )}
            >
              <span
                className={cn(
                  'flex h-11 w-11 items-center justify-center rounded-lg',
                  TONE[c.tone],
                )}
                aria-hidden
              >
                <Icon size={19} strokeWidth={2} />
              </span>
              <div>
                <h3 className="text-sm font-semibold text-foreground">{c.title}</h3>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2 leading-relaxed">
                  {c.body}
                </p>
              </div>
              <span
                className={cn(
                  'inline-flex items-center rounded-full',
                  'bg-secondary px-2 py-0.5 text-[10px] font-semibold',
                  'text-muted-foreground',
                )}
              >
                {c.count} procedures
              </span>
            </Link>
          );
        })}
      </div>

      {/* Floating "Can't find what you need?" card */}
      <Link
        href="/dashboard/ask"
        className={cn(
          'fixed bottom-5 right-5 z-30',
          'inline-flex items-center gap-2 rounded-full',
          'bg-card border border-border shadow-lg backdrop-blur-sm',
          'pl-4 pr-2 py-2 text-xs',
          'transition-all hover:scale-105 hover:border-primary/40',
        )}
      >
        <span className="text-muted-foreground">Can't find what you need?</span>
        <span
          className={cn(
            'inline-flex items-center gap-1 rounded-full',
            'bg-primary text-primary-foreground',
            'px-2.5 py-1 text-[11px] font-semibold',
          )}
        >
          Ask AI <ArrowRight size={10} strokeWidth={2.5} />
        </span>
      </Link>
    </div>
  );
}
