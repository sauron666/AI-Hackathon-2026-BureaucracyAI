'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import AppSidebar from '@/components/dashboard/AppSidebar';
import PalettePicker from '@/components/dashboard/PalettePicker';
import ThemeToggle from '@/components/ThemeToggle';
import { useMockUser } from '@/lib/storage';
import {
  COUNTRY_NAMES,
  COUNTRY_FLAGS,
  type Country,
} from '@/lib/types';
import { cn } from '@/lib/utils';

const COUNTRIES: Country[] = ['BG', 'DE', 'NL', 'PT', 'ES', 'FR', 'PL', 'CZ', 'AT', 'SE', 'GE', 'RS', 'GB', 'CH', 'UA', 'HR', 'GR', 'RO'];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { user, isHydrated } = useMockUser();
  const [country, setCountry] = useState<Country>('BG');

  // Auth gate: bounce unauthenticated users to /login
  useEffect(() => {
    if (isHydrated && !user) {
      router.replace('/login');
    }
  }, [isHydrated, user, router]);

  if (!isHydrated || !user) {
    // Hydration flash guard — show nothing until we know the auth state
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-sm text-muted-foreground">Loading…</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />

      {/* Top-right widget with theme + palette + country */}
      <div
        className={cn(
          'fixed top-0 right-0 z-20 h-16 flex items-center gap-1.5 px-4 sm:px-6',
          'bg-transparent',
        )}
      >
        <ThemeToggle />
        <PalettePicker />
        <select
          value={country}
          onChange={(e) => setCountry(e.target.value as Country)}
          aria-label="Country"
          className={cn(
            'h-9 rounded-md border border-border bg-card px-2.5 text-sm',
            'text-foreground hover:border-primary/40 transition-colors',
            'focus:outline-none focus:ring-2 focus:ring-ring/40',
          )}
        >
          {COUNTRIES.map((c) => (
            <option key={c} value={c}>
              {COUNTRY_FLAGS[c]} {COUNTRY_NAMES[c]}
            </option>
          ))}
        </select>
      </div>

      {/* Content area, offset by sidebar on lg+ */}
      <main className="lg:pl-64 pt-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-8">
          {children}
        </div>
      </main>
    </div>
  );
}
