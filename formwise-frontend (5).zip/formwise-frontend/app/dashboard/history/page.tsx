'use client';

import Link from 'next/link';
import { useState, useMemo } from 'react';
import {
  Search,
  MessageSquare,
  FileText,
  ArrowRight,
  Calendar,
  Plus,
} from 'lucide-react';
import { useSavedAnswers } from '@/lib/storage';
import { cn } from '@/lib/utils';

type Status = 'Completed' | 'In Progress';
type Kind = 'question' | 'document';

interface HistoryEntry {
  id: string;
  title: string;
  body: string;
  status: Status;
  kind: Kind;
  date: string;
  ts: number;
}

const MOCK_HISTORY: HistoryEntry[] = [
  {
    id: 'h1',
    title: 'Residence Permit Renewal',
    body: 'How do I renew my residence permit before it expires in Bulgaria?',
    status: 'Completed',
    kind: 'question',
    date: 'Dec 10, 2025',
    ts: Date.now() - 1000 * 60 * 60 * 24 * 1,
  },
  {
    id: 'h2',
    title: 'Passport Scan Analysis',
    body: 'Analyzed passport document for validity check',
    status: 'Completed',
    kind: 'document',
    date: 'Dec 8, 2025',
    ts: Date.now() - 1000 * 60 * 60 * 24 * 3,
  },
  {
    id: 'h3',
    title: 'Work Permit Requirements',
    body: 'What documents do I need to apply for a work permit in Bulgaria?',
    status: 'In Progress',
    kind: 'question',
    date: 'Dec 5, 2025',
    ts: Date.now() - 1000 * 60 * 60 * 24 * 7,
  },
  {
    id: 'h4',
    title: 'Business Registration',
    body: 'How to register a company as a foreigner?',
    status: 'Completed',
    kind: 'question',
    date: 'Nov 28, 2025',
    ts: Date.now() - 1000 * 60 * 60 * 24 * 14,
  },
  {
    id: 'h5',
    title: 'Bank Statement Review',
    body: 'Analyzed bank statement for visa application',
    status: 'Completed',
    kind: 'document',
    date: 'Nov 25, 2025',
    ts: Date.now() - 1000 * 60 * 60 * 24 * 21,
  },
];

const TABS: { id: 'all' | Kind; label: string }[] = [
  { id: 'all',      label: 'All' },
  { id: 'question', label: 'Questions' },
  { id: 'document', label: 'Documents' },
];

const STATUS_TONE: Record<Status, string> = {
  'Completed':   'bg-accent/10 text-accent border-accent/20',
  'In Progress': 'bg-[oklch(0.95_0.04_75)] text-[oklch(0.45_0.13_65)] border-[oklch(0.85_0.05_75)] dark:bg-[oklch(0.25_0.06_75)] dark:text-[oklch(0.78_0.14_65)] dark:border-[oklch(0.40_0.08_75)]',
};

export default function HistoryPage() {
  const { saved } = useSavedAnswers();
  const [tab, setTab] = useState<'all' | Kind>('all');
  const [query, setQuery] = useState('');

  // Merge real saved answers with mock history
  const allEntries: HistoryEntry[] = useMemo(() => {
    const fromSaved: HistoryEntry[] = saved.map((s) => ({
      id: s.id,
      title: s.question,
      body: s.summary || '',
      status: 'Completed' as Status,
      kind: 'question' as Kind,
      date: new Date(s.savedAt).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
      ts: s.savedAt,
    }));
    return [...fromSaved, ...MOCK_HISTORY].sort((a, b) => b.ts - a.ts);
  }, [saved]);

  const filtered = useMemo(() => {
    let list = allEntries;
    if (tab !== 'all') list = list.filter((e) => e.kind === tab);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (e) =>
          e.title.toLowerCase().includes(q) || e.body.toLowerCase().includes(q),
      );
    }
    return list;
  }, [allEntries, tab, query]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">History</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Every question you've asked and document you've analyzed.
        </p>
      </div>

      {/* Search */}
      <div
        className={cn(
          'flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2',
          'focus-within:border-primary/40 transition-colors',
        )}
      >
        <Search size={15} strokeWidth={2} className="text-muted-foreground shrink-0" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search history…"
          className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
        />
      </div>

      {/* Tabs */}
      <div
        className={cn(
          'inline-flex gap-1 p-1 rounded-lg bg-secondary/60 border border-border',
        )}
      >
        {TABS.map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={cn(
                'rounded-md px-4 py-1.5 text-xs font-semibold',
                'transition-colors',
                active
                  ? 'bg-card text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {/* List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
            No history matches your search.
          </div>
        ) : (
          filtered.map((e) => {
            const Icon = e.kind === 'document' ? FileText : MessageSquare;
            return (
              <div
                key={e.id}
                className={cn(
                  'group flex items-start gap-3 rounded-xl border border-border bg-card p-4',
                  'transition-all hover:border-primary/30 hover:shadow-md',
                )}
              >
                <span
                  className={cn(
                    'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg',
                    e.kind === 'document'
                      ? 'bg-[oklch(0.92_0.05_75)] text-[oklch(0.55_0.15_65)] dark:bg-[oklch(0.30_0.08_75)] dark:text-[oklch(0.78_0.14_65)]'
                      : 'bg-accent/15 text-accent',
                  )}
                  aria-hidden
                >
                  <Icon size={15} strokeWidth={2} />
                </span>
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-semibold text-foreground">
                      {e.title}
                    </span>
                    <span
                      className={cn(
                        'inline-flex rounded-full border px-2 py-0.5',
                        'text-[10px] font-semibold uppercase tracking-wide',
                        STATUS_TONE[e.status],
                      )}
                    >
                      {e.status}
                    </span>
                  </div>
                  {e.body && (
                    <p className="text-xs text-muted-foreground line-clamp-2">{e.body}</p>
                  )}
                  <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                    <Calendar size={10} strokeWidth={2} />
                    {e.date}
                  </div>
                </div>
                <ArrowRight
                  size={14}
                  strokeWidth={2}
                  className="mt-3 shrink-0 text-muted-foreground transition-all group-hover:translate-x-0.5 group-hover:text-primary"
                  aria-hidden
                />
              </div>
            );
          })
        )}
      </div>

      {/* Bottom CTA */}
      <div className="pt-2 flex justify-center">
        <Link
          href="/dashboard/ask"
          className={cn(
            'inline-flex items-center gap-1.5 rounded-md',
            'border border-border bg-card',
            'px-4 py-2 text-sm font-semibold text-foreground',
            'transition-all hover:border-primary/40 hover:shadow-md',
          )}
        >
          <Plus size={13} strokeWidth={2.25} />
          Ask a new question
        </Link>
      </div>
    </div>
  );
}
