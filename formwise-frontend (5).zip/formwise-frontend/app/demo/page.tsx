'use client';

import { useState, useCallback } from 'react';
import {
  MessageSquare,
  CalendarDays,
  Scale,
  Upload,
} from 'lucide-react';
import Header from '@/components/Header';
import ChatInterface, { type ChatRunSignal } from '@/components/ChatInterface';
import JourneyPlanner, { type JourneyRunSignal } from '@/components/JourneyPlanner';
import CountryCompare, { type CompareRunSignal } from '@/components/CountryCompare';
import UploadAnalyze, { type AnalyzeRunSignal } from '@/components/UploadAnalyze';
import DemoDrawer, { type DemoSelection } from '@/components/DemoDrawer';
import SavedDrawer from '@/components/SavedDrawer';
import Onboarding from '@/components/Onboarding';
import { type AppMode, type Country, type Language } from '@/lib/types';
import { type SavedAnswer } from '@/lib/storage';
import { cn } from '@/lib/utils';

type Mode = Extract<AppMode, 'chat' | 'journey' | 'compare' | 'analyze'>;

const MODES: { id: Mode; label: string; icon: React.ReactNode }[] = [
  { id: 'chat',    label: 'Ask',             icon: <MessageSquare size={15} strokeWidth={2} /> },
  { id: 'journey', label: 'Relocation plan', icon: <CalendarDays  size={15} strokeWidth={2} /> },
  { id: 'compare', label: 'Compare',         icon: <Scale         size={15} strokeWidth={2} /> },
  { id: 'analyze', label: 'Analyze doc',     icon: <Upload        size={15} strokeWidth={2} /> },
];

export default function HomePage() {
  const [mode, setMode] = useState<Mode>('chat');
  const [country, setCountry] = useState<Country>('DE');
  const [language, setLanguage] = useState<Language>('en');

  // One signal per child — incrementing nonce makes the child re-run.
  const [chatSignal, setChatSignal] = useState<ChatRunSignal | null>(null);
  const [journeySignal, setJourneySignal] = useState<JourneyRunSignal | null>(null);
  const [compareSignal, setCompareSignal] = useState<CompareRunSignal | null>(null);
  const [analyzeSignal, setAnalyzeSignal] = useState<AnalyzeRunSignal | null>(null);

  // Demo selection → switch country/mode + emit run signal for the target child
  const handleDemoSelect = useCallback((demo: DemoSelection) => {
    const nonce = Date.now();

    if (demo.country) setCountry(demo.country as Country);
    setMode(demo.mode);

    if (demo.mode === 'chat' && demo.question) {
      setChatSignal({ nonce, question: demo.question });
    } else if (demo.mode === 'journey') {
      setJourneySignal({
        nonce,
        fromCountry: demo.fromCountry ?? '',
        nationality: demo.nationality ?? '',
        purpose: (demo.purpose as JourneyRunSignal['purpose']) ?? 'work',
      });
    } else if (demo.mode === 'compare') {
      setCompareSignal({
        nonce,
        question: demo.question ?? '',
        countries: (demo.countries as Country[]) ?? ['DE', 'NL', 'PT', 'ES'],
      });
    } else if (demo.mode === 'analyze') {
      setAnalyzeSignal({
        nonce,
        documentType: demo.documentType ?? 'rental',
      });
    }
  }, []);

  // Re-open saved answer = switch to chat + auto-submit the question
  const handleReopenSaved = useCallback((entry: SavedAnswer) => {
    if (entry.country) setCountry(entry.country as Country);
    setMode('chat');
    setChatSignal({ nonce: Date.now(), question: entry.question });
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header
        country={country}
        language={language}
        onCountryChange={setCountry}
        onLanguageChange={setLanguage}
      />

      <main className="pt-16">
        {/* Mode tabs */}
        <div className="border-b border-border/50 bg-background/60 backdrop-blur-sm sticky top-16 z-20">
          <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
            <nav
              role="tablist"
              aria-label="App modes"
              className="flex gap-1 -mb-px overflow-x-auto"
            >
              {MODES.map((m) => {
                const active = mode === m.id;
                return (
                  <button
                    key={m.id}
                    role="tab"
                    aria-selected={active}
                    onClick={() => setMode(m.id)}
                    className={cn(
                      'inline-flex items-center gap-2 px-4 py-3 text-sm font-medium',
                      'border-b-2 transition-all whitespace-nowrap',
                      active
                        ? 'border-primary text-foreground'
                        : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border',
                    )}
                  >
                    {m.icon}
                    <span>{m.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
          {mode === 'chat' && (
            <ChatInterface
              country={country}
              language={language}
              runSignal={chatSignal}
            />
          )}
          {mode === 'journey' && (
            <JourneyPlanner
              country={country}
              language={language}
              runSignal={journeySignal}
            />
          )}
          {mode === 'compare' && (
            <CountryCompare runSignal={compareSignal} />
          )}
          {mode === 'analyze' && (
            <UploadAnalyze country={country} runSignal={analyzeSignal} />
          )}
        </div>
      </main>

      {/* Demo launcher (DEMO_MODE only) */}
      <DemoDrawer onSelect={handleDemoSelect} />

      {/* Saved answers tray (always available) */}
      <SavedDrawer onReopen={handleReopenSaved} />

      {/* First-visit Clippy tour */}
      <Onboarding />
    </div>
  );
}
