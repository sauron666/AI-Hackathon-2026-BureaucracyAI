import type { Metadata, Viewport } from 'next';
import './globals.css';

/**
 * Note on fonts: Next 14.2.3's `next/font/google` doesn't export `Geist`
 * yet (it was added to Google Fonts later). We rely on the CSS `@import`
 * in `globals.css`, which matches the FormWise design system's own setup.
 * If you upgrade Next, you can swap to `next/font/google` for self-hosting.
 */

export const metadata: Metadata = {
  title: {
    default: 'FormWise — Navigate bureaucracy without the headache',
    template: '%s · FormWise',
  },
  description:
    'AI-powered guidance for any government procedure across 15+ European countries. Upload contracts, flag risky clauses, never miss a deadline.',
  applicationName: 'FormWise',
  icons: {
    icon: '/favicon.png',
    apple: '/apple-icon.png',
  },
  openGraph: {
    title: 'FormWise — Navigate bureaucracy without the headache',
    description:
      'Step-by-step guidance for any government procedure across 15+ European countries.',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#fbf7f0' },
    { media: '(prefers-color-scheme: dark)',  color: '#1a1612' },
  ],
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
