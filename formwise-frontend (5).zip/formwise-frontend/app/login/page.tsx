'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState, type FormEvent } from 'react';
import { ArrowRight, Eye, EyeOff } from 'lucide-react';
import ClippyMascot from '@/components/ClippyMascot';
import ThemeToggle from '@/components/ThemeToggle';
import { useMockUser } from '@/lib/storage';
import { cn } from '@/lib/utils';

export default function LoginPage() {
  const router = useRouter();
  const { signIn } = useMockUser();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const canSubmit = email.includes('@') && password.length >= 4;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    signIn(email);
    setTimeout(() => router.push('/dashboard'), 200);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="flex items-center justify-between px-4 sm:px-6 lg:px-8 py-4">
        <Link href="/" className="inline-flex items-center gap-2.5">
          <ClippyMascot size={22} mood="static" ariaLabel="" />
          <span className="text-lg font-bold tracking-tight text-foreground">FormWise</span>
        </Link>
        <ThemeToggle />
      </header>

      <main className="flex-1 flex items-start sm:items-center justify-center px-4 py-8">
        <div
          className={cn(
            'w-full max-w-md rounded-2xl border border-border bg-card shadow-xl',
            'p-6 sm:p-8 space-y-6',
          )}
        >
          <div className="text-center space-y-1">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
              Welcome back
            </h1>
            <p className="text-sm text-muted-foreground">Sign in to continue your journey</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <label className="block space-y-1.5">
              <span className="text-sm font-semibold text-foreground">Email</span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
                required
                className={cn(
                  'h-11 w-full rounded-md border border-border bg-card px-3 text-sm',
                  'text-foreground placeholder:text-muted-foreground/70',
                  'focus:outline-none focus:ring-2 focus:ring-ring/40 focus:border-primary/40',
                )}
              />
            </label>

            {/* Password with show/hide toggle */}
            <label className="block space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-foreground">Password</span>
                <button
                  type="button"
                  onClick={() => alert('Demo mode — no real password to recover.')}
                  className="text-[11px] font-medium text-primary hover:underline"
                >
                  Forgot?
                </button>
              </div>
              <div
                className={cn(
                  'relative flex items-center rounded-md border border-border bg-card',
                  'transition-colors focus-within:ring-2 focus-within:ring-ring/40 focus-within:border-primary/40',
                )}
              >
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••"
                  autoComplete="current-password"
                  required
                  minLength={4}
                  className={cn(
                    'h-11 w-full bg-transparent px-3 pr-10 text-sm',
                    'text-foreground placeholder:text-muted-foreground/70',
                    'focus:outline-none',
                  )}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className={cn(
                    'absolute right-1 h-9 w-9 inline-flex items-center justify-center rounded-md',
                    'text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors',
                  )}
                >
                  {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </label>

            <button
              type="submit"
              disabled={submitting || !canSubmit}
              className={cn(
                'w-full inline-flex items-center justify-center gap-1.5 rounded-md',
                'bg-primary text-primary-foreground shadow-brand',
                'px-4 py-3 text-sm font-semibold',
                'transition-all hover:shadow-brand-strong active:scale-[0.99]',
                'disabled:opacity-50 disabled:cursor-not-allowed',
              )}
            >
              {submitting ? 'Signing in…' : 'Sign in'}
              {!submitting && <ArrowRight size={14} strokeWidth={2.25} />}
            </button>

            <p className="text-[11px] text-center text-muted-foreground">
              Demo mode — any email and a 4+ character password works.
            </p>
          </form>

          <p className="text-center text-sm text-muted-foreground">
            Don't have an account?{' '}
            <Link href="/register" className="font-semibold text-primary hover:underline">
              Create one
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
