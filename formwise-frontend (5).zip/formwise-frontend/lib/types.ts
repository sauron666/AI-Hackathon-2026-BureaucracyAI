/**
 * lib/types.ts — Source of truth for ALL Zod schemas and shared types.
 * Verbatim from AI-CONTEXT-FINAL.md. Do NOT redefine these elsewhere.
 *
 * Dev 1 owns this file per the project contract; it is included in this
 * Dev 4 frontend bundle so the components compile in isolation. If your
 * repo already has it, prefer the existing file.
 */

import { z } from 'zod';

/* ---------------------------------------------------------------- */
/* ProcedureAnswer — /api/chat (streamObject)                        */
/* ---------------------------------------------------------------- */

export const ProcedureAnswerSchema = z.object({
  summary: z.string(),
  steps: z.array(z.string()),
  documents: z.array(z.string()),
  office: z.string().nullable(),
  fee_info: z.string().nullable(),
  source_url: z.string().nullable(),
  confidence: z.number().min(0).max(1),
  answerable: z.boolean(),
});
export type ProcedureAnswer = z.infer<typeof ProcedureAnswerSchema>;

/* ---------------------------------------------------------------- */
/* DocumentRisk — /api/analyze (generateObject)                      */
/* ---------------------------------------------------------------- */

export const DocumentRiskSchema = z.object({
  risk_level: z.enum(['low', 'medium', 'high']),
  summary: z.string(),
  risks: z.array(
    z.object({
      clause: z.string(),
      risk: z.string(),
      severity: z.enum(['low', 'medium', 'high']),
      recommendation: z.string(),
    }),
  ),
  missing_clauses: z.array(z.string()),
  positive_points: z.array(z.string()),
  verdict: z.string(),
});
export type DocumentRisk = z.infer<typeof DocumentRiskSchema>;

/* ---------------------------------------------------------------- */
/* RelocationJourney — /api/journey (generateObject)                 */
/* ---------------------------------------------------------------- */

export const RelocationJourneySchema = z.object({
  title: z.string(),
  phases: z.array(
    z.object({
      phase: z.string(),
      timeline: z.string(),
      tasks: z.array(
        z.object({
          task: z.string(),
          urgency: z.enum(['critical', 'important', 'optional']),
          where: z.string().nullable(),
          estimated_time: z.string().nullable(),
        }),
      ),
    }),
  ),
  warnings: z.array(z.string()),
  estimated_total_cost: z.string().nullable(),
});
export type RelocationJourney = z.infer<typeof RelocationJourneySchema>;

/* ---------------------------------------------------------------- */
/* CountryComparison — /api/compare (generateObject)                 */
/* ---------------------------------------------------------------- */

export const CountryComparisonSchema = z.object({
  question_interpreted: z.string(),
  countries: z.array(
    z.object({
      country_code: z.string(),
      country_name: z.string(),
      summary: z.string(),
      processing_time: z.string().nullable(),
      typical_cost: z.string().nullable(),
      difficulty: z.enum(['easy', 'moderate', 'complex']),
      key_advantage: z.string().nullable(),
      key_disadvantage: z.string().nullable(),
    }),
  ),
  recommendation: z.string(),
});
export type CountryComparison = z.infer<typeof CountryComparisonSchema>;

/* ---------------------------------------------------------------- */
/* ProcedureSummary — /api/procedures GET                            */
/* ---------------------------------------------------------------- */

export const ProcedureSummarySchema = z.object({
  procedure_id: z.string(),
  title: z.string(),
  category: z.string(),
  country: z.string(),
  source_url: z.string(),
  difficulty: z.enum(['easy', 'moderate', 'complex']).optional(),
});
export type ProcedureSummary = z.infer<typeof ProcedureSummarySchema>;

/* ---------------------------------------------------------------- */
/* Enumerations                                                      */
/* ---------------------------------------------------------------- */

export type Country =
  | 'BG' | 'DE' | 'NL' | 'PT' | 'ES' | 'FR' | 'PL' | 'CZ'
  | 'AT' | 'SE' | 'HR' | 'GR' | 'RO' | 'GE' | 'RS' | 'GB'
  | 'CH' | 'UA';

export type Language =
  | 'en' | 'bg' | 'de' | 'nl' | 'pt' | 'es' | 'fr' | 'tr';

export type AppMode =
  | 'chat' | 'browse' | 'upload' | 'analyze' | 'journey' | 'compare';

export const COUNTRY_NAMES: Record<string, string> = {
  BG: 'Bulgaria',  DE: 'Germany',     NL: 'Netherlands', PT: 'Portugal',
  ES: 'Spain',     FR: 'France',      PL: 'Poland',      CZ: 'Czech Republic',
  AT: 'Austria',   SE: 'Sweden',      HR: 'Croatia',     GR: 'Greece',
  RO: 'Romania',   GE: 'Georgia',     RS: 'Serbia',      GB: 'United Kingdom',
  CH: 'Switzerland', UA: 'Ukraine',
};

export const COUNTRY_FLAGS: Record<string, string> = {
  BG: '🇧🇬', DE: '🇩🇪', NL: '🇳🇱', PT: '🇵🇹', ES: '🇪🇸', FR: '🇫🇷',
  PL: '🇵🇱', CZ: '🇨🇿', AT: '🇦🇹', SE: '🇸🇪', HR: '🇭🇷', GR: '🇬🇷',
  RO: '🇷🇴', GE: '🇬🇪', RS: '🇷🇸', GB: '🇬🇧', CH: '🇨🇭', UA: '🇺🇦',
};
