import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * DeepPartial — every nested field optional, every array element possibly
 * undefined. Matches the shape that Vercel AI SDK's useObject hook yields
 * during streaming. Components that consume streamed data should accept this.
 */
export type DeepPartial<T> = T extends Array<infer U>
  ? Array<DeepPartial<U> | undefined>
  : T extends object
    ? { [K in keyof T]?: DeepPartial<T[K]> }
    : T | undefined;
