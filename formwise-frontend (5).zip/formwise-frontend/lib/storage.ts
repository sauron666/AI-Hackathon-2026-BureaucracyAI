'use client';

import { useState, useEffect, useCallback } from 'react';

/**
 * useLocalStorage — SSR-safe persistent state.
 *
 * Hydrates from localStorage on mount (after SSR returns the default).
 * Writes are best-effort: if localStorage is unavailable (private mode,
 * quota, etc.) the warning is logged but the in-memory state still works.
 */
export function useLocalStorage<T>(
  key: string,
  defaultValue: T,
): [T, (v: T | ((prev: T) => T)) => void] {
  const [value, setValueState] = useState<T>(defaultValue);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw !== null) setValueState(JSON.parse(raw));
    } catch (e) {
      // ignore parse / access errors — keep defaults
    }
  }, [key]);

  const setValue = useCallback(
    (next: T | ((prev: T) => T)) => {
      setValueState((prev) => {
        const computed =
          typeof next === 'function' ? (next as (p: T) => T)(prev) : next;
        try {
          window.localStorage.setItem(key, JSON.stringify(computed));
        } catch (e) {
          // ignore write errors
        }
        return computed;
      });
    },
    [key],
  );

  return [value, setValue];
}

/* -------------------------------------------------- */
/* Theme                                               */
/* -------------------------------------------------- */

export type Theme = 'light' | 'dark' | 'system';

/**
 * useTheme — light / dark / system, persisted to localStorage and
 * applied as a `.dark` class on <html>. Listens to the OS
 * `prefers-color-scheme` media query when in "system" mode.
 *
 * Returns: [storedPref, setStoredPref, resolvedTheme]
 *   - storedPref: what the user explicitly chose (or 'system' default)
 *   - resolvedTheme: what's currently rendered ('light' | 'dark')
 */
export function useTheme(): [Theme, (t: Theme) => void, 'light' | 'dark'] {
  const [stored, setStored] = useLocalStorage<Theme>('formwise:theme', 'system');
  const [resolved, setResolved] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const compute = (): 'light' | 'dark' => {
      if (stored === 'system') return mq.matches ? 'dark' : 'light';
      return stored;
    };
    setResolved(compute());
    if (stored === 'system') {
      const handler = () => setResolved(mq.matches ? 'dark' : 'light');
      mq.addEventListener('change', handler);
      return () => mq.removeEventListener('change', handler);
    }
  }, [stored]);

  useEffect(() => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    if (resolved === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
  }, [resolved]);

  return [stored, setStored, resolved];
}

/* -------------------------------------------------- */
/* Saved questions (cross-conversation library)        */
/* -------------------------------------------------- */

export interface SavedAnswer {
  id: string;
  question: string;
  country: string;
  language: string;
  summary: string; // short preview
  savedAt: number; // epoch ms
}

const SAVED_KEY = 'formwise:saved';

export function useSavedAnswers(): {
  saved: SavedAnswer[];
  isSaved: (id: string) => boolean;
  toggle: (entry: Omit<SavedAnswer, 'savedAt'>) => void;
  remove: (id: string) => void;
  clear: () => void;
} {
  const [saved, setSaved] = useLocalStorage<SavedAnswer[]>(SAVED_KEY, []);

  const isSaved = useCallback(
    (id: string) => saved.some((s) => s.id === id),
    [saved],
  );

  const toggle = useCallback(
    (entry: Omit<SavedAnswer, 'savedAt'>) => {
      setSaved((prev) => {
        const exists = prev.find((s) => s.id === entry.id);
        if (exists) return prev.filter((s) => s.id !== entry.id);
        return [{ ...entry, savedAt: Date.now() }, ...prev].slice(0, 50);
      });
    },
    [setSaved],
  );

  const remove = useCallback(
    (id: string) => setSaved((prev) => prev.filter((s) => s.id !== id)),
    [setSaved],
  );

  const clear = useCallback(() => setSaved([]), [setSaved]);

  return { saved, isSaved, toggle, remove, clear };
}

/* -------------------------------------------------- */
/* Journey progress tracker                            */
/* -------------------------------------------------- */

/**
 * Per-country progress for journey tasks. Stored as a single keyed object:
 *   { "DE": { "phase-0:task-2": true, "phase-1:task-0": true }, ... }
 * Compact, easy to serialize, avoids one localStorage entry per task.
 */
export type ProgressMap = Record<string, Record<string, boolean>>;

const PROGRESS_KEY = 'formwise:journey-progress';

export function useJourneyProgress(country: string): {
  done: Record<string, boolean>;
  toggle: (taskKey: string) => void;
  reset: () => void;
  count: number;
} {
  const [all, setAll] = useLocalStorage<ProgressMap>(PROGRESS_KEY, {});
  const done = all[country] ?? {};
  const count = Object.values(done).filter(Boolean).length;

  const toggle = useCallback(
    (taskKey: string) => {
      setAll((prev) => {
        const next = { ...prev };
        const slice = { ...(next[country] ?? {}) };
        if (slice[taskKey]) delete slice[taskKey];
        else slice[taskKey] = true;
        next[country] = slice;
        return next;
      });
    },
    [setAll, country],
  );

  const reset = useCallback(() => {
    setAll((prev) => {
      const next = { ...prev };
      delete next[country];
      return next;
    });
  }, [setAll, country]);

  return { done, toggle, reset, count };
}

/* -------------------------------------------------- */
/* Onboarding flag                                     */
/* -------------------------------------------------- */

export function useOnboarding(): {
  needsOnboarding: boolean;
  markDone: () => void;
} {
  const [done, setDone] = useLocalStorage<boolean>('formwise:onboarded:v1', false);
  return {
    needsOnboarding: !done,
    markDone: () => setDone(true),
  };
}

/* -------------------------------------------------- */
/* Mock user + auth                                    */
/* -------------------------------------------------- */

export interface MockUser {
  name: string;
  email: string;
  joinedAt: number;
}

const USER_KEY = 'formwise:user';

export function useMockUser(): {
  user: MockUser | null;
  signIn: (email: string, name?: string) => MockUser;
  signOut: () => void;
  isHydrated: boolean;
} {
  const [user, setUser] = useLocalStorage<MockUser | null>(USER_KEY, null);
  const [isHydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  const signIn = useCallback(
    (email: string, name?: string) => {
      const u: MockUser = {
        name: name?.trim() || email.split('@')[0],
        email: email.trim(),
        joinedAt: Date.now(),
      };
      setUser(u);
      return u;
    },
    [setUser],
  );

  const signOut = useCallback(() => setUser(null), [setUser]);

  return { user, signIn, signOut, isHydrated };
}

/* -------------------------------------------------- */
/* Color palette picker (multi-theme)                  */
/* -------------------------------------------------- */

export type Palette = 'terracotta' | 'sage' | 'azure' | 'plum' | 'amber';

export const PALETTES: Record<
  Palette,
  { label: string; primary: string; primaryFg: string; ring: string; accent: string }
> = {
  terracotta: {
    label: 'Terracotta',
    primary: 'oklch(0.58 0.16 35)',
    primaryFg: 'oklch(0.98 0.005 55)',
    ring: 'oklch(0.58 0.16 35)',
    accent: 'oklch(0.68 0.14 145)',
  },
  sage: {
    label: 'Sage',
    primary: 'oklch(0.55 0.13 155)',
    primaryFg: 'oklch(0.98 0.005 145)',
    ring: 'oklch(0.55 0.13 155)',
    accent: 'oklch(0.68 0.14 35)',
  },
  azure: {
    label: 'Azure',
    primary: 'oklch(0.55 0.16 235)',
    primaryFg: 'oklch(0.98 0.005 235)',
    ring: 'oklch(0.55 0.16 235)',
    accent: 'oklch(0.68 0.14 145)',
  },
  plum: {
    label: 'Plum',
    primary: 'oklch(0.50 0.18 320)',
    primaryFg: 'oklch(0.98 0.005 320)',
    ring: 'oklch(0.50 0.18 320)',
    accent: 'oklch(0.68 0.14 145)',
  },
  amber: {
    label: 'Amber',
    primary: 'oklch(0.65 0.16 65)',
    primaryFg: 'oklch(0.20 0.02 50)',
    ring: 'oklch(0.65 0.16 65)',
    accent: 'oklch(0.55 0.13 155)',
  },
};

export function usePalette(): [Palette, (p: Palette) => void] {
  const [palette, setPalette] = useLocalStorage<Palette>('formwise:palette', 'terracotta');

  // Apply CSS vars on change
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const p = PALETTES[palette];
    const root = document.documentElement;
    root.style.setProperty('--primary', p.primary);
    root.style.setProperty('--primary-foreground', p.primaryFg);
    root.style.setProperty('--ring', p.ring);
    root.style.setProperty('--accent', p.accent);
  }, [palette]);

  return [palette, setPalette];
}
