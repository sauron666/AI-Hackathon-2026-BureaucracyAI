'use client';

import { ChevronDown } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import {
  COUNTRY_NAMES,
  COUNTRY_FLAGS,
  type Country,
  type Language,
} from '@/lib/types';
import ClippyMascot from './ClippyMascot';
import ThemeToggle from './ThemeToggle';
import { cn } from '@/lib/utils';

const LANGUAGES: { code: Language; label: string }[] = [
  { code: 'en', label: 'English' },
  { code: 'bg', label: 'Български' },
  { code: 'de', label: 'Deutsch' },
  { code: 'nl', label: 'Nederlands' },
  { code: 'pt', label: 'Português' },
  { code: 'es', label: 'Español' },
  { code: 'fr', label: 'Français' },
  { code: 'tr', label: 'Türkçe' },
];

const COUNTRIES: Country[] = [
  'BG', 'DE', 'NL', 'PT', 'ES', 'FR', 'PL', 'CZ',
  'AT', 'SE', 'HR', 'GR', 'RO', 'GE', 'RS', 'GB', 'CH', 'UA',
];

interface DropdownProps<T extends string> {
  value: T;
  options: { value: T; label: string; flag?: string }[];
  onChange: (v: T) => void;
  ariaLabel: string;
  width?: string;
}

function Dropdown<T extends string>({
  value, options, onChange, ariaLabel, width = 'min-w-[180px]',
}: DropdownProps<T>) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const current = options.find((o) => o.value === value);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-label={ariaLabel}
        onClick={() => setOpen((o) => !o)}
        className={cn(
          'flex h-9 items-center gap-2 rounded-md border border-border bg-card',
          'px-3 text-sm font-medium text-foreground',
          'transition-all hover:border-primary/40 hover:bg-secondary/60',
          'focus:outline-none focus:ring-2 focus:ring-ring/40',
        )}
      >
        {current?.flag && <span className="text-base leading-none">{current.flag}</span>}
        <span>{current?.label}</span>
        <ChevronDown
          size={14}
          className={cn('text-muted-foreground transition-transform', open && 'rotate-180')}
        />
      </button>
      {open && (
        <div
          role="listbox"
          className={cn(
            'absolute right-0 top-[calc(100%+4px)] z-50',
            width,
            'max-h-[280px] overflow-y-auto rounded-lg border border-border bg-popover p-1 shadow-xl',
          )}
        >
          {options.map((o) => (
            <button
              key={o.value}
              type="button"
              role="option"
              aria-selected={o.value === value}
              onClick={() => { onChange(o.value); setOpen(false); }}
              className={cn(
                'flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm',
                'transition-colors hover:bg-secondary',
                o.value === value && 'bg-secondary font-medium',
              )}
            >
              {o.flag && <span className="text-base leading-none">{o.flag}</span>}
              <span className="flex-1">{o.label}</span>
              {o.value === value && (
                <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

interface HeaderProps {
  country: Country;
  language: Language;
  onCountryChange: (c: Country) => void;
  onLanguageChange: (l: Language) => void;
}

export default function Header({
  country, language, onCountryChange, onLanguageChange,
}: HeaderProps) {
  return (
    <header className="fixed inset-x-0 top-0 z-40 h-16 border-b border-border/50 bg-background/80 backdrop-blur-lg">
      <div className="mx-auto flex h-full max-w-6xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <a href="/" className="flex items-center gap-2.5 group" aria-label="FormWise home">
          <span
            className={cn(
              'flex h-9 w-9 items-center justify-center',
              'transition-transform group-hover:scale-105',
            )}
          >
            <ClippyMascot size={22} mood="static" ariaLabel="" />
          </span>
          <span className="text-lg font-bold tracking-tight text-foreground">
            FormWise
          </span>
        </a>

        <div className="flex items-center gap-2">
          <Dropdown<Country>
            ariaLabel="Select country"
            value={country}
            onChange={onCountryChange}
            options={COUNTRIES.map((c) => ({
              value: c,
              label: COUNTRY_NAMES[c] ?? c,
              flag: COUNTRY_FLAGS[c],
            }))}
          />
          <Dropdown<Language>
            ariaLabel="Select language"
            value={language}
            onChange={onLanguageChange}
            options={LANGUAGES.map((l) => ({ value: l.code, label: l.label }))}
            width="min-w-[160px]"
          />
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
