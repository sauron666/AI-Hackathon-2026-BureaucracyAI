'use client';

import { useState, useEffect, useRef } from 'react';
import {
  MapPin,
  Plane,
  CalendarDays,
  AlertTriangle,
  Clock,
  ArrowRight,
  Plus,
  Sparkles,
  Check,
  RotateCcw,
} from 'lucide-react';
import {
  type RelocationJourney,
  type Country,
  type Language,
  COUNTRY_NAMES,
  COUNTRY_FLAGS,
} from '@/lib/types';
import { useJourneyProgress } from '@/lib/storage';
import SkeletonCard from './SkeletonCard';
import ErrorBanner from './ErrorBanner';
import ClippyMascot from './ClippyMascot';
import { cn } from '@/lib/utils';

type Purpose = 'work' | 'study' | 'family' | 'retirement' | 'digital_nomad';

export interface JourneyRunSignal {
  nonce: number;
  fromCountry: string;
  nationality: string;
  purpose: Purpose;
}

const PURPOSES: { value: Purpose; label: string }[] = [
  { value: 'work', label: 'Work' },
  { value: 'study', label: 'Study' },
  { value: 'family', label: 'Family' },
  { value: 'retirement', label: 'Retirement' },
  { value: 'digital_nomad', label: 'Digital nomad' },
];

const URGENCY_TONE = {
  critical: {
    label: 'Critical',
    pill: 'bg-risk-high',
    accent: 'text-[var(--risk-high-fg)]',
  },
  important: {
    label: 'Important',
    pill: 'bg-risk-medium',
    accent: 'text-[var(--risk-medium-fg)]',
  },
  optional: {
    label: 'Optional',
    pill: 'bg-secondary text-muted-foreground',
    accent: 'text-muted-foreground',
  },
} as const;

interface JourneyPlannerProps {
  country: Country;
  language: Language;
  runSignal?: JourneyRunSignal | null;
}

export default function JourneyPlanner({ country, language, runSignal }: JourneyPlannerProps) {
  const [fromCountry, setFromCountry] = useState('');
  const [nationality, setNationality] = useState('');
  const [purpose, setPurpose] = useState<Purpose>('work');

  const [journey, setJourney] = useState<RelocationJourney | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedSummary, setSubmittedSummary] = useState<string | null>(null);
  const lastNonce = useRef<number | null>(null);

  // Persistent per-country task completion
  const { done, toggle: toggleTask, reset: resetProgress, count } = useJourneyProgress(country);
  const totalTasks = journey?.phases.reduce((s, p) => s + p.tasks.length, 0) ?? 0;
  const progressPct = totalTasks > 0 ? Math.round((count / totalTasks) * 100) : 0;

  const toCountryName = COUNTRY_NAMES[country] ?? country;
  const toFlag = COUNTRY_FLAGS[country] ?? '';

  const submit = async () => {
    if (loading) return;
    setLoading(true);
    setError(null);
    setJourney(null);
    setSubmittedSummary(
      `${nationality || 'Someone'} moving from ${fromCountry || 'abroad'} to ${toCountryName} for ${purpose.replace('_', ' ')}`,
    );
    try {
      const res = await fetch('/api/journey', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from_country: fromCountry || 'unknown',
          to_country: country,
          nationality: nationality || undefined,
          purpose,
          language,
        }),
      });
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = (await res.json()) as RelocationJourney;
      setJourney(data);
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "We couldn't build your relocation plan. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setJourney(null);
    setError(null);
    setSubmittedSummary(null);
  };

  // Demo signal: auto-fill the form fields and submit
  useEffect(() => {
    if (runSignal && runSignal.nonce !== lastNonce.current) {
      lastNonce.current = runSignal.nonce;
      setFromCountry(runSignal.fromCountry);
      setNationality(runSignal.nationality);
      setPurpose(runSignal.purpose);

      // Submit on next tick so state has settled
      const t = setTimeout(() => {
        (async () => {
          setLoading(true);
          setError(null);
          setJourney(null);
          setSubmittedSummary(
            `${runSignal.nationality || 'Someone'} moving from ${runSignal.fromCountry || 'abroad'} to ${COUNTRY_NAMES[country] ?? country} for ${runSignal.purpose.replace('_', ' ')}`,
          );
          try {
            const res = await fetch('/api/journey', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                from_country: runSignal.fromCountry || 'unknown',
                to_country: country,
                nationality: runSignal.nationality || undefined,
                purpose: runSignal.purpose,
                language,
              }),
            });
            if (!res.ok) throw new Error(`Request failed (${res.status})`);
            const data = (await res.json()) as RelocationJourney;
            setJourney(data);
          } catch (e) {
            setError(
              e instanceof Error
                ? e.message
                : "We couldn't build your relocation plan. Please try again.",
            );
          } finally {
            setLoading(false);
          }
        })();
      }, 60);

      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runSignal]);

  /* -------------------------------------------------- */
  /* RESULT STATE                                        */
  /* -------------------------------------------------- */
  if (journey || loading || error) {
    return (
      <div className="space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1.5 min-w-0">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              <span>Relocation plan</span>
              <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
              <span className="flex items-center gap-1">
                <span className="text-base leading-none">{toFlag}</span>
                {toCountryName}
              </span>
            </div>
            <h2 className="text-xl font-semibold leading-snug text-foreground">
              {journey?.title || submittedSummary}
            </h2>
          </div>
          <button
            type="button"
            onClick={reset}
            className={cn(
              'shrink-0 inline-flex items-center gap-1.5 rounded-md',
              'border border-border bg-card px-3 py-1.5',
              'text-xs font-medium text-foreground',
              'transition-all hover:border-primary/40 hover:bg-secondary/60',
            )}
          >
            <Plus size={12} strokeWidth={2.25} />
            New plan
          </button>
        </div>

        {error && (
          <ErrorBanner message={error} onRetry={submit} onDismiss={reset} />
        )}

        {loading && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <ClippyMascot size={36} mood="thinking" />
              <span className="text-sm text-muted-foreground">
                Mapping out your move to {COUNTRY_NAMES[country] ?? country}…
              </span>
            </div>
            <SkeletonCard variant="journey" />
          </div>
        )}

        {journey && (
          <>
            {/* Progress bar — persisted across sessions */}
            {totalTasks > 0 && (
              <div
                className={cn(
                  'rounded-lg border border-border bg-card p-4',
                  'space-y-2',
                )}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      Your progress in {COUNTRY_NAMES[country] ?? country}
                    </div>
                    <div className="text-sm font-semibold text-foreground">
                      {count} of {totalTasks} tasks done · {progressPct}%
                    </div>
                  </div>
                  {count > 0 && (
                    <button
                      type="button"
                      onClick={resetProgress}
                      title="Reset progress"
                      className={cn(
                        'inline-flex items-center gap-1 rounded-md',
                        'border border-border bg-card px-2.5 py-1 text-xs font-medium',
                        'text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors',
                      )}
                    >
                      <RotateCcw size={11} strokeWidth={2.25} />
                      Reset
                    </button>
                  )}
                </div>
                <div
                  className="h-2 w-full overflow-hidden rounded-full bg-secondary"
                  role="progressbar"
                  aria-valuenow={progressPct}
                  aria-valuemin={0}
                  aria-valuemax={100}
                >
                  <div
                    className={cn(
                      'h-full rounded-full transition-all duration-700',
                      progressPct === 100 ? 'bg-accent' : 'bg-primary',
                    )}
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
              </div>
            )}

            {/* Estimated total cost */}
            {journey.estimated_total_cost && (
              <div
                className={cn(
                  'rounded-lg border border-border bg-secondary/50 px-4 py-3',
                  'flex items-center gap-3',
                )}
              >
                <span
                  className={cn(
                    'flex h-9 w-9 items-center justify-center rounded-lg',
                    'bg-accent/10 text-accent',
                  )}
                  aria-hidden
                >
                  <Sparkles size={16} strokeWidth={2} />
                </span>
                <div className="flex-1">
                  <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Estimated total cost
                  </div>
                  <div className="text-sm font-mono font-semibold text-foreground">
                    {journey.estimated_total_cost}
                  </div>
                </div>
              </div>
            )}

            {/* Phases */}
            <div className="space-y-4">
              {journey.phases.map((phase, pi) => (
                <article
                  key={pi}
                  className={cn(
                    'rounded-lg border border-border bg-card p-6',
                    'border-l-4 border-l-primary',
                    'space-y-4',
                  )}
                >
                  <header className="space-y-1">
                    <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-primary">
                      <span
                        className={cn(
                          'flex h-5 w-5 items-center justify-center rounded-full',
                          'bg-primary/10 text-[10px] font-semibold',
                        )}
                      >
                        {pi + 1}
                      </span>
                      Phase
                    </div>
                    <h3 className="text-lg font-semibold tracking-tight text-foreground">
                      {phase.phase}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Clock size={12} strokeWidth={2} />
                      {phase.timeline}
                    </div>
                  </header>

                  <ul className="space-y-2.5">
                    {phase.tasks.map((t, ti) => {
                      const tone = URGENCY_TONE[t.urgency];
                      const taskKey = `phase-${pi}:task-${ti}`;
                      const isDone = Boolean(done[taskKey]);
                      return (
                        <li
                          key={ti}
                          className={cn(
                            'rounded-md border border-border p-3 space-y-1.5',
                            'transition-colors',
                            isDone
                              ? 'bg-accent/5 border-accent/30'
                              : 'bg-secondary/30',
                          )}
                        >
                          <div className="flex items-start gap-2.5">
                            <button
                              type="button"
                              onClick={() => toggleTask(taskKey)}
                              aria-label={isDone ? 'Mark not done' : 'Mark done'}
                              className={cn(
                                'mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center',
                                'rounded-md border transition-all',
                                isDone
                                  ? 'border-accent bg-accent text-accent-foreground'
                                  : 'border-border bg-card hover:border-primary/50',
                              )}
                            >
                              {isDone && <Check size={11} strokeWidth={3} />}
                            </button>
                            <span
                              className={cn(
                                'shrink-0 inline-flex items-center rounded-full px-2 py-0.5',
                                'text-[10px] font-semibold uppercase tracking-wide',
                                tone.pill,
                              )}
                            >
                              {tone.label}
                            </span>
                            <p
                              className={cn(
                                'text-sm leading-relaxed transition-colors',
                                isDone
                                  ? 'text-muted-foreground line-through'
                                  : 'text-foreground',
                              )}
                            >
                              {t.task}
                            </p>
                          </div>
                          {(t.where || t.estimated_time) && (
                            <div className="flex flex-wrap gap-x-4 gap-y-1 pl-9 text-xs text-muted-foreground">
                              {t.where && (
                                <span className="inline-flex items-center gap-1">
                                  <MapPin size={11} strokeWidth={2} />
                                  {t.where}
                                </span>
                              )}
                              {t.estimated_time && (
                                <span className="inline-flex items-center gap-1">
                                  <Clock size={11} strokeWidth={2} />
                                  {t.estimated_time}
                                </span>
                              )}
                            </div>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                </article>
              ))}
            </div>

            {/* Warnings */}
            {journey.warnings.length > 0 && (
              <section className="space-y-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle
                    size={18}
                    strokeWidth={2}
                    className="text-[var(--risk-medium-fg)]"
                  />
                  <h3 className="text-lg font-semibold text-foreground">
                    Common mistakes to avoid
                  </h3>
                </div>
                <ul className="space-y-2 rounded-lg bg-risk-medium/40 border border-[var(--risk-medium-fg)]/15 p-4">
                  {journey.warnings.map((w, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-2 text-sm leading-relaxed text-foreground"
                    >
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--risk-medium-fg)]" />
                      {w}
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </>
        )}
      </div>
    );
  }

  /* -------------------------------------------------- */
  /* FORM STATE                                          */
  /* -------------------------------------------------- */
  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight text-foreground">
          Plan your relocation
        </h2>
        <p className="text-sm text-muted-foreground">
          Tell us where you're moving from and we'll build a phased roadmap — what to do before you leave, in your first week, your first month, and your first three months.
        </p>
      </div>

      <div
        className={cn(
          'rounded-xl border border-border bg-card p-6 space-y-5',
          'shadow-sm',
        )}
      >
        {/* From / To */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <label
              htmlFor="from-country"
              className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
            >
              Moving from
            </label>
            <div className="relative">
              <Plane
                size={14}
                strokeWidth={2}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                aria-hidden
              />
              <input
                id="from-country"
                type="text"
                value={fromCountry}
                onChange={(e) => setFromCountry(e.target.value)}
                placeholder="e.g. Brazil, India, USA"
                className={cn(
                  'h-10 w-full rounded-md border border-border bg-card pl-9 pr-3',
                  'text-sm text-foreground placeholder:text-muted-foreground/70',
                  'transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/30',
                )}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label
              htmlFor="to-country"
              className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
            >
              Moving to
            </label>
            <div
              id="to-country"
              className={cn(
                'flex h-10 items-center gap-2 rounded-md border border-border bg-secondary/40 px-3',
                'text-sm font-medium text-foreground',
              )}
              aria-live="polite"
            >
              <span className="text-base leading-none">{toFlag}</span>
              <span>{toCountryName}</span>
              <span className="ml-auto text-[10px] uppercase tracking-wide text-muted-foreground">
                set in header
              </span>
            </div>
          </div>
        </div>

        {/* Nationality */}
        <div className="space-y-2">
          <label
            htmlFor="nationality"
            className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
          >
            Nationality (optional)
          </label>
          <input
            id="nationality"
            type="text"
            value={nationality}
            onChange={(e) => setNationality(e.target.value)}
            placeholder="e.g. Brazilian, Indian, American"
            className={cn(
              'h-10 w-full rounded-md border border-border bg-card px-3',
              'text-sm text-foreground placeholder:text-muted-foreground/70',
              'transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/30',
            )}
          />
        </div>

        {/* Purpose */}
        <div className="space-y-2">
          <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Purpose
          </label>
          <div className="flex flex-wrap gap-2">
            {PURPOSES.map((p) => {
              const active = purpose === p.value;
              return (
                <button
                  key={p.value}
                  type="button"
                  onClick={() => setPurpose(p.value)}
                  className={cn(
                    'rounded-full border px-3.5 py-1.5 text-sm font-medium transition-all',
                    active
                      ? 'border-primary bg-primary text-primary-foreground shadow-brand'
                      : 'border-border bg-card text-foreground hover:border-primary/40',
                  )}
                >
                  {p.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Submit */}
        <button
          type="button"
          onClick={submit}
          disabled={loading}
          className={cn(
            'mt-2 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg',
            'bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-brand',
            'transition-all hover:shadow-brand-strong active:scale-[0.99]',
            'disabled:opacity-60',
          )}
        >
          <CalendarDays size={15} strokeWidth={2.25} />
          Build my relocation plan
          <ArrowRight size={15} strokeWidth={2.25} />
        </button>
      </div>
    </div>
  );
}
