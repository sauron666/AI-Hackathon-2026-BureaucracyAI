import { cn } from '@/lib/utils';

interface SkeletonCardProps {
  variant?: 'answer' | 'risk' | 'journey' | 'compare' | 'compact';
  className?: string;
}

export default function SkeletonCard({
  variant = 'answer',
  className,
}: SkeletonCardProps) {
  if (variant === 'compact') {
    return (
      <div className={cn('space-y-3', className)}>
        <div className="h-4 w-3/4 rounded fw-shimmer" />
        <div className="h-4 w-full rounded fw-shimmer" />
        <div className="h-4 w-5/6 rounded fw-shimmer" />
      </div>
    );
  }

  if (variant === 'risk') {
    return (
      <div className={cn('space-y-6', className)}>
        <div className="h-20 w-full rounded-xl fw-shimmer" aria-label="Loading risk banner" />
        <div className="space-y-3">
          <div className="h-4 w-1/3 rounded fw-shimmer" />
          <div className="h-4 w-full rounded fw-shimmer" />
        </div>
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="space-y-3 rounded-lg border border-border bg-card p-5"
          >
            <div className="h-5 w-1/2 rounded fw-shimmer" />
            <div className="h-4 w-full rounded fw-shimmer" />
            <div className="h-4 w-4/5 rounded fw-shimmer" />
          </div>
        ))}
      </div>
    );
  }

  if (variant === 'journey') {
    return (
      <div className={cn('space-y-6', className)}>
        <div className="h-8 w-2/3 rounded fw-shimmer" />
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="rounded-lg border border-border bg-card p-6 space-y-3">
            <div className="h-5 w-1/3 rounded fw-shimmer" />
            <div className="h-4 w-1/4 rounded fw-shimmer" />
            <div className="space-y-2 pt-2">
              <div className="h-4 w-full rounded fw-shimmer" />
              <div className="h-4 w-5/6 rounded fw-shimmer" />
              <div className="h-4 w-3/4 rounded fw-shimmer" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (variant === 'compare') {
    return (
      <div className={cn('space-y-6', className)}>
        <div className="h-5 w-2/3 rounded fw-shimmer" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-2">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className="space-y-3 rounded-lg border border-border bg-card p-5"
            >
              <div className="flex items-center gap-2">
                <div className="h-6 w-8 rounded fw-shimmer" />
                <div className="h-5 w-1/3 rounded fw-shimmer" />
              </div>
              <div className="h-4 w-full rounded fw-shimmer" />
              <div className="h-4 w-5/6 rounded fw-shimmer" />
              <div className="h-4 w-2/3 rounded fw-shimmer" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 'answer' default
  return (
    <div className={cn('space-y-6', className)} aria-label="Loading answer">
      {/* Summary */}
      <div className="rounded-lg border border-border bg-card border-l-4 border-l-primary/40 p-6 space-y-3">
        <div className="flex gap-2">
          <div className="h-5 w-16 rounded-full fw-shimmer" />
          <div className="h-5 w-20 rounded-full fw-shimmer" />
        </div>
        <div className="h-5 w-3/5 rounded fw-shimmer" />
        <div className="space-y-2 pt-1">
          <div className="h-4 w-full rounded fw-shimmer" />
          <div className="h-4 w-11/12 rounded fw-shimmer" />
          <div className="h-4 w-3/4 rounded fw-shimmer" />
        </div>
      </div>

      {/* Steps */}
      <div className="space-y-3">
        <div className="h-5 w-32 rounded fw-shimmer" />
        {[0, 1, 2].map((i) => (
          <div key={i} className="flex gap-4">
            <div className="h-8 w-8 shrink-0 rounded-full fw-shimmer" />
            <div className="flex-1 space-y-2">
              <div className="h-4 w-2/3 rounded fw-shimmer" />
              <div className="h-3 w-5/6 rounded fw-shimmer" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
