'use client';

import {
  AlertCircle,
  AlertTriangle,
  ShieldCheck,
  XCircle,
  CheckCircle2,
  Quote,
  ArrowRight,
} from 'lucide-react';
import type { DocumentRisk } from '@/lib/types';
import { cn } from '@/lib/utils';

const RISK_TONE = {
  low: {
    label: 'Low risk',
    Icon: ShieldCheck,
    banner: 'bg-risk-low border-l-[var(--risk-low-fg)]',
    pill: 'bg-risk-low',
  },
  medium: {
    label: 'Medium risk',
    Icon: AlertTriangle,
    banner: 'bg-risk-medium border-l-[var(--risk-medium-fg)]',
    pill: 'bg-risk-medium',
  },
  high: {
    label: 'High risk',
    Icon: AlertCircle,
    banner: 'bg-risk-high border-l-[var(--risk-high-fg)]',
    pill: 'bg-risk-high',
  },
} as const;

const SEVERITY_RANK: Record<'low' | 'medium' | 'high', number> = {
  high: 3,
  medium: 2,
  low: 1,
};

interface DocumentAnalysisCardProps {
  risk: DocumentRisk;
}

export default function DocumentAnalysisCard({ risk }: DocumentAnalysisCardProps) {
  const tone = RISK_TONE[risk.risk_level];
  const BannerIcon = tone.Icon;

  // Sort risks by severity DESC (rule 3)
  const sortedRisks = [...risk.risks].sort(
    (a, b) => SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity],
  );

  return (
    <div className="space-y-6">
      {/* 1. Risk-level banner — full width */}
      <div
        role="status"
        aria-label={`Overall risk: ${risk.risk_level}`}
        className={cn(
          'flex items-center gap-3 rounded-xl border-l-4 px-5 py-4',
          tone.banner,
        )}
      >
        <BannerIcon size={22} strokeWidth={2} className="shrink-0" aria-hidden />
        <div className="text-sm font-semibold uppercase tracking-wide">
          {tone.label}
        </div>
      </div>

      {/* 2. Summary */}
      <p className="text-base leading-relaxed text-foreground">{risk.summary}</p>

      {/* 3. Flagged clauses, sorted by severity */}
      {sortedRisks.length > 0 && (
        <section className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">
            Flagged clauses ({sortedRisks.length})
          </h3>

          <div className="space-y-4">
            {sortedRisks.map((r, i) => {
              const sevTone = RISK_TONE[r.severity];
              return (
                <article
                  key={i}
                  className={cn(
                    'rounded-lg border border-border bg-card p-5 space-y-3',
                    'transition-shadow hover:shadow-md',
                  )}
                >
                  {/* Severity badge */}
                  <div className="flex items-center gap-2">
                    <span
                      className={cn(
                        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5',
                        'text-xs font-semibold uppercase tracking-wide',
                        sevTone.pill,
                      )}
                    >
                      {r.severity}
                    </span>
                  </div>

                  {/* Quoted clause */}
                  <blockquote
                    className={cn(
                      'border-l-2 border-border pl-3 py-1',
                      'text-sm italic leading-relaxed text-muted-foreground',
                    )}
                  >
                    <Quote
                      size={12}
                      strokeWidth={2}
                      className="inline mr-1 -mt-0.5 text-muted-foreground/60"
                      aria-hidden
                    />
                    {r.clause}
                  </blockquote>

                  {/* Risk explanation */}
                  <p className="text-sm leading-relaxed text-foreground">
                    {r.risk}
                  </p>

                  {/* Recommendation with → prefix */}
                  <div
                    className={cn(
                      'flex items-start gap-2 rounded-md',
                      'bg-secondary/50 px-3 py-2.5',
                    )}
                  >
                    <ArrowRight
                      size={14}
                      strokeWidth={2.25}
                      className="mt-0.5 shrink-0 text-primary"
                      aria-hidden
                    />
                    <p className="text-sm leading-relaxed text-foreground">
                      <span className="font-medium">Recommendation: </span>
                      {r.recommendation}
                    </p>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      )}

      {/* 4. Missing clauses — red X bullets */}
      {risk.missing_clauses.length > 0 && (
        <section className="space-y-3">
          <h3 className="text-lg font-semibold text-foreground">
            What's missing
          </h3>
          <ul className="space-y-2">
            {risk.missing_clauses.map((m, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <XCircle
                  size={16}
                  strokeWidth={2}
                  className="mt-0.5 shrink-0 text-[var(--risk-high-fg)]"
                  aria-hidden
                />
                <span className="text-sm leading-relaxed text-foreground">
                  {m}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* 5. Positive points — green checkmark bullets */}
      {risk.positive_points.length > 0 && (
        <section className="space-y-3">
          <h3 className="text-lg font-semibold text-foreground">
            What looks good
          </h3>
          <ul className="space-y-2">
            {risk.positive_points.map((p, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <CheckCircle2
                  size={16}
                  strokeWidth={2}
                  className="mt-0.5 shrink-0 text-accent"
                  aria-hidden
                />
                <span className="text-sm leading-relaxed text-foreground">
                  {p}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* 6. Verdict — bold bottom line in highlighted box */}
      {risk.verdict && (
        <div
          className={cn(
            'rounded-xl border border-primary/20 p-5',
            'bg-gradient-to-br from-primary/5 via-accent/5 to-transparent',
          )}
        >
          <div className="text-xs font-semibold uppercase tracking-wide text-primary mb-1.5">
            Bottom line
          </div>
          <p className="text-base font-semibold leading-relaxed text-foreground">
            {risk.verdict}
          </p>
        </div>
      )}
    </div>
  );
}
