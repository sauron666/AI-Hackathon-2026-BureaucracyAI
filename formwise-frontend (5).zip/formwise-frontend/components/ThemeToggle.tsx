'use client';

import { Sun, Moon, Monitor } from 'lucide-react';
import { useTheme, type Theme } from '@/lib/storage';
import { cn } from '@/lib/utils';

interface ThemeToggleProps {
  /** Optional className override (e.g. for sizing tweaks). */
  className?: string;
}

/**
 * ThemeToggle — small icon button cycling light → dark → system.
 * Shows the icon for the *currently active* state and the label
 * for the explicit user choice (so "Auto" reads as "System").
 */
export default function ThemeToggle({ className }: ThemeToggleProps) {
  const [theme, setTheme, resolved] = useTheme();

  const cycle = () => {
    const next: Theme =
      theme === 'light' ? 'dark' : theme === 'dark' ? 'system' : 'light';
    setTheme(next);
  };

  // Icon: light = sun, dark = moon, system = laptop (so all three are distinguishable)
  const Icon = theme === 'dark' ? Moon : theme === 'system' ? Monitor : Sun;

  const labelMap: Record<Theme, string> = {
    light: 'Light theme',
    dark: 'Dark theme',
    system: `Auto (${resolved})`,
  };
  const label = labelMap[theme];

  return (
    <button
      type="button"
      onClick={cycle}
      aria-label={label}
      title={label}
      className={cn(
        'flex h-9 w-9 items-center justify-center rounded-md',
        'text-muted-foreground hover:bg-secondary hover:text-foreground',
        'transition-colors',
        'focus:outline-none focus:ring-2 focus:ring-ring/40',
        className,
      )}
    >
      <Icon size={16} strokeWidth={2} />
    </button>
  );
}
