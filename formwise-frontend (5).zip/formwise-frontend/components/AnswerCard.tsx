'use client';

import { useState, useMemo } from 'react';
import {
  Check,
  Clock,
  ListChecks,
  FileText,
  MapPin,
  CreditCard,
  ExternalLink,
  AlertCircle,
  Building,
  HelpCircle,
  Share2,
  Heart,
  CheckCircle2,
} from 'lucide-react';
import type { ProcedureAnswer } from '@/lib/types';
import { cn, type DeepPartial } from '@/lib/utils';
import { useSavedAnswers } from '@/lib/storage';

/* ---------------------------------------------------------------- */
/* Sub-components                                                    */
/* ---------------------------------------------------------------- */

function ClarificationPrompt({ summary }: { summary?: string }) {
  return (
    <div
      className={cn(
        'rounded-lg border border-border bg-gradient-to-br',
        'from-primary/5 via-accent/5 to-transparent',
        'border-primary/20 p-6',
      )}
    >
      <div className="flex items-start gap-3">
        <span
          className={cn(
            'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
            'bg-primary/10 text-primary',
          )}
        >
          <HelpCircle size={20} />
        </span>
        <div className="space-y-2">
          <h3 className="text-base font-semibold text-foreground">
            I need a bit more to give you a confident answer
          </h3>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {summary ||
              "I don't have specific information about this procedure yet. Try rephrasing your question, or check the official government website."}
          </p>
        </div>
      </div>
    </div>
  );
}

function ConfidenceRing({ confidence }: { confidence: number }) {
  // Visual: circular ring whose fill = confidence and color shifts with level
  const size = 38;
  const stroke = 3.5;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const filled = Math.max(0, Math.min(1, confidence));
  const dashOffset = c * (1 - filled);

  // Color: low = neutral muted, mid = primary, high = accent (sage)
  const color =
    filled >= 0.85
      ? 'oklch(0.55 0.14 145)' // sage
      : filled >= 0.5
        ? 'oklch(0.58 0.16 35)' // terracotta
        : 'oklch(0.60 0.04 55)'; // muted

  const label =
    filled >= 0.85
      ? 'High confidence'
      : filled >= 0.5
        ? 'Partial answer'
        : 'Limited information';

  return (
    <div className="inline-flex items-center gap-2.5">
      <span
        className="relative inline-flex items-center justify-center"
        style={{ width: size, height: size }}
        aria-label={`Confidence: ${Math.round(filled * 100)}%`}
      >
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          className="-rotate-90"
          aria-hidden
        >
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke="oklch(0.91 0.012 55)"
            strokeWidth={stroke}
          />
          <circle
            className="confidence-ring-fg"
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke={color}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={c}
            style={
              {
                strokeDashoffset: dashOffset,
                ['--ring-circumference' as never]: c,
                ['--ring-target' as never]: dashOffset,
              } as React.CSSProperties
            }
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-[10px] font-mono font-semibold text-foreground">
          {Math.round(filled * 100)}
        </span>
      </span>
      <div className="flex flex-col gap-0.5">
        <span className="text-xs font-semibold text-foreground leading-none">
          {label}
        </span>
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground leading-none">
          Confidence
        </span>
      </div>
    </div>
  );
}

function StepsTimeline({ steps }: { steps: string[] }) {
  return (
    <div className="space-y-0">
      {steps.map((step, i) => {
        const isLast = i === steps.length - 1;
        return (
          <div key={i} className="relative flex gap-4 pb-4 last:pb-0">
            {/* Connector line */}
            {!isLast && (
              <span
                className="absolute left-4 top-10 bottom-0 w-px bg-border"
                aria-hidden
              />
            )}
            {/* Number */}
            <div
              className={cn(
                'relative z-10 flex h-8 w-8 shrink-0 items-center justify-center',
                'rounded-full bg-card border border-border',
                'text-sm font-semibold text-primary',
              )}
            >
              {i + 1}
            </div>
            {/* Body */}
            <div className="flex-1 pt-0.5">
              <p className="text-sm leading-relaxed text-foreground">{step}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function DocumentsChecklist({ documents }: { documents: string[] }) {
  const [checked, setChecked] = useState<Set<number>>(new Set());

  const toggle = (i: number) => {
    setChecked((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  };

  return (
    <div className="space-y-2">
      {documents.map((doc, i) => {
        const isChecked = checked.has(i);
        return (
          <button
            key={i}
            type="button"
            onClick={() => toggle(i)}
            className={cn(
              'group flex w-full items-start gap-3 rounded-lg border p-3 text-left',
              'transition-all',
              isChecked
                ? 'border-accent/30 bg-accent/5'
                : 'border-border bg-card hover:border-primary/40 hover:bg-secondary/40',
            )}
          >
            <span
              className={cn(
                'mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-all',
                isChecked
                  ? 'border-accent bg-accent text-accent-foreground'
                  : 'border-border bg-card group-hover:border-primary/50',
              )}
              aria-hidden
            >
              {isChecked && <Check size={12} strokeWidth={3} />}
            </span>
            <span
              className={cn(
                'text-sm leading-relaxed transition-colors',
                isChecked
                  ? 'text-muted-foreground line-through'
                  : 'text-foreground',
              )}
            >
              {doc}
            </span>
          </button>
        );
      })}
    </div>
  );
}

function OfficeAndFee({
  office,
  feeInfo,
}: {
  office?: string | null;
  feeInfo?: string | null;
}) {
  if (!office && !feeInfo) return null;

  return (
    <div
      className={cn(
        'rounded-lg bg-secondary/50 p-5 space-y-3',
      )}
    >
      {office && (
        <div className="flex items-start gap-3">
          <span className="mt-0.5 text-muted-foreground" aria-hidden>
            <MapPin size={16} strokeWidth={2} />
          </span>
          <div className="flex-1">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-0.5">
              Where to go
            </div>
            <div className="text-sm leading-relaxed text-foreground">
              {office}
            </div>
          </div>
        </div>
      )}

      {feeInfo && (
        <div className="flex items-start gap-3">
          <span className="mt-0.5 text-muted-foreground" aria-hidden>
            <CreditCard size={16} strokeWidth={2} />
          </span>
          <div className="flex-1">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-0.5">
              Fee
            </div>
            <div className="text-sm leading-relaxed text-foreground font-mono">
              {feeInfo}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Main component                                                    */
/* ---------------------------------------------------------------- */

interface AnswerCardProps {
  answer: DeepPartial<ProcedureAnswer>;
  isStreaming?: boolean;
  question?: string;
  country?: string;
  language?: string;
}

export default function AnswerCard({
  answer,
  isStreaming,
  question,
  country,
  language,
}: AnswerCardProps) {
  const { isSaved, toggle } = useSavedAnswers();
  const [copied, setCopied] = useState(false);

  // Stable id from question + country (used for save dedup)
  const id = useMemo(
    () =>
      `${(country || 'XX')}::${(question || answer.summary || '').slice(0, 80)}`,
    [country, question, answer.summary],
  );

  const saved = isSaved(id);

  const handleSave = () => {
    if (!question && !answer.summary) return;
    toggle({
      id,
      question: question ?? answer.summary ?? 'Untitled',
      country: country ?? 'XX',
      language: language ?? 'en',
      summary: (answer.summary ?? '').slice(0, 240),
    });
  };

  const handleShare = async () => {
    if (!answer.summary) return;
    const md = [
      `# ${question ?? 'FormWise answer'} ${country ? `(${country})` : ''}`,
      '',
      answer.summary,
      '',
      ...(answer.steps && answer.steps.length
        ? ['## Steps', ...answer.steps.filter(Boolean).map((s, i) => `${i + 1}. ${s}`), '']
        : []),
      ...(answer.documents && answer.documents.length
        ? ['## Required documents', ...answer.documents.filter(Boolean).map((d) => `- ${d}`), '']
        : []),
      ...(answer.office ? [`**Where:** ${answer.office}`, ''] : []),
      ...(answer.fee_info ? [`**Fee:** ${answer.fee_info}`, ''] : []),
      ...(answer.source_url ? [`Source: ${answer.source_url}`] : []),
      '',
      '— via FormWise · ai-hackathon-2026-bureaucracy.vercel.app',
    ].join('\n');

    try {
      await navigator.clipboard.writeText(md);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard might be unavailable in non-secure contexts; fail silently
    }
  };

  // answerable=false → ClarificationPrompt branch (rule 6)
  if (answer.answerable === false) {
    return <ClarificationPrompt summary={answer.summary} />;
  }

  const showConfidence = typeof answer.confidence === 'number';
  const canShareOrSave = !isStreaming && Boolean(answer.summary);

  return (
    <div className="space-y-6">
      {/* 1. Summary card with left-rail terracotta accent */}
      {answer.summary && (
        <div
          className={cn(
            'rounded-lg border border-border bg-card p-6',
            'border-l-4 border-l-primary',
            'space-y-4',
          )}
        >
          <div className="flex items-start justify-between gap-3">
            {showConfidence ? (
              <ConfidenceRing confidence={answer.confidence!} />
            ) : (
              <span />
            )}

            {canShareOrSave && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleSave}
                  aria-label={saved ? 'Unsave' : 'Save this answer'}
                  title={saved ? 'Saved' : 'Save'}
                  className={cn(
                    'h-8 w-8 inline-flex items-center justify-center rounded-md',
                    'transition-colors',
                    saved
                      ? 'text-[oklch(0.55_0.18_25)] hover:bg-secondary'
                      : 'text-muted-foreground hover:bg-secondary hover:text-foreground',
                  )}
                >
                  <Heart
                    size={15}
                    strokeWidth={2}
                    fill={saved ? 'currentColor' : 'none'}
                  />
                </button>
                <button
                  type="button"
                  onClick={handleShare}
                  aria-label="Copy answer to clipboard"
                  title="Copy answer"
                  className={cn(
                    'h-8 inline-flex items-center justify-center gap-1.5 rounded-md px-2',
                    'text-xs font-medium',
                    'text-muted-foreground hover:bg-secondary hover:text-foreground',
                    'transition-colors',
                    copied && 'text-accent',
                  )}
                >
                  {copied ? (
                    <>
                      <CheckCircle2 size={13} strokeWidth={2.25} />
                      Copied
                    </>
                  ) : (
                    <>
                      <Share2 size={13} strokeWidth={2.25} />
                      Share
                    </>
                  )}
                </button>
              </div>
            )}
          </div>

          <p className="text-base leading-relaxed text-foreground">
            {answer.summary}
            {isStreaming && (
              <span
                className="ml-1 inline-block h-4 w-0.5 align-middle bg-primary animate-pulse"
                aria-hidden
              />
            )}
          </p>
        </div>
      )}

      {/* 2. Steps timeline */}
      {answer.steps && answer.steps.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <ListChecks size={18} strokeWidth={2} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">
              Step by step
            </h3>
          </div>
          <StepsTimeline steps={answer.steps.filter((s): s is string => Boolean(s))} />
        </section>
      )}

      {/* 3. Documents checklist */}
      {answer.documents && answer.documents.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <FileText size={18} strokeWidth={2} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">
              Required documents
            </h3>
          </div>
          <DocumentsChecklist
            documents={answer.documents.filter((d): d is string => Boolean(d))}
          />
        </section>
      )}

      {/* 4. Office + fee combined info card */}
      {(answer.office || answer.fee_info) && (
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Building size={18} strokeWidth={2} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">
              Where & how much
            </h3>
          </div>
          <OfficeAndFee office={answer.office} feeInfo={answer.fee_info} />
        </section>
      )}

      {/* 5. Source attribution */}
      {answer.source_url && (
        <div className="flex items-center gap-2 pt-2 border-t border-border/60">
          <span className="text-xs text-muted-foreground">Source:</span>
          <a
            href={answer.source_url}
            target="_blank"
            rel="noopener noreferrer"
            className={cn(
              'inline-flex items-center gap-1 text-xs font-medium',
              'text-muted-foreground hover:text-primary transition-colors',
              'underline-offset-4 hover:underline',
            )}
          >
            <span className="font-mono truncate max-w-[400px]">
              {answer.source_url}
            </span>
            <ExternalLink size={11} strokeWidth={2} />
          </a>
        </div>
      )}

      {/* Empty/early-streaming hint */}
      {isStreaming && !answer.summary && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="relative flex h-2 w-2">
            <span className="absolute inset-0 rounded-full bg-primary fw-ping" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
          </span>
          Thinking through your question…
        </div>
      )}
    </div>
  );
}
