'use client';

import { cn } from '@/lib/utils';

/**
 * Clippy — FormWise's paperclip mascot.
 *
 * The brand identity. Inspired by the spirit of a certain office assistant
 * but redrawn from scratch in the FormWise warm terracotta palette.
 *
 * Variants:
 *  - "static"  — no animation, used in header logo + tight spaces
 *  - "idle"    — gentle blink every ~4s, used in hero + empty states
 *  - "waving"  — animated body tilt on top of idle, used for greetings
 *  - "thinking" — "..." dots emerge to the side, used during streaming
 *
 * All animations respect prefers-reduced-motion and degrade to static.
 */

type Mood = 'static' | 'idle' | 'waving' | 'thinking';

interface ClippyMascotProps {
  size?: number;
  mood?: Mood;
  className?: string;
  ariaLabel?: string;
}

export default function ClippyMascot({
  size = 80,
  mood = 'idle',
  className,
  ariaLabel = 'Clippy, the FormWise mascot',
}: ClippyMascotProps) {
  const animateBody =
    mood === 'waving'
      ? 'clippy-wave'
      : mood === 'thinking'
        ? 'clippy-think'
        : '';

  const blink = mood !== 'static';

  return (
    <span
      className={cn('inline-block relative', className)}
      style={{ width: size, height: size * 1.4 }}
      role="img"
      aria-label={ariaLabel}
    >
      <svg
        viewBox="0 0 60 84"
        width={size}
        height={size * 1.4}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={cn('absolute inset-0', animateBody)}
        aria-hidden
      >
        <defs>
          <linearGradient id="clippy-body-grad" x1="0" y1="0" x2="0.6" y2="1">
            <stop offset="0%" stopColor="oklch(0.72 0.17 40)" />
            <stop offset="55%" stopColor="oklch(0.58 0.16 35)" />
            <stop offset="100%" stopColor="oklch(0.45 0.15 30)" />
          </linearGradient>
          <radialGradient id="clippy-shine" cx="0.3" cy="0.3" r="0.7">
            <stop offset="0%" stopColor="white" stopOpacity="0.45" />
            <stop offset="40%" stopColor="white" stopOpacity="0.08" />
            <stop offset="100%" stopColor="white" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Drop shadow ellipse on the ground */}
        <ellipse
          cx="30"
          cy="80"
          rx="13"
          ry="2.2"
          fill="oklch(0.22 0.03 45)"
          opacity="0.16"
        />

        {/* Paperclip body — continuous wire path
            Outer loop -> bottom curve -> back up -> inner loop -> hook */}
        <path
          d="
            M 18 14
            Q 18 4, 30 4
            Q 42 4, 42 14
            L 42 60
            Q 42 70, 30 70
            Q 18 70, 18 60
            L 18 22
            Q 18 16, 26 16
            L 34 16
            Q 38 16, 38 22
            L 38 56
            Q 38 60, 34 60
            L 30 60
          "
          stroke="url(#clippy-body-grad)"
          strokeWidth="3.6"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />

        {/* Subtle highlight running along the front edge */}
        <path
          d="M 18 14 Q 18 4, 30 4 Q 36 4, 39 8"
          stroke="white"
          strokeOpacity="0.35"
          strokeWidth="1.2"
          strokeLinecap="round"
          fill="none"
        />

        {/* Cheek blushes */}
        <ellipse cx="22" cy="36" rx="1.8" ry="1.1" fill="oklch(0.78 0.14 35)" opacity="0.55" />
        <ellipse cx="38" cy="36" rx="1.8" ry="1.1" fill="oklch(0.78 0.14 35)" opacity="0.55" />

        {/* Eyebrows */}
        <path
          d="M 22.5 23.5 L 28 25.4"
          stroke="oklch(0.32 0.10 30)"
          strokeWidth="1.6"
          strokeLinecap="round"
        />
        <path
          d="M 32 25.4 L 37.5 23.5"
          stroke="oklch(0.32 0.10 30)"
          strokeWidth="1.6"
          strokeLinecap="round"
        />

        {/* Eyes — wrapped in <g> so we can blink them together via CSS */}
        <g className={blink ? 'clippy-eyes' : ''}>
          <ellipse
            cx="26"
            cy="31"
            rx="2.6"
            ry="3.2"
            fill="oklch(0.20 0.03 45)"
          />
          <ellipse
            cx="34"
            cy="31"
            rx="2.6"
            ry="3.2"
            fill="oklch(0.20 0.03 45)"
          />
          {/* Eye shines */}
          <circle cx="27.1" cy="29.9" r="0.85" fill="white" />
          <circle cx="35.1" cy="29.9" r="0.85" fill="white" />
        </g>

        {/* Smile */}
        <path
          d="M 26 39 Q 30 43.5, 34 39"
          stroke="oklch(0.32 0.10 30)"
          strokeWidth="1.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Soft sphere highlight overlay */}
        <ellipse
          cx="24"
          cy="20"
          rx="9"
          ry="11"
          fill="url(#clippy-shine)"
          opacity="0.6"
        />
      </svg>

      {/* Thinking dots — only rendered when thinking */}
      {mood === 'thinking' && (
        <span
          className="absolute -right-2 top-3 flex gap-0.5 items-center"
          aria-hidden
        >
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="block h-1.5 w-1.5 rounded-full bg-primary clippy-dot"
              style={{ animationDelay: `${i * 0.18}s` }}
            />
          ))}
        </span>
      )}
    </span>
  );
}
