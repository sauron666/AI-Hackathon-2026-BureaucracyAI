'use client';

import { useState, useRef, useEffect } from 'react';
import { experimental_useObject as useObject } from 'ai/react';
import {
  Search,
  Send,
  Sparkles,
  ArrowLeft,
  Plus,
  ArrowRight,
  Mic,
  MicOff,
} from 'lucide-react';
import {
  ProcedureAnswerSchema,
  type Country,
  type Language,
  COUNTRY_NAMES,
  COUNTRY_FLAGS,
} from '@/lib/types';
import AnswerCard from './AnswerCard';
import BrowseMode from './BrowseMode';
import SkeletonCard from './SkeletonCard';
import ErrorBanner from './ErrorBanner';
import ClippyMascot from './ClippyMascot';
import WorldMap from './WorldMap';
import { cn } from '@/lib/utils';

export interface ChatRunSignal {
  nonce: number;
  question: string;
}

interface ChatInterfaceProps {
  country: Country;
  language: Language;
  runSignal?: ChatRunSignal | null;
}

const SAMPLE_QUESTIONS: { country: Country; flag: string; text: string }[] = [
  { country: 'DE', flag: '🇩🇪', text: 'How do I register my address in Berlin?' },
  { country: 'NL', flag: '🇳🇱', text: 'How do I get a BSN number?' },
  { country: 'PT', flag: '🇵🇹', text: 'What is NIF and how do I get one?' },
  { country: 'ES', flag: '🇪🇸', text: 'How do I get my NIE in Spain?' },
];

export default function ChatInterface({
  country,
  language,
  runSignal,
}: ChatInterfaceProps) {
  const [input, setInput] = useState('');
  const [submittedQuestion, setSubmittedQuestion] = useState<string | null>(null);
  const [showBrowse, setShowBrowse] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const lastNonce = useRef<number | null>(null);
  const recognitionRef = useRef<any>(null);

  const { object, submit, isLoading, error, stop } = useObject({
    api: '/api/chat',
    schema: ProcedureAnswerSchema,
  });

  // Detect Web Speech API support once, on mount
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const w = window as any;
    setVoiceSupported(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition));
  }, []);

  const handleAsk = (question: string) => {
    const q = question.trim();
    if (!q || isLoading) return;
    setSubmittedQuestion(q);
    setInput(q);
    setShowBrowse(false);
    submit({ question: q, language, country });
  };

  // Voice — start/stop recognition, fill input as user speaks
  const langCode = (() => {
    const map: Record<string, string> = {
      en: 'en-US', bg: 'bg-BG', de: 'de-DE', nl: 'nl-NL',
      pt: 'pt-PT', es: 'es-ES', fr: 'fr-FR', tr: 'tr-TR',
    };
    return map[language] ?? 'en-US';
  })();

  const startListening = () => {
    if (!voiceSupported || listening) return;
    const w = window as any;
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    const r = new Ctor();
    r.continuous = false;
    r.interimResults = true;
    r.lang = langCode;

    r.onresult = (event: any) => {
      let transcript = '';
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setInput(transcript);
    };
    r.onerror = () => setListening(false);
    r.onend = () => setListening(false);
    r.start();
    recognitionRef.current = r;
    setListening(true);
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch {}
      recognitionRef.current = null;
    }
    setListening(false);
  };

  // Demo auto-submit: when runSignal arrives with a new nonce, fire it
  useEffect(() => {
    if (runSignal && runSignal.nonce !== lastNonce.current) {
      lastNonce.current = runSignal.nonce;
      handleAsk(runSignal.question);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runSignal]);

  const handleNewQuestion = () => {
    stop();
    setSubmittedQuestion(null);
    setInput('');
    setShowBrowse(false);
    inputRef.current?.focus();
  };

  useEffect(() => {
    if (!isLoading && submittedQuestion) inputRef.current?.blur();
  }, [isLoading, submittedQuestion]);

  const flag = COUNTRY_FLAGS[country] ?? '';
  const countryName = COUNTRY_NAMES[country] ?? country;

  /* -------------------------------------------------- */
  /* RESULT STATE                                        */
  /* -------------------------------------------------- */
  if (submittedQuestion) {
    return (
      <div className="space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1.5 min-w-0">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              <span>Your question</span>
              <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
              <span className="flex items-center gap-1">
                <span className="text-base leading-none">{flag}</span>
                {countryName}
              </span>
            </div>
            <h2 className="text-xl font-semibold leading-snug text-foreground">
              {submittedQuestion}
            </h2>
          </div>
          <button
            type="button"
            onClick={handleNewQuestion}
            className={cn(
              'shrink-0 inline-flex items-center gap-1.5 rounded-md',
              'border border-border bg-card px-3 py-1.5',
              'text-xs font-medium text-foreground',
              'transition-all hover:border-primary/40 hover:bg-secondary/60',
            )}
          >
            <Plus size={12} strokeWidth={2.25} />
            New question
          </button>
        </div>

        {error && (
          <ErrorBanner
            message={
              error.message ||
              "We couldn't load this answer. Check your connection and try again."
            }
            onRetry={() => handleAsk(submittedQuestion)}
          />
        )}

        {!error && !object && isLoading && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <ClippyMascot size={36} mood="thinking" />
              <span className="text-sm text-muted-foreground">
                Clippy is searching {countryName} procedures…
              </span>
            </div>
            <SkeletonCard variant="answer" />
          </div>
        )}

        {object && (
          <AnswerCard
            answer={object}
            isStreaming={isLoading}
            question={submittedQuestion}
            country={country}
            language={language}
          />
        )}
      </div>
    );
  }

  /* -------------------------------------------------- */
  /* BROWSE STATE                                        */
  /* -------------------------------------------------- */
  if (showBrowse) {
    return (
      <div className="space-y-6">
        <button
          type="button"
          onClick={() => setShowBrowse(false)}
          className={cn(
            'inline-flex items-center gap-1.5 text-sm font-medium',
            'text-muted-foreground hover:text-foreground transition-colors',
          )}
        >
          <ArrowLeft size={14} strokeWidth={2} />
          Back to ask
        </button>
        <BrowseMode country={country} onSelectQuestion={handleAsk} />
      </div>
    );
  }

  /* -------------------------------------------------- */
  /* EMPTY STATE — Hero with Clippy + WorldMap           */
  /* -------------------------------------------------- */
  return (
    <div className="relative">
      {/* Ambient orbs */}
      <div
        className="hero-orb -top-32 -left-32 h-72 w-72 bg-primary/15"
        aria-hidden
      />
      <div
        className="hero-orb -top-12 right-0 h-64 w-64 bg-accent/10"
        aria-hidden
      />

      <div className="relative space-y-12">
        {/* Headline + Clippy */}
        <div className="space-y-5 text-center">
          <span
            className={cn(
              'inline-flex items-center gap-1.5 rounded-full',
              'border border-border bg-card/60 backdrop-blur-sm',
              'px-3 py-1 text-xs font-medium text-muted-foreground',
            )}
          >
            <Sparkles size={11} strokeWidth={2} className="text-primary" />
            Live · powered by Claude
          </span>

          <div className="flex justify-center">
            <ClippyMascot size={88} mood="waving" />
          </div>

          <div className="space-y-3">
            <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
              Navigate bureaucracy{' '}
              <span className="relative inline-block">
                without the headache
                <svg
                  className="absolute -bottom-2 left-0 right-0 h-3 w-full text-accent"
                  viewBox="0 0 600 14"
                  preserveAspectRatio="none"
                  fill="none"
                  aria-hidden
                >
                  <path
                    d="M2 9C100 4 200 2 300 6C400 10 500 4 598 9"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            </h1>
            <p className="text-pretty mx-auto max-w-xl text-base leading-relaxed text-muted-foreground">
              Step-by-step guidance for any government procedure across 18 countries — and counting. Hi, I'm Clippy. Ask me anything.
            </p>
          </div>
        </div>

        {/* Input card */}
        <div
          className={cn(
            'rounded-2xl border border-border bg-card p-3 shadow-xl',
            'transition-shadow focus-within:shadow-brand',
          )}
        >
          <div className="flex items-center gap-2 px-2">
            <Search size={18} strokeWidth={2} className="shrink-0 text-muted-foreground" />
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAsk(input);
              }}
              placeholder={
                listening
                  ? 'Listening… speak now'
                  : `Ask about any ${countryName} procedure…`
              }
              className={cn(
                'h-12 w-full bg-transparent px-1 text-base text-foreground',
                'placeholder:text-muted-foreground/70',
                'focus:outline-none',
              )}
              disabled={isLoading}
              aria-label="Your question"
            />

            {voiceSupported && (
              <button
                type="button"
                onClick={listening ? stopListening : startListening}
                disabled={isLoading}
                aria-label={listening ? 'Stop listening' : 'Voice input'}
                title={listening ? 'Stop listening' : 'Speak your question'}
                className={cn(
                  'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg',
                  'transition-all relative',
                  listening
                    ? 'bg-primary text-primary-foreground'
                    : 'border border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground',
                  'disabled:opacity-40',
                )}
              >
                {listening ? (
                  <>
                    <MicOff size={14} strokeWidth={2.25} />
                    <span
                      className="absolute inset-0 rounded-lg bg-primary/40 fw-ping"
                      aria-hidden
                    />
                  </>
                ) : (
                  <Mic size={14} strokeWidth={2.25} />
                )}
              </button>
            )}

            <button
              type="button"
              onClick={() => handleAsk(input)}
              disabled={!input.trim() || isLoading}
              aria-label="Send"
              className={cn(
                'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg',
                'bg-primary text-primary-foreground shadow-brand',
                'transition-all hover:shadow-brand-strong active:scale-95',
                'disabled:opacity-40 disabled:shadow-none disabled:active:scale-100',
              )}
            >
              <Send size={14} strokeWidth={2.25} />
            </button>
          </div>
        </div>

        {/* World Map */}
        <section className="space-y-3">
          <div className="flex items-baseline justify-between">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Live coverage
              </div>
              <h2 className="text-base font-semibold text-foreground">
                Eighteen countries, one paperclip.
              </h2>
            </div>
            <span className="text-xs text-muted-foreground hidden sm:inline">
              Click a country to explore
            </span>
          </div>
          <div
            className={cn(
              'rounded-2xl border border-border bg-card/60 backdrop-blur-sm p-4 sm:p-6',
            )}
          >
            <WorldMap active={country} />
          </div>
        </section>

        {/* Sample chips */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Try one of these
            </span>
            <button
              type="button"
              onClick={() => setShowBrowse(true)}
              className="text-xs font-medium text-primary transition-opacity hover:opacity-80 inline-flex items-center gap-1"
            >
              Browse all procedures <ArrowRight size={11} strokeWidth={2.25} />
            </button>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            {SAMPLE_QUESTIONS.map((s, i) => (
              <button
                key={i}
                type="button"
                onClick={() => handleAsk(s.text)}
                className={cn(
                  'group flex items-center gap-2.5 rounded-lg border border-border',
                  'bg-card/80 px-3 py-2.5 text-left text-sm',
                  'transition-all hover:border-primary/40 hover:bg-card hover:shadow-md',
                )}
              >
                <span className="text-base leading-none">{s.flag}</span>
                <span className="flex-1 text-foreground">{s.text}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
