'use client';

import { useState, useRef, useEffect } from 'react';
import { Palette as PaletteIcon, Check } from 'lucide-react';
import { usePalette, PALETTES, type Palette } from '@/lib/storage';
import { cn } from '@/lib/utils';

export default function PalettePicker() {
  const [palette, setPalette] = usePalette();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    if (open) document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-label="Choose theme color"
        title="Theme"
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-md',
          'text-muted-foreground hover:bg-secondary hover:text-foreground',
          'transition-colors',
        )}
      >
        <PaletteIcon size={16} strokeWidth={2} />
      </button>

      {open && (
        <div
          className={cn(
            'absolute right-0 top-full mt-2 z-50',
            'min-w-[200px] rounded-lg border border-border bg-card shadow-xl',
            'p-2',
            'animate-in fade-in slide-in-from-top-1 duration-150',
          )}
        >
          <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Theme color
          </div>
          {(Object.entries(PALETTES) as [Palette, typeof PALETTES[Palette]][]).map(
            ([key, p]) => {
              const active = palette === key;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    setPalette(key);
                    setOpen(false);
                  }}
                  className={cn(
                    'w-full flex items-center gap-2.5 px-2 py-1.5 rounded-md',
                    'text-sm text-left transition-colors',
                    active ? 'bg-secondary' : 'hover:bg-secondary/60',
                  )}
                >
                  <span
                    className="flex h-4 w-4 rounded-full border border-border/40 shrink-0"
                    style={{ background: p.primary }}
                    aria-hidden
                  />
                  <span className="flex-1 text-foreground">{p.label}</span>
                  {active && <Check size={13} strokeWidth={2.5} className="text-primary" />}
                </button>
              );
            },
          )}
        </div>
      )}
    </div>
  );
}
