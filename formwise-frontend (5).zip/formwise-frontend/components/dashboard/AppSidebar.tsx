'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard,
  MessageSquare,
  FolderOpen,
  History,
  Settings,
  LogOut,
  Plus,
} from 'lucide-react';
import ClippyMascot from '@/components/ClippyMascot';
import { useMockUser } from '@/lib/storage';
import { cn } from '@/lib/utils';

const NAV = [
  { href: '/dashboard',         label: 'Dashboard', icon: LayoutDashboard },
  { href: '/dashboard/ask',     label: 'Ask',       icon: MessageSquare },
  { href: '/dashboard/browse',  label: 'Browse',    icon: FolderOpen },
  { href: '/dashboard/history', label: 'History',   icon: History },
];

export default function AppSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, signOut } = useMockUser();

  const handleSignOut = () => {
    signOut();
    router.push('/');
  };

  const initials = user?.name
    ? user.name
        .split(/\s+/)
        .slice(0, 2)
        .map((s) => s[0]?.toUpperCase())
        .join('')
    : 'FW';

  return (
    <aside
      className={cn(
        'fixed inset-y-0 left-0 z-30 hidden lg:flex w-64',
        'flex-col bg-sidebar border-r border-sidebar-border',
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 h-16 border-b border-sidebar-border">
        <ClippyMascot size={22} mood="static" ariaLabel="" />
        <Link href="/" className="text-lg font-bold tracking-tight text-foreground">
          FormWise
        </Link>
      </div>

      {/* New question CTA */}
      <div className="px-3 pt-4">
        <Link
          href="/dashboard/ask"
          className={cn(
            'flex items-center gap-2 w-full rounded-md',
            'bg-primary text-primary-foreground shadow-brand',
            'px-3 py-2 text-sm font-semibold',
            'transition-all hover:shadow-brand-strong active:scale-[0.99]',
          )}
        >
          <Plus size={14} strokeWidth={2.5} />
          New question
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 pt-4 space-y-1">
        {NAV.map((n) => {
          const active =
            n.href === '/dashboard'
              ? pathname === '/dashboard'
              : pathname.startsWith(n.href);
          const Icon = n.icon;
          return (
            <Link
              key={n.href}
              href={n.href}
              className={cn(
                'flex items-center gap-2.5 rounded-md px-3 py-2 text-sm',
                'transition-colors',
                active
                  ? 'bg-sidebar-accent text-foreground font-medium'
                  : 'text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground',
              )}
            >
              <Icon size={16} strokeWidth={2} />
              <span>{n.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* User card */}
      {user && (
        <div className="px-3 py-3 border-t border-sidebar-border">
          <div
            className={cn(
              'flex items-center gap-2.5 px-2 py-2 rounded-md',
              'hover:bg-sidebar-accent/60 transition-colors',
            )}
          >
            <span
              className={cn(
                'flex h-8 w-8 items-center justify-center rounded-full shrink-0',
                'bg-primary/10 text-primary text-xs font-semibold',
              )}
              aria-hidden
            >
              {initials}
            </span>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold truncate text-foreground">
                {user.name}
              </div>
              <div className="text-[10px] text-muted-foreground truncate">
                {user.email}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 mt-1 px-1">
            <Link
              href="/dashboard/settings"
              className={cn(
                'flex-1 inline-flex items-center gap-1.5 rounded-md px-2 py-1.5',
                'text-xs text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground transition-colors',
              )}
            >
              <Settings size={12} strokeWidth={2} />
              Settings
            </Link>
            <button
              type="button"
              onClick={handleSignOut}
              aria-label="Sign out"
              className={cn(
                'h-7 w-7 inline-flex items-center justify-center rounded-md',
                'text-muted-foreground hover:bg-sidebar-accent/60 hover:text-[var(--risk-high-fg)] transition-colors',
              )}
            >
              <LogOut size={12} strokeWidth={2} />
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}
