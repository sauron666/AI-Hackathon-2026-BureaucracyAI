'use client';

import { useState, useEffect } from 'react';
import { ArrowRight, X, Sparkles } from 'lucide-react';
import ClippyMascot from './ClippyMascot';
import { useOnboarding } from '@/lib/storage';
import { cn } from '@/lib/utils';

interface Step {
  title: string;
  body: string;
  pointTo?: string; // CSS selector to highlight (best-effort)
}

const STEPS: Step[] = [
  {
    title: "Hi! I'm Clippy 👋",
    body:
      "I'm your guide for any government procedure across 18 European countries. Let me show you around in 30 seconds.",
  },
  {
    title: 'Pick your country up top',
    body:
      'Top-right corner: country and language selectors. Everything below adapts — local document names, official offices, language of the answer.',
  },
  {
    title: 'Four ways to use me',
    body:
      'Ask a single question, plan a full relocation, compare countries side-by-side, or upload a contract for a risk check. Switch between them anytime.',
  },
  {
    title: 'Saved answers stay with you',
    body:
      'Tap the heart on any answer to keep it. The Saved tray bottom-left collects them across sessions — useful when paperwork drags on for weeks.',
  },
];

export default function Onboarding() {
  const { needsOnboarding, markDone } = useOnboarding();
  const [step, setStep] = useState(0);
  const [show, setShow] = useState(false);

  // Defer showing until after hydration so we don't flash on returning visitors
  useEffect(() => {
    if (needsOnboarding) {
      const t = setTimeout(() => setShow(true), 600);
      return () => clearTimeout(t);
    }
  }, [needsOnboarding]);

  if (!show || !needsOnboarding) return null;

  const current = STEPS[step];
  const isLast = step === STEPS.length - 1;

  const next = () => {
    if (isLast) {
      markDone();
      setShow(false);
    } else {
      setStep(step + 1);
    }
  };

  const skip = () => {
    markDone();
    setShow(false);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Welcome to FormWise"
      className="fixed inset-0 z-50 flex items-center justify-center px-4"
    >
      <div
        className="absolute inset-0 bg-background/85 backdrop-blur-md"
        onClick={skip}
      />

      <div
        className={cn(
          'relative w-full max-w-md',
          'bg-card border border-border rounded-2xl shadow-2xl',
          'p-6 sm:p-7',
          'animate-in fade-in zoom-in-95 duration-300',
        )}
      >
        {/* Skip in corner */}
        <button
          type="button"
          onClick={skip}
          aria-label="Skip onboarding"
          className={cn(
            'absolute right-3 top-3 h-8 w-8 inline-flex items-center justify-center',
            'rounded-md text-muted-foreground hover:bg-secondary transition-colors',
          )}
        >
          <X size={15} />
        </button>

        {/* Clippy + content */}
        <div className="flex flex-col items-center text-center space-y-5">
          <ClippyMascot
            size={72}
            mood={step === 0 ? 'waving' : step === STEPS.length - 1 ? 'idle' : 'thinking'}
          />

          <div className="space-y-2">
            <span
              className={cn(
                'inline-flex items-center gap-1.5 rounded-full',
                'border border-border bg-secondary/60 backdrop-blur-sm',
                'px-2.5 py-1 text-[10px] font-medium text-muted-foreground uppercase tracking-wider',
              )}
            >
              <Sparkles size={10} strokeWidth={2.25} className="text-primary" />
              Step {step + 1} of {STEPS.length}
            </span>
            <h2 className="text-lg sm:text-xl font-bold tracking-tight text-foreground">
              {current.title}
            </h2>
            <p className="text-sm leading-relaxed text-muted-foreground max-w-sm mx-auto">
              {current.body}
            </p>
          </div>

          {/* Step indicator */}
          <div className="flex items-center gap-1.5" aria-hidden>
            {STEPS.map((_, i) => (
              <span
                key={i}
                className={cn(
                  'h-1.5 rounded-full transition-all duration-300',
                  i === step
                    ? 'w-6 bg-primary'
                    : i < step
                      ? 'w-1.5 bg-primary/50'
                      : 'w-1.5 bg-border',
                )}
              />
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between gap-3 w-full pt-1">
            <button
              type="button"
              onClick={skip}
              className={cn(
                'text-xs font-medium text-muted-foreground hover:text-foreground transition-colors',
              )}
            >
              Skip tour
            </button>
            <button
              type="button"
              onClick={next}
              className={cn(
                'inline-flex items-center gap-1.5 rounded-lg',
                'bg-primary text-primary-foreground shadow-brand',
                'px-4 py-2 text-sm font-semibold',
                'transition-all hover:shadow-brand-strong active:scale-95',
              )}
            >
              {isLast ? 'Get started' : 'Next'}
              <ArrowRight size={13} strokeWidth={2.25} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
