'use client';

import {
  Home,
  Briefcase,
  Shield,
  FileText,
  Users,
  Car,
  GraduationCap,
  Heart,
  ChevronRight,
} from 'lucide-react';
import { COUNTRY_NAMES, COUNTRY_FLAGS, type Country } from '@/lib/types';
import { cn } from '@/lib/utils';

interface BrowseModeProps {
  country: Country;
  onSelectQuestion: (q: string) => void;
}

interface CategoryCard {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  examplePrompt: (country: string) => string;
  tone: 'primary' | 'accent';
}

const CATEGORIES: CategoryCard[] = [
  {
    id: 'address',
    title: 'Address registration',
    description: 'Register where you live',
    icon: <Home size={20} strokeWidth={2} />,
    examplePrompt: (c) => `How do I register my address in ${c}?`,
    tone: 'primary',
  },
  {
    id: 'work',
    title: 'Work & visas',
    description: 'Permits, visas, employment',
    icon: <Briefcase size={20} strokeWidth={2} />,
    examplePrompt: (c) => `What work permit do I need in ${c}?`,
    tone: 'accent',
  },
  {
    id: 'health',
    title: 'Health & insurance',
    description: 'Public coverage and registrations',
    icon: <Shield size={20} strokeWidth={2} />,
    examplePrompt: (c) => `How do I get health insurance in ${c}?`,
    tone: 'primary',
  },
  {
    id: 'tax',
    title: 'Tax & finance',
    description: 'Tax IDs, banking, declarations',
    icon: <FileText size={20} strokeWidth={2} />,
    examplePrompt: (c) => `How do I get a tax number in ${c}?`,
    tone: 'accent',
  },
  {
    id: 'family',
    title: 'Family & civil status',
    description: 'Marriage, partner, children',
    icon: <Users size={20} strokeWidth={2} />,
    examplePrompt: (c) =>
      `How does family reunification work in ${c}?`,
    tone: 'primary',
  },
  {
    id: 'driving',
    title: 'Driving & vehicles',
    description: 'Licenses, registrations',
    icon: <Car size={20} strokeWidth={2} />,
    examplePrompt: (c) =>
      `How do I exchange my foreign driver's license in ${c}?`,
    tone: 'accent',
  },
  {
    id: 'education',
    title: 'Education',
    description: 'Schools, recognition of degrees',
    icon: <GraduationCap size={20} strokeWidth={2} />,
    examplePrompt: (c) =>
      `How do I get my foreign degree recognized in ${c}?`,
    tone: 'primary',
  },
  {
    id: 'social',
    title: 'Social benefits',
    description: 'Pensions, child benefits, support',
    icon: <Heart size={20} strokeWidth={2} />,
    examplePrompt: (c) =>
      `What social benefits am I entitled to in ${c}?`,
    tone: 'accent',
  },
];

export default function BrowseMode({ country, onSelectQuestion }: BrowseModeProps) {
  const countryName = COUNTRY_NAMES[country] ?? country;
  const flag = COUNTRY_FLAGS[country] ?? '';

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="text-base leading-none">{flag}</span>
          <span>Browsing procedures for {countryName}</span>
        </div>
        <h2 className="text-2xl font-bold tracking-tight text-foreground">
          What do you need help with?
        </h2>
        <p className="text-sm text-muted-foreground">
          Pick a topic and we'll start a question for you. You can edit it before sending.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => onSelectQuestion(c.examplePrompt(countryName))}
            className={cn(
              'group flex items-start gap-3 rounded-xl border border-border bg-card p-4 text-left',
              'transition-all hover:border-primary/40 hover:shadow-md',
              'focus:outline-none focus:ring-2 focus:ring-ring/40',
            )}
          >
            <span
              className={cn(
                'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                'transition-transform group-hover:scale-105',
                c.tone === 'primary'
                  ? 'bg-primary/10 text-primary'
                  : 'bg-accent/10 text-accent',
              )}
            >
              {c.icon}
            </span>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-foreground">
                {c.title}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {c.description}
              </div>
            </div>
            <ChevronRight
              size={16}
              strokeWidth={2}
              className={cn(
                'mt-2 shrink-0 text-muted-foreground/60',
                'transition-all group-hover:translate-x-0.5 group-hover:text-primary',
              )}
              aria-hidden
            />
          </button>
        ))}
      </div>
    </div>
  );
}
