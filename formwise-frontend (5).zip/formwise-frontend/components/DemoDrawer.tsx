'use client';

import { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  X,
  ArrowRight,
  MessageSquare,
  CalendarDays,
  Scale,
  Upload,
  Command,
} from 'lucide-react';
import { COUNTRY_FLAGS } from '@/lib/types';
import { cn } from '@/lib/utils';

/**
 * DemoDrawer — the demo's "secret weapon".
 *
 * Renders only when NEXT_PUBLIC_DEMO_MODE === 'true'. A floating button
 * (bottom-right) opens a slide-up panel listing the 10 demo questions
 * from the AI-CONTEXT-FINAL spec. Selecting one fires onSelect with the
 * mode + payload — the parent page handles the actual routing & submit.
 *
 * Keyboard: ⌘K / Ctrl-K opens. Esc closes. Arrow keys navigate.
 *
 * Why this matters: the DEV-GUIDE demo script is 3.5 minutes. Typing each
 * question wastes precious seconds AND introduces typo risk on stage.
 * One click per scripted moment = zero stress.
 */

export type DemoMode = 'chat' | 'journey' | 'compare' | 'analyze';

export interface DemoSelection {
  id: string;
  mode: DemoMode;
  question?: string;
  country?: string;
  countries?: string[];
  fromCountry?: string;
  nationality?: string;
  purpose?: string;
  documentType?: string;
}

const DEMO_QUESTIONS: (DemoSelection & { label: string; tag?: string })[] = [
  {
    id: 'q1',
    mode: 'journey',
    label: 'Brazilian moving to Germany for work',
    tag: 'HERO · OPENS DEMO',
    country: 'DE',
    fromCountry: 'Brazil',
    nationality: 'Brazilian',
    purpose: 'work',
  },
  {
    id: 'q2',
    mode: 'chat',
    label: 'Indian partner joining me in the Netherlands',
    country: 'NL',
    question:
      "My Indian partner wants to join me in the Netherlands. What visa and permits does she need?",
  },
  {
    id: 'q3',
    mode: 'chat',
    label: 'British retiree to Portugal — NHR & residence',
    country: 'PT',
    question:
      "I want to retire in Portugal. I'm 61 and British. Tell me about the NHR tax regime and how to get a residence permit.",
  },
  {
    id: 'q4',
    mode: 'compare',
    label: 'Easiest EU country for non-EU tech work permit',
    countries: ['DE', 'NL', 'PT', 'ES'],
    question:
      "Which EU country has the easiest and fastest work permit process for a non-EU software engineer?",
  },
  {
    id: 'q5',
    mode: 'chat',
    label: 'US freelancer in Georgia long-term',
    country: 'GE',
    question:
      "I'm a US freelancer. Can I live in Georgia (the country) long-term legally? How does it work?",
  },
  {
    id: 'q6',
    mode: 'chat',
    label: 'German Ausländerbehörde letter — what they want',
    country: 'DE',
    question:
      "I received an official letter from the German Ausländerbehörde. What do they typically want and what are my deadlines?",
  },
  {
    id: 'q7',
    mode: 'analyze',
    label: 'German rental contract — risk check',
    country: 'DE',
    documentType: 'rental',
  },
  {
    id: 'q8',
    mode: 'analyze',
    label: 'Dutch employment contract — review',
    country: 'NL',
    documentType: 'employment',
  },
  {
    id: 'q9',
    mode: 'chat',
    label: 'Family reunification — mother to Spain',
    country: 'ES',
    question:
      "I want to bring my elderly mother to live with me in Spain under family reunification. What is the full process?",
  },
  {
    id: 'q10',
    mode: 'chat',
    label: 'Ukrainian in Poland — long-term legal status',
    country: 'PL',
    question:
      "I'm Ukrainian living in Poland on temporary protection. What are my options for longer-term legal status?",
  },
];

const MODE_META: Record<
  DemoMode,
  { label: string; icon: React.ReactNode; tone: 'primary' | 'accent' }
> = {
  chat: { label: 'Ask',          icon: <MessageSquare size={13} />, tone: 'primary' },
  journey: { label: 'Plan',      icon: <CalendarDays size={13} />,  tone: 'primary' },
  compare: { label: 'Compare',   icon: <Scale size={13} />,         tone: 'accent'  },
  analyze: { label: 'Analyze',   icon: <Upload size={13} />,        tone: 'accent'  },
};

interface DemoDrawerProps {
  onSelect: (s: DemoSelection) => void;
}

export default function DemoDrawer({ onSelect }: DemoDrawerProps) {
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);

  // Only show in demo mode
  const enabled =
    typeof process !== 'undefined' &&
    process.env.NEXT_PUBLIC_DEMO_MODE === 'true';

  // Keyboard: ⌘K open, Esc close, arrows navigate, Enter select
  useEffect(() => {
    if (!enabled) return;
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen((o) => !o);
        return;
      }
      if (!open) return;
      if (e.key === 'Escape') {
        setOpen(false);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setActiveIndex((i) => Math.min(i + 1, DEMO_QUESTIONS.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setActiveIndex((i) => Math.max(i - 1, 0));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const item = DEMO_QUESTIONS[activeIndex];
        if (item) {
          onSelect(item);
          setOpen(false);
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, activeIndex, onSelect, enabled]);

  if (!enabled) return null;

  return (
    <>
      {/* Floating launcher button */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Open demo questions"
        className={cn(
          'fixed bottom-5 right-5 z-30',
          'inline-flex items-center gap-2 rounded-full',
          'bg-primary text-primary-foreground',
          'pl-3 pr-3.5 py-2.5 text-xs font-semibold',
          'shadow-brand-strong border border-primary/40',
          'transition-all hover:scale-105 active:scale-95',
        )}
      >
        <Sparkles size={14} strokeWidth={2.25} />
        <span>Demo</span>
        <span
          className={cn(
            'hidden sm:inline-flex items-center gap-0.5 rounded',
            'bg-primary-foreground/15 px-1.5 py-0.5 ml-1',
            'text-[10px] font-mono font-medium opacity-90',
          )}
          aria-hidden
        >
          <Command size={9} strokeWidth={2.5} />K
        </span>
      </button>

      {/* Backdrop + drawer */}
      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Demo questions"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
        >
          <div
            className="absolute inset-0 bg-background/70 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />

          <div
            className={cn(
              'relative w-full sm:max-w-xl max-h-[85vh] sm:max-h-[680px]',
              'bg-card border border-border rounded-t-2xl sm:rounded-2xl',
              'shadow-2xl flex flex-col',
              'mx-0 sm:mx-4',
              'animate-in slide-in-from-bottom-2 fade-in duration-200',
            )}
          >
            <header className="flex items-center justify-between gap-3 px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className={cn(
                    'flex h-8 w-8 items-center justify-center rounded-lg',
                    'bg-primary/10 text-primary',
                  )}
                  aria-hidden
                >
                  <Sparkles size={16} strokeWidth={2.25} />
                </span>
                <div className="min-w-0">
                  <h2 className="text-sm font-semibold tracking-tight text-foreground">
                    Demo questions
                  </h2>
                  <p className="text-xs text-muted-foreground">
                    Ten scripted scenarios — click one to run it.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close"
                className={cn(
                  'h-8 w-8 inline-flex items-center justify-center rounded-md',
                  'text-muted-foreground hover:bg-secondary transition-colors',
                )}
              >
                <X size={15} />
              </button>
            </header>

            <div ref={listRef} className="flex-1 overflow-y-auto p-2">
              {DEMO_QUESTIONS.map((q, i) => {
                const meta = MODE_META[q.mode];
                const isActive = i === activeIndex;
                return (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => {
                      onSelect(q);
                      setOpen(false);
                    }}
                    onMouseEnter={() => setActiveIndex(i)}
                    className={cn(
                      'w-full flex items-center gap-3 p-3 rounded-lg text-left',
                      'transition-colors',
                      isActive ? 'bg-secondary' : 'hover:bg-secondary/60',
                    )}
                  >
                    <span
                      className={cn(
                        'shrink-0 inline-flex items-center justify-center',
                        'w-6 h-6 rounded-md',
                        'text-[10px] font-mono font-semibold',
                        'bg-secondary border border-border text-muted-foreground',
                      )}
                      aria-hidden
                    >
                      {q.id.toUpperCase()}
                    </span>

                    <span className="flex-1 min-w-0 space-y-1">
                      <span className="flex items-center gap-2 flex-wrap">
                        <span
                          className={cn(
                            'inline-flex items-center gap-1 rounded-full px-2 py-0.5',
                            'text-[10px] font-semibold uppercase tracking-wide',
                            meta.tone === 'primary'
                              ? 'bg-primary/10 text-primary'
                              : 'bg-accent/10 text-accent',
                          )}
                        >
                          {meta.icon} {meta.label}
                        </span>
                        {q.country && (
                          <span className="text-xs text-muted-foreground inline-flex items-center gap-1">
                            <span className="text-base leading-none">
                              {COUNTRY_FLAGS[q.country] ?? ''}
                            </span>
                          </span>
                        )}
                        {q.tag && (
                          <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-primary/80">
                            {q.tag}
                          </span>
                        )}
                      </span>
                      <span className="block text-sm text-foreground leading-snug">
                        {q.label}
                      </span>
                    </span>

                    <ArrowRight
                      size={14}
                      strokeWidth={2}
                      className={cn(
                        'shrink-0 text-muted-foreground transition-all',
                        isActive && 'translate-x-0.5 text-primary',
                      )}
                      aria-hidden
                    />
                  </button>
                );
              })}
            </div>

            <footer
              className={cn(
                'px-5 py-3 border-t border-border bg-secondary/40',
                'text-[11px] text-muted-foreground flex flex-wrap gap-x-4 gap-y-1 items-center justify-center',
              )}
            >
              <span>
                <kbd className="font-mono px-1.5 py-0.5 rounded border border-border bg-card">
                  ↑↓
                </kbd>{' '}
                navigate
              </span>
              <span>
                <kbd className="font-mono px-1.5 py-0.5 rounded border border-border bg-card">
                  ↵
                </kbd>{' '}
                run
              </span>
              <span>
                <kbd className="font-mono px-1.5 py-0.5 rounded border border-border bg-card">
                  esc
                </kbd>{' '}
                close
              </span>
            </footer>
          </div>
        </div>
      )}
    </>
  );
}
