'use client';

import { AlertCircle, RefreshCw, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ErrorBannerProps {
  title?: string;
  message: string;
  onRetry?: () => void;
  onDismiss?: () => void;
  className?: string;
}

export default function ErrorBanner({
  title = 'Something went wrong',
  message,
  onRetry,
  onDismiss,
  className,
}: ErrorBannerProps) {
  return (
    <div
      role="alert"
      className={cn(
        'flex items-start gap-3 rounded-lg border p-4',
        'border-l-4',
        'bg-risk-high border-l-[var(--risk-high-fg)] border-[var(--risk-high-bg)]',
        className,
      )}
    >
      <AlertCircle
        size={20}
        strokeWidth={2}
        className="mt-0.5 shrink-0"
        aria-hidden
      />

      <div className="flex-1 space-y-1">
        <div className="text-sm font-semibold leading-tight">{title}</div>
        <p className="text-sm leading-relaxed opacity-90">{message}</p>

        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className={cn(
              'mt-2 inline-flex items-center gap-1.5 rounded-md',
              'bg-card px-3 py-1.5 text-xs font-medium',
              'border border-current/20',
              'transition-all hover:bg-secondary',
            )}
          >
            <RefreshCw size={12} strokeWidth={2.25} />
            Try again
          </button>
        )}
      </div>

      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss"
          className="rounded-md p-1 transition-colors hover:bg-card/40"
        >
          <X size={16} />
        </button>
      )}
    </div>
  );
}
