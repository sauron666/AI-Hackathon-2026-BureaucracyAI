'use client';

import { useState, useEffect, useRef } from 'react';
import {
  Scale,
  ArrowRight,
  Plus,
  Sparkles,
  ThumbsUp,
  ThumbsDown,
  Clock,
  CreditCard,
} from 'lucide-react';
import {
  type CountryComparison,
  type Country,
  COUNTRY_NAMES,
  COUNTRY_FLAGS,
} from '@/lib/types';
import SkeletonCard from './SkeletonCard';
import ErrorBanner from './ErrorBanner';
import ClippyMascot from './ClippyMascot';
import { cn } from '@/lib/utils';

export interface CompareRunSignal {
  nonce: number;
  question: string;
  countries: Country[];
}

const SUGGESTED_COUNTRIES: Country[] = [
  'DE', 'NL', 'PT', 'ES', 'FR', 'PL', 'BG', 'AT', 'CZ', 'GE',
];

const DIFFICULTY_TONE = {
  easy: 'bg-risk-low',
  moderate: 'bg-risk-medium',
  complex: 'bg-risk-high',
} as const;

const SAMPLE_QUESTIONS = [
  'Which EU country has the easiest work permit for non-EU software engineers?',
  'Where is it cheapest and fastest to register a residence as a digital nomad?',
  'Which country is best for retirees on a UK pension?',
];

interface CountryCompareProps {
  defaultCountries?: Country[];
  runSignal?: CompareRunSignal | null;
}

export default function CountryCompare({
  defaultCountries = ['DE', 'NL', 'PT', 'ES'],
  runSignal,
}: CountryCompareProps) {
  const [question, setQuestion] = useState('');
  const [selected, setSelected] = useState<Country[]>(defaultCountries);
  const [comparison, setComparison] = useState<CountryComparison | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedQuestion, setSubmittedQuestion] = useState<string | null>(null);
  const lastNonce = useRef<number | null>(null);

  // Demo auto-submit
  useEffect(() => {
    if (runSignal && runSignal.nonce !== lastNonce.current) {
      lastNonce.current = runSignal.nonce;
      setQuestion(runSignal.question);
      setSelected(runSignal.countries);
      const t = setTimeout(() => {
        (async () => {
          setLoading(true);
          setError(null);
          setComparison(null);
          setSubmittedQuestion(runSignal.question);
          try {
            const res = await fetch('/api/compare', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                question: runSignal.question,
                countries: runSignal.countries,
              }),
            });
            if (!res.ok) throw new Error(`Request failed (${res.status})`);
            const data = (await res.json()) as CountryComparison;
            setComparison(data);
          } catch (e) {
            setError(
              e instanceof Error
                ? e.message
                : "We couldn't run that comparison. Please try again.",
            );
          } finally {
            setLoading(false);
          }
        })();
      }, 60);
      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runSignal]);

  const toggle = (c: Country) => {
    setSelected((prev) => {
      if (prev.includes(c)) return prev.filter((x) => x !== c);
      if (prev.length >= 5) return prev; // soft cap to keep render readable
      return [...prev, c];
    });
  };

  const submit = async (q: string = question) => {
    const trimmed = q.trim();
    if (!trimmed || selected.length < 2 || loading) return;
    setLoading(true);
    setError(null);
    setComparison(null);
    setSubmittedQuestion(trimmed);
    try {
      const res = await fetch('/api/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: trimmed, countries: selected }),
      });
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = (await res.json()) as CountryComparison;
      setComparison(data);
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "We couldn't run that comparison. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setComparison(null);
    setError(null);
    setSubmittedQuestion(null);
  };

  /* -------------------------------------------------- */
  /* RESULT STATE                                        */
  /* -------------------------------------------------- */
  if (comparison || loading || error) {
    return (
      <div className="space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1.5 min-w-0">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Comparing {selected.length} countries
            </div>
            <h2 className="text-xl font-semibold leading-snug text-foreground">
              {comparison?.question_interpreted || submittedQuestion}
            </h2>
          </div>
          <button
            type="button"
            onClick={reset}
            className={cn(
              'shrink-0 inline-flex items-center gap-1.5 rounded-md',
              'border border-border bg-card px-3 py-1.5',
              'text-xs font-medium text-foreground',
              'transition-all hover:border-primary/40 hover:bg-secondary/60',
            )}
          >
            <Plus size={12} strokeWidth={2.25} />
            New comparison
          </button>
        </div>

        {error && (
          <ErrorBanner message={error} onRetry={() => submit(submittedQuestion ?? '')} onDismiss={reset} />
        )}

        {loading && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <ClippyMascot size={36} mood="thinking" />
              <span className="text-sm text-muted-foreground">
                Comparing {selected.length} countries side by side…
              </span>
            </div>
            <SkeletonCard variant="compare" />
          </div>
        )}

        {comparison && (
          <>
            <div className="grid gap-4 sm:grid-cols-2">
              {comparison.countries.map((c) => (
                <article
                  key={c.country_code}
                  className={cn(
                    'rounded-lg border border-border bg-card p-5 space-y-3',
                    'transition-shadow hover:shadow-md',
                  )}
                >
                  <header className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-xl leading-none shrink-0">
                        {COUNTRY_FLAGS[c.country_code] ?? ''}
                      </span>
                      <h3 className="text-base font-semibold truncate text-foreground">
                        {c.country_name}
                      </h3>
                    </div>
                    <span
                      className={cn(
                        'shrink-0 inline-flex items-center rounded-full px-2.5 py-0.5',
                        'text-[10px] font-semibold uppercase tracking-wide',
                        DIFFICULTY_TONE[c.difficulty],
                      )}
                    >
                      {c.difficulty}
                    </span>
                  </header>

                  <p className="text-sm leading-relaxed text-foreground">
                    {c.summary}
                  </p>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    {c.processing_time && (
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Clock size={12} strokeWidth={2} />
                        <span className="font-mono">{c.processing_time}</span>
                      </div>
                    )}
                    {c.typical_cost && (
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <CreditCard size={12} strokeWidth={2} />
                        <span className="font-mono">{c.typical_cost}</span>
                      </div>
                    )}
                  </div>

                  {(c.key_advantage || c.key_disadvantage) && (
                    <div className="space-y-1.5 pt-2 border-t border-border/60">
                      {c.key_advantage && (
                        <div className="flex items-start gap-2 text-xs leading-relaxed">
                          <ThumbsUp
                            size={12}
                            strokeWidth={2}
                            className="mt-0.5 shrink-0 text-accent"
                            aria-hidden
                          />
                          <span className="text-foreground">{c.key_advantage}</span>
                        </div>
                      )}
                      {c.key_disadvantage && (
                        <div className="flex items-start gap-2 text-xs leading-relaxed">
                          <ThumbsDown
                            size={12}
                            strokeWidth={2}
                            className="mt-0.5 shrink-0 text-[var(--risk-high-fg)]"
                            aria-hidden
                          />
                          <span className="text-foreground">{c.key_disadvantage}</span>
                        </div>
                      )}
                    </div>
                  )}
                </article>
              ))}
            </div>

            {/* Recommendation */}
            {comparison.recommendation && (
              <div
                className={cn(
                  'rounded-xl border border-primary/20 p-5',
                  'bg-gradient-to-br from-primary/5 via-accent/5 to-transparent',
                )}
              >
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-primary mb-2">
                  <Sparkles size={12} strokeWidth={2} />
                  Recommendation
                </div>
                <p className="text-base font-semibold leading-relaxed text-foreground">
                  {comparison.recommendation}
                </p>
              </div>
            )}
          </>
        )}
      </div>
    );
  }

  /* -------------------------------------------------- */
  /* FORM STATE                                          */
  /* -------------------------------------------------- */
  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight text-foreground">
          Compare countries
        </h2>
        <p className="text-sm text-muted-foreground">
          Ask the same question across multiple countries side-by-side. Pick 2–5 countries and we'll lay out the trade-offs.
        </p>
      </div>

      {/* Country picker */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Countries to compare
          </label>
          <span className="text-xs text-muted-foreground">
            {selected.length} selected
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          {SUGGESTED_COUNTRIES.map((c) => {
            const active = selected.includes(c);
            return (
              <button
                key={c}
                type="button"
                onClick={() => toggle(c)}
                aria-pressed={active}
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5',
                  'text-sm font-medium transition-all',
                  active
                    ? 'border-primary bg-primary text-primary-foreground shadow-brand'
                    : 'border-border bg-card text-foreground hover:border-primary/40',
                )}
              >
                <span className="text-base leading-none">
                  {COUNTRY_FLAGS[c] ?? ''}
                </span>
                <span>{COUNTRY_NAMES[c] ?? c}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Question input */}
      <div className="space-y-3">
        <label
          htmlFor="compare-q"
          className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
        >
          Your question
        </label>
        <div
          className={cn(
            'rounded-xl border border-border bg-card p-3 shadow-sm',
            'transition-shadow focus-within:shadow-brand',
          )}
        >
          <div className="flex items-center gap-2 px-2">
            <Scale size={18} strokeWidth={2} className="shrink-0 text-muted-foreground" />
            <input
              id="compare-q"
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submit()}
              placeholder="e.g. Which country has the fastest work permit?"
              className={cn(
                'h-12 w-full bg-transparent px-1 text-base text-foreground',
                'placeholder:text-muted-foreground/70 focus:outline-none',
              )}
            />
            <button
              type="button"
              onClick={() => submit()}
              disabled={!question.trim() || selected.length < 2}
              aria-label="Compare"
              className={cn(
                'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg',
                'bg-primary text-primary-foreground shadow-brand',
                'transition-all hover:shadow-brand-strong active:scale-95',
                'disabled:opacity-40 disabled:shadow-none disabled:active:scale-100',
              )}
            >
              <ArrowRight size={14} strokeWidth={2.25} />
            </button>
          </div>
        </div>
        {selected.length < 2 && (
          <p className="text-xs text-muted-foreground">
            Pick at least two countries to compare.
          </p>
        )}
      </div>

      {/* Sample comparisons */}
      <div className="space-y-3">
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Try one of these
        </span>
        <div className="space-y-2">
          {SAMPLE_QUESTIONS.map((q, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setQuestion(q);
                submit(q);
              }}
              disabled={selected.length < 2}
              className={cn(
                'group flex w-full items-center gap-2.5 rounded-lg border border-border',
                'bg-card/80 px-3 py-2.5 text-left text-sm',
                'transition-all hover:border-primary/40 hover:bg-card hover:shadow-md',
                'disabled:opacity-50 disabled:cursor-not-allowed',
              )}
            >
              <Scale
                size={14}
                strokeWidth={2}
                className="shrink-0 text-primary"
                aria-hidden
              />
              <span className="flex-1 text-foreground">{q}</span>
              <ArrowRight
                size={12}
                strokeWidth={2}
                className="shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-primary"
                aria-hidden
              />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
