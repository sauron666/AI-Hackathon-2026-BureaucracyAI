'use client';

import { useState } from 'react';
import { Heart, X, Trash2, ArrowRight, Inbox } from 'lucide-react';
import { useSavedAnswers, type SavedAnswer } from '@/lib/storage';
import { COUNTRY_FLAGS, COUNTRY_NAMES } from '@/lib/types';
import { cn } from '@/lib/utils';

interface SavedDrawerProps {
  /** Called when user re-opens a saved item — parent should switch to chat + run it. */
  onReopen?: (entry: SavedAnswer) => void;
}

function formatRelative(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d} d ago`;
  return new Date(ts).toLocaleDateString();
}

export default function SavedDrawer({ onReopen }: SavedDrawerProps) {
  const [open, setOpen] = useState(false);
  const { saved, remove, clear } = useSavedAnswers();
  const count = saved.length;

  return (
    <>
      {/* Floating launcher (only when there's something saved, OR always — let's show always for discoverability) */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label={`Open saved answers (${count})`}
        className={cn(
          'fixed bottom-5 left-5 z-30',
          'inline-flex items-center gap-1.5 rounded-full',
          'border border-border bg-card backdrop-blur-sm',
          'pl-2.5 pr-3 py-2 text-xs font-semibold text-foreground',
          'shadow-lg transition-all hover:scale-105 hover:border-primary/40',
        )}
      >
        <Heart
          size={13}
          strokeWidth={2.25}
          className={count > 0 ? 'text-[oklch(0.55_0.18_25)]' : 'text-muted-foreground'}
          fill={count > 0 ? 'currentColor' : 'none'}
        />
        <span>Saved</span>
        {count > 0 && (
          <span
            className={cn(
              'inline-flex items-center justify-center rounded-full',
              'bg-primary text-primary-foreground',
              'h-4 min-w-4 px-1 text-[10px] font-bold',
            )}
            aria-hidden
          >
            {count}
          </span>
        )}
      </button>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Saved answers"
          className="fixed inset-0 z-50"
        >
          <div
            className="absolute inset-0 bg-background/70 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />

          <aside
            className={cn(
              'absolute right-0 top-0 bottom-0 w-full sm:max-w-md',
              'bg-card border-l border-border shadow-2xl flex flex-col',
              'animate-in slide-in-from-right-2 duration-200',
            )}
          >
            <header className="flex items-center justify-between gap-3 px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className={cn(
                    'flex h-8 w-8 items-center justify-center rounded-lg',
                    'bg-primary/10 text-primary',
                  )}
                  aria-hidden
                >
                  <Heart size={15} strokeWidth={2.25} />
                </span>
                <div className="min-w-0">
                  <h2 className="text-sm font-semibold tracking-tight text-foreground">
                    Your saved answers
                  </h2>
                  <p className="text-xs text-muted-foreground">
                    {count === 0
                      ? 'Star answers as you go to keep them here.'
                      : `${count} saved · stored on this device only.`}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close"
                className={cn(
                  'h-8 w-8 inline-flex items-center justify-center rounded-md',
                  'text-muted-foreground hover:bg-secondary transition-colors',
                )}
              >
                <X size={15} />
              </button>
            </header>

            <div className="flex-1 overflow-y-auto p-3">
              {count === 0 ? (
                <div className="flex flex-col items-center justify-center text-center px-6 py-16 space-y-3">
                  <span
                    className={cn(
                      'flex h-12 w-12 items-center justify-center rounded-2xl',
                      'bg-secondary text-muted-foreground',
                    )}
                    aria-hidden
                  >
                    <Inbox size={20} strokeWidth={1.75} />
                  </span>
                  <div>
                    <div className="text-sm font-semibold text-foreground">
                      Nothing saved yet
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 max-w-xs">
                      Tap the heart on any answer to save it here for later. Saved answers stay on this device.
                    </p>
                  </div>
                </div>
              ) : (
                <ul className="space-y-2">
                  {saved.map((s) => (
                    <li
                      key={s.id}
                      className={cn(
                        'group rounded-lg border border-border bg-card p-3',
                        'hover:border-primary/40 hover:shadow-md transition-all',
                      )}
                    >
                      <div className="flex items-start gap-2 mb-1.5">
                        <span className="text-base leading-none">
                          {COUNTRY_FLAGS[s.country] ?? ''}
                        </span>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-semibold text-foreground line-clamp-2">
                            {s.question}
                          </div>
                          <div className="text-[11px] text-muted-foreground mt-0.5">
                            {COUNTRY_NAMES[s.country] ?? s.country} · {formatRelative(s.savedAt)}
                          </div>
                        </div>
                      </div>
                      {s.summary && (
                        <p className="text-xs text-muted-foreground line-clamp-3 leading-relaxed mt-1">
                          {s.summary}
                        </p>
                      )}
                      <div className="flex items-center justify-end gap-1 mt-2 pt-2 border-t border-border/60">
                        <button
                          type="button"
                          onClick={() => remove(s.id)}
                          aria-label="Remove from saved"
                          title="Remove"
                          className={cn(
                            'h-7 w-7 inline-flex items-center justify-center rounded-md',
                            'text-muted-foreground hover:text-[var(--risk-high-fg)] hover:bg-secondary transition-colors',
                          )}
                        >
                          <Trash2 size={12} strokeWidth={2} />
                        </button>
                        {onReopen && (
                          <button
                            type="button"
                            onClick={() => {
                              onReopen(s);
                              setOpen(false);
                            }}
                            className={cn(
                              'inline-flex items-center gap-1 rounded-md',
                              'bg-primary text-primary-foreground px-2.5 py-1',
                              'text-[11px] font-medium',
                              'transition-all hover:shadow-brand',
                            )}
                          >
                            Re-ask <ArrowRight size={11} strokeWidth={2.25} />
                          </button>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {count > 0 && (
              <footer className="border-t border-border px-5 py-3 bg-secondary/40">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Clear all saved answers? This cannot be undone.')) {
                      clear();
                    }
                  }}
                  className="text-[11px] text-muted-foreground hover:text-[var(--risk-high-fg)] transition-colors"
                >
                  Clear all
                </button>
              </footer>
            )}
          </aside>
        </div>
      )}
    </>
  );
}
