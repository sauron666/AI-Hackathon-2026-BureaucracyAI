'use client';

import { useState, useEffect, useRef } from 'react';
import { Upload, FileText, AlertCircle, RefreshCw, Plus, Sparkles } from 'lucide-react';
import { UploadDropzone } from '@/lib/uploadthing';
import { type DocumentRisk, type Country, COUNTRY_NAMES } from '@/lib/types';
import DocumentAnalysisCard from './DocumentAnalysisCard';
import SkeletonCard from './SkeletonCard';
import ErrorBanner from './ErrorBanner';
import ClippyMascot from './ClippyMascot';
import { cn } from '@/lib/utils';

type DocumentType = 'rental' | 'employment' | 'official_letter' | 'contract';

export interface AnalyzeRunSignal {
  nonce: number;
  documentType: string;
}

const DOC_TYPES: { value: DocumentType; label: string; description: string }[] = [
  { value: 'rental', label: 'Rental contract', description: 'Lease, tenancy agreement' },
  { value: 'employment', label: 'Employment contract', description: 'Job offer, work contract' },
  { value: 'official_letter', label: 'Official letter', description: 'Government correspondence' },
  { value: 'contract', label: 'Other contract', description: 'General agreement or document' },
];

interface UploadAnalyzeProps {
  country: Country;
  runSignal?: AnalyzeRunSignal | null;
}

type Stage = 'select' | 'uploading' | 'analyzing' | 'done' | 'error';

interface UploadedFile {
  url: string;
  name: string;
  documentType: DocumentType;
  country: Country;
}

export default function UploadAnalyze({ country, runSignal }: UploadAnalyzeProps) {
  const [docType, setDocType] = useState<DocumentType>('rental');
  const [stage, setStage] = useState<Stage>('select');
  const [file, setFile] = useState<UploadedFile | null>(null);
  const [risk, setRisk] = useState<DocumentRisk | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const lastNonce = useRef<number | null>(null);

  const reset = () => {
    setStage('select');
    setFile(null);
    setRisk(null);
    setErrorMessage('');
  };

  // Demo signal: switch doc type and auto-run sample analysis
  useEffect(() => {
    if (runSignal && runSignal.nonce !== lastNonce.current) {
      lastNonce.current = runSignal.nonce;
      const dt = runSignal.documentType as DocumentType;
      setDocType(dt);
      const sample: UploadedFile = {
        url: 'demo://sample-' + dt,
        name: `Sample ${dt.replace('_', ' ')}.pdf`,
        documentType: dt,
        country,
      };
      setFile(sample);
      runAnalysis(sample);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runSignal]);

  const runAnalysis = async (f: UploadedFile) => {
    setStage('analyzing');
    try {
      // 300ms delay per AI-CONTEXT — UploadThing URLs aren't immediately accessible
      await new Promise((r) => setTimeout(r, 300));

      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          file_url: f.url,
          document_type: f.documentType,
          country: f.country,
        }),
      });

      if (!res.ok) throw new Error(`Analysis failed (${res.status})`);
      const data = (await res.json()) as DocumentRisk;
      setRisk(data);
      setStage('done');
    } catch (e) {
      setErrorMessage(
        e instanceof Error
          ? e.message
          : "We couldn't analyze that document. Please try again.",
      );
      setStage('error');
    }
  };

  /* -------------------------------------------------- */
  /* DONE — show analysis                                */
  /* -------------------------------------------------- */
  if (stage === 'done' && risk && file) {
    return (
      <div className="space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 min-w-0">
            <span
              className={cn(
                'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl',
                'bg-primary/10 text-primary',
              )}
              aria-hidden
            >
              <FileText size={22} strokeWidth={2} />
            </span>
            <div className="min-w-0">
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Document analyzed
              </div>
              <div className="text-base font-semibold truncate text-foreground">
                {file.name}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {DOC_TYPES.find((d) => d.value === file.documentType)?.label} ·{' '}
                {COUNTRY_NAMES[file.country] ?? file.country} jurisdiction
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={reset}
            className={cn(
              'shrink-0 inline-flex items-center gap-1.5 rounded-md',
              'border border-border bg-card px-3 py-1.5',
              'text-xs font-medium text-foreground',
              'transition-all hover:border-primary/40 hover:bg-secondary/60',
            )}
          >
            <Plus size={12} strokeWidth={2.25} />
            Analyze another
          </button>
        </div>

        <DocumentAnalysisCard risk={risk} />
      </div>
    );
  }

  /* -------------------------------------------------- */
  /* ANALYZING — skeleton                                */
  /* -------------------------------------------------- */
  if (stage === 'analyzing' && file) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inset-0 rounded-full bg-primary fw-ping" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-primary" />
          </span>
          <span className="text-sm text-muted-foreground">
            Analyzing {file.name} against {COUNTRY_NAMES[file.country] ?? file.country} legal standards…
          </span>
        </div>
        <SkeletonCard variant="risk" />
      </div>
    );
  }

  /* -------------------------------------------------- */
  /* ERROR                                               */
  /* -------------------------------------------------- */
  if (stage === 'error') {
    return (
      <div className="space-y-6">
        <ErrorBanner
          title="Analysis failed"
          message={errorMessage}
          onRetry={file ? () => runAnalysis(file) : undefined}
          onDismiss={reset}
        />
      </div>
    );
  }

  /* -------------------------------------------------- */
  /* SELECT — type picker + dropzone                     */
  /* -------------------------------------------------- */
  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight text-foreground">
          Analyze a document
        </h2>
        <p className="text-sm text-muted-foreground">
          Upload a contract or official letter and we'll flag risky clauses, missing protections, and what you should push back on before signing.
        </p>
      </div>

      {/* Demo mode — preview the analysis flow with sample document */}
      {process.env.NEXT_PUBLIC_DEMO_MODE === 'true' && (
        <button
          type="button"
          onClick={() => {
            const sample: UploadedFile = {
              url: 'demo://sample-rental-contract',
              name: `Sample ${DOC_TYPES.find((d) => d.value === docType)?.label.toLowerCase()}.pdf`,
              documentType: docType,
              country,
            };
            setFile(sample);
            runAnalysis(sample);
          }}
          className={cn(
            'flex w-full items-center gap-3 rounded-xl border border-primary/20 px-4 py-3 text-left',
            'bg-gradient-to-br from-primary/5 via-accent/5 to-transparent',
            'transition-all hover:border-primary/40 hover:shadow-md',
          )}
        >
          <span
            className={cn(
              'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
              'bg-primary/10 text-primary',
            )}
            aria-hidden
          >
            <Sparkles size={18} strokeWidth={2} />
          </span>
          <div className="flex-1">
            <div className="text-sm font-semibold text-foreground">
              Try with a sample document
            </div>
            <div className="text-xs text-muted-foreground mt-0.5">
              Skip the upload and preview the analysis flow with a sample of the selected document type.
            </div>
          </div>
        </button>
      )}

      {/* Document type */}
      <div className="space-y-3">
        <label
          htmlFor="doc-type"
          className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
        >
          Document type
        </label>
        <div className="grid gap-2 sm:grid-cols-2">
          {DOC_TYPES.map((dt) => {
            const active = docType === dt.value;
            return (
              <button
                key={dt.value}
                type="button"
                onClick={() => setDocType(dt.value)}
                className={cn(
                  'rounded-lg border p-3.5 text-left transition-all',
                  active
                    ? 'border-primary bg-primary/5 shadow-brand'
                    : 'border-border bg-card hover:border-primary/40 hover:bg-secondary/40',
                )}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="text-sm font-semibold text-foreground">
                    {dt.label}
                  </div>
                  <span
                    aria-hidden
                    className={cn(
                      'mt-0.5 h-3.5 w-3.5 shrink-0 rounded-full border-2',
                      active
                        ? 'border-primary bg-primary'
                        : 'border-border bg-card',
                    )}
                  />
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {dt.description}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Dropzone */}
      <div className="space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Upload
        </div>
        <div
          className={cn(
            'rounded-xl border-2 border-dashed border-border bg-card/40 p-6',
            'transition-colors hover:border-primary/40',
          )}
        >
          <UploadDropzone
            endpoint="documentUploader"
            input={{
              country,
              mode: 'analyze',
              document_type: docType,
            }}
            onUploadBegin={() => {
              setStage('uploading');
              setErrorMessage('');
            }}
            onClientUploadComplete={(res) => {
              if (!res || res.length === 0) return;
              const r = res[0];
              const uploaded: UploadedFile = {
                url: r.url,
                name: r.name ?? 'document',
                documentType: docType,
                country,
              };
              setFile(uploaded);
              runAnalysis(uploaded);
            }}
            onUploadError={(err) => {
              setErrorMessage(err.message || 'Upload failed.');
              setStage('error');
            }}
            appearance={{
              container:
                'flex flex-col items-center gap-3 py-4',
              label: 'text-sm font-medium text-foreground cursor-pointer',
              allowedContent: 'text-xs text-muted-foreground',
              button:
                'mt-2 inline-flex items-center gap-1.5 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-brand transition-all hover:shadow-brand-strong',
            }}
            content={{
              uploadIcon: () => (
                <Upload
                  size={28}
                  strokeWidth={1.75}
                  className="text-primary"
                  aria-hidden
                />
              ),
              label: 'Drop a PDF or DOCX here, or click to browse',
              allowedContent: 'PDF up to 16 MB · DOCX up to 8 MB',
              button: ({ ready, isUploading }) => {
                if (!ready) return 'Loading…';
                if (isUploading) return 'Uploading…';
                return 'Choose file';
              },
            }}
          />
        </div>

        <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
          <AlertCircle size={12} strokeWidth={2} className="mt-0.5 shrink-0" aria-hidden />
          Documents are analyzed for risk only and not stored. The analysis runs against{' '}
          <span className="font-medium text-foreground">
            {COUNTRY_NAMES[country] ?? country}
          </span>{' '}
          legal standards.
        </p>
      </div>
    </div>
  );
}
