# FormWise Frontend — Integration Guide

This bundle is **Dev 4's complete frontend** for `VikoPiko/AI-Hackathon-2026-Bureaucracy`, faithful to the FormWise design system (terracotta + sage on warm cream, Geist, lucide-react).

## ⚡ Quick preview (no backend needed)

The bundle ships **mock API routes** for every endpoint, so you can see the whole UI working with realistic content while Dev 1/2/3 are still building the real backend.

```bash
cd formwise-frontend
npm install
npm run dev
```

Open http://localhost:3000 — all four modes work:

- **Ask** — type any question, sample chips for DE / NL / PT / ES return realistic streaming answers. Hero shows **Clippy waving** + the **interactive World Map**.
- **Relocation plan** — fill the form (or use demo prefill) and see the 4-phase roadmap
- **Compare** — pick countries and a question, see side-by-side cards + recommendation
- **Analyze doc** — click "Try with a sample document" or use the Demo drawer to skip UploadThing and preview the risk analysis

**Press ⌘K (Ctrl+K on Windows/Linux) to open the Demo drawer** — one-click access to all 10 scripted demo questions for the live presentation. Each entry switches mode, sets the country, and auto-runs.

The mocks live in `app/api/{chat,analyze,journey,compare}/route.ts` and are clearly marked. **Replace each one with the real spec from `AI-CONTEXT-FINAL.md` as Dev 2 ships them** — the components on the client side need no changes.

When `NEXT_PUBLIC_DEMO_MODE=false` (or unset), the "Try with a sample document" button and the floating Demo launcher disappear. Set this once you have UploadThing and `/api/analyze` running for real.

---

## 🏆 Why this design wins the hackathon

The DEV-GUIDE rubric scores: 30% Idea & Potential · 25% AI Integration · 25% UI/UX · 20% Execution. Here's how the bundle hits each:

**30% Idea & Potential — explicitly asks for *"World map UI, 15+ countries, expansion pitch"*:**
- `components/WorldMap.tsx` — interactive constellation map with all 18 supported countries shown as dots with pulsing glows on the active one, plus three dashed "ghost" nodes (BR, US, IN) labelled as the planned expansion. Stats strip below: *"18 countries live · 200+ procedures · 3 launching this year"*. This is the visual centerpiece judges see first when the demo opens.
- `components/ClippyMascot.tsx` — branded paperclip mascot ("Clippy") makes the product memorable beyond the demo. Perfect thematic fit: bureaucracy = paperwork = paperclip.

**25% UI/UX — explicitly asks for *"polished answer card, smooth upload→analysis flow"*:**
- `AnswerCard` ships a circular **confidence ring** (38px ring, smoothly animates from 0 → confidence value, color shifts terracotta→sage as confidence rises)
- Streaming caret blinks while content is incomplete; every section is guarded so partial JSON doesn't crash
- Loading states show **Clippy with thinking dots** and the contextual line *"Clippy is searching {country} procedures…"* — gives perceived speed
- `UploadAnalyze` has a one-click "Try with a sample document" path for the demo and a real UploadThing dropzone for production

**25% Presentation — `DemoDrawer` is your stage safety net:**
- Floating button bottom-right + ⌘K shortcut
- All 10 scripted questions; one click switches mode, sets country, auto-submits
- No typing on stage = no typos = no awkward silences

**20% Execution:** Mock API routes mean the UI works end-to-end *today*, before any backend is wired. Production build verified clean (`tsc --noEmit` and `next build` both pass with zero errors).

---

## What's in the box


```
formwise-frontend/
├── tailwind.config.ts          ← Tailwind v3.4 config (CSS-variable theme)
├── app/
│   ├── globals.css             ← Design tokens + base styles + animations
│   ├── layout.tsx              ← Root layout, Geist via @import
│   ├── page.tsx                ← Main page, four-mode switcher + demo wiring
│   └── api/
│       ├── chat/route.ts       ← MOCK streaming endpoint (replace with Dev 2's)
│       ├── analyze/route.ts    ← MOCK doc-analysis endpoint
│       ├── journey/route.ts    ← MOCK relocation-roadmap endpoint
│       ├── compare/route.ts    ← MOCK country-comparison endpoint
│       └── uploadthing/        ← Dev 3's UploadThing handlers (verbatim)
├── components/
│   ├── ClippyMascot.tsx        ← The brand mascot — animated paperclip ★
│   ├── WorldMap.tsx            ← Interactive 18-country constellation map ★
│   ├── DemoDrawer.tsx          ← ⌘K demo launcher (DEMO_MODE only) ★
│   ├── Header.tsx              ← Fixed header + Clippy logo + selectors
│   ├── ChatInterface.tsx       ← Streaming Q&A with hero (Clippy + WorldMap)
│   ├── AnswerCard.tsx          ← Streaming-aware + animated confidence ring
│   ├── DocumentAnalysisCard.tsx← Severity-sorted clause cards + verdict box
│   ├── UploadAnalyze.tsx       ← UploadThing dropzone → /api/analyze flow
│   ├── JourneyPlanner.tsx      ← Phased relocation roadmap
│   ├── CountryCompare.tsx      ← Side-by-side country comparison
│   ├── BrowseMode.tsx          ← Category cards that pre-fill chat
│   ├── SkeletonCard.tsx        ← Loading skeletons (5 variants)
│   └── ErrorBanner.tsx         ← Calm, retryable error UI
├── lib/
│   ├── types.ts                ← Source of truth — Dev 1 owns this
│   ├── utils.ts                ← cn() helper + DeepPartial<T>
│   └── uploadthing.ts          ← UploadThing client (UploadDropzone + Button)
└── public/
    ├── formwise-icon.svg       ← Clippy-themed favicon
    ├── favicon.png
    └── apple-icon.png
```

## Step-by-step integration

### 1. Copy files into the repo

From the repo root:

```bash
# Backup anything that already exists:
mv app/page.tsx app/page.tsx.bak 2>/dev/null
mv app/layout.tsx app/layout.tsx.bak 2>/dev/null
mv app/globals.css app/globals.css.bak 2>/dev/null

# Copy the bundle:
cp -r formwise-frontend/app/*           app/
cp -r formwise-frontend/components/*    components/
cp -r formwise-frontend/lib/*           lib/
cp -r formwise-frontend/public/*        public/
cp    formwise-frontend/tailwind.config.ts ./
```

> **`lib/types.ts`** — only overwrite if Dev 1 hasn't shipped a different version yet. The bundle's copy is verbatim from `AI-CONTEXT-FINAL.md`, so if Dev 1's version diverges, theirs wins.

### 2. Verify dependencies

These should already be in `package.json` per `AI-CONTEXT-FINAL.md`:

```jsonc
{
  "dependencies": {
    "next": "14.2.3",
    "react": "^18",
    "ai": "^3.2.0",
    "@ai-sdk/anthropic": "^0.0.39",
    "zod": "^3.23.8",
    "uploadthing": "^6.12.0",
    "@uploadthing/react": "^6.7.0",
    "tailwindcss": "^3.4.0",
    "lucide-react": "^0.383.0",
    "clsx": "^2.1.0",
    "tailwind-merge": "^2.3.0"
  }
}
```

If anything is missing: `npm install <missing>`.

### 3. Environment variables

The frontend itself only needs `NEXT_PUBLIC_UPLOADTHING_APP_ID` and `NEXT_PUBLIC_APP_URL`, but the API routes that this UI calls require:

```bash
# .env.local
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
UPLOADTHING_SECRET=sk_live_...
NEXT_PUBLIC_UPLOADTHING_APP_ID=...
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_DEMO_MODE=true
CHROMA_URL=http://localhost:8000
```

### 4. Run it

```bash
docker compose up -d chromadb     # Dev 3's infra
npx tsx scripts/seed.ts           # Dev 1's seed loader
npm run dev
```

Open http://localhost:3000 — defaults to **Ask** mode.

## How the modes wire together

```
app/page.tsx
├── <Header country="DE" language="en" /> ──┐
└── tabs ─→ ChatInterface       ──→ /api/chat    (streamObject)
       ─→ JourneyPlanner       ──→ /api/journey  (generateObject)
       ─→ CountryCompare       ──→ /api/compare  (generateObject)
       └→ UploadAnalyze        ──→ UploadThing → /api/analyze (generateObject)
```

**Header** owns `country` + `language` state and passes them down — the spec says "Country selector and language selector live in the header, passed as props to each mode."

**`ChatInterface`** uses the streaming pattern from the Dev 4 spec exactly:

```typescript
const { object, submit, isLoading, error } = useObject({
  api: '/api/chat',
  schema: ProcedureAnswerSchema,
});
submit({ question, language, country });
```

**`AnswerCard`** receives `Partial<ProcedureAnswer>` and guards every field — it renders progressively as the stream fills in. The spec's render order is preserved exactly:

1. summary (left-rail terracotta accent card)
2. steps (numbered timeline with connecting line)
3. documents (interactive checkbox checklist with strikethrough)
4. office + fee_info (info card with MapPin and CreditCard icons)
5. source_url (small attribution link with ExternalLink icon)
6. answerable=false → ClarificationPrompt (replaces steps/docs)
7. confidence < 0.5 → "limited information available" badge

**`DocumentAnalysisCard`** receives full `DocumentRisk` (no streaming, `generateObject`):

1. risk_level full-width banner (green/amber/red)
2. summary
3. risks sorted by severity DESC, severity pill + italic blockquote + → recommendation
4. missing_clauses with red XCircle bullets
5. positive_points with sage CheckCircle2 bullets
6. verdict in a primary/accent gradient box

## What Dev 1, 2, 3 must ship for end-to-end function

| Endpoint        | Owner | What this UI sends                                                  |
| --------------- | ----- | ------------------------------------------------------------------- |
| `POST /api/chat`     | Dev 2 | `{ question, language, country }` → streams `ProcedureAnswer`    |
| `POST /api/analyze`  | Dev 2 | `{ file_url, document_type, country }` → `DocumentRisk` JSON     |
| `POST /api/journey`  | Dev 2 | `{ from_country, to_country, nationality, purpose, language }`   |
| `POST /api/compare`  | Dev 2 | `{ question, countries: string[] }` → `CountryComparison` JSON   |
| `POST /api/uploadthing` | Dev 3 | UploadThing handler (`core.ts` + `route.ts`)                  |
| `lib/types.ts`       | Dev 1 | Shared schemas — the bundle includes a verbatim copy             |

If `/api/chat` isn't ready yet, the UI will surface the failure through `ErrorBanner` with a retry button — graceful degradation.

## Design fidelity notes

- **No Framer Motion**: animations are pure CSS (`fw-shimmer`, `fw-ping`, `fw-float-anim`) so we don't add a dependency that wasn't in `AI-CONTEXT-FINAL.md`.
- **`prefers-reduced-motion`** is respected globally in `globals.css`.
- **No emoji except country flags** — every affordance uses lucide-react.
- **Sentence case throughout** — "New question", "Try it free", "Choose file".
- **Brand-tinted shadow** on every primary CTA (`shadow-brand` / `shadow-brand-strong`).

## Tailwind version note

`AI-CONTEXT-FINAL.md` specifies Tailwind **3.4**, but the FormWise design system README mentions the live repo uses Tailwind **4**. The included `tailwind.config.ts` is written for **v3.4** with CSS-variable theming (shadcn-style). If your repo is already on v4:

- Delete `tailwind.config.ts`
- In `globals.css` move the `:root` token block under `@theme inline { ... }` instead of `@layer base { :root { ... } }`
- The components themselves (utility classes like `bg-primary`, `text-accent`) work unchanged on both versions

## Troubleshooting

**"Module not found: `@/lib/types`"** — Make sure `tsconfig.json` has `"paths": { "@/*": ["./*"] }` (Next.js default does).

**Streaming object stays `undefined` forever** — Confirm `/api/chat/route.ts` returns `result.toTextStreamResponse()`, not `result.toJsonResponse()`. The `useObject` hook expects a text stream of partial JSON.

**UploadThing 401** — Check `UPLOADTHING_SECRET` and `NEXT_PUBLIC_UPLOADTHING_APP_ID` are both set, and that your UploadThing dashboard's "App ID" matches the public env var.

**Country flag boxes on Windows** — Known limitation: Windows ships incomplete emoji flag glyphs. Production fix is a font like Twemoji; for the demo, accept it.

**Tab styling looks off** — The page tabs use `border-b-2` on active. If you've customized `borderWidth` in your Tailwind config, restore the default 2px.

## File-level test checklist

Before demo, click through:

- [ ] **Ask mode** — type one of the sample chips, see the answer stream in progressively (summary first, then steps appear, then documents, then office/fee). The streaming caret blinks while incomplete.
- [ ] **Ask mode → Browse all** — pick a category, the chat re-opens with the question pre-filled, then submits.
- [ ] **Ask mode** — try a deliberately weird question to trigger `answerable=false` or `confidence < 0.5`. The ClarificationPrompt or "limited information" badge should appear.
- [ ] **Relocation plan** — fill the form, see phased cards with critical/important/optional pills sorted by phase.
- [ ] **Compare** — toggle 4 countries, type a question, see side-by-side cards with difficulty pills and a final recommendation.
- [ ] **Analyze doc** — upload a PDF, see the spinner while analyzing, then risk banner + clauses sorted high→low + verdict box.
- [ ] **Header dropdowns** — change country, then re-open Ask: the placeholder ("Ask about any [country] procedure…") updates.
- [ ] **Reduced motion** — enable in OS, confirm shimmer/ping animations stop.
